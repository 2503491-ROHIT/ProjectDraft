# LOCRMS — Loan Origination & Credit Risk Management System

An industry-style Spring Boot 3.x microservices backend (Java 21) for loan origination and
credit-risk management. Each service is an independent Spring Boot project with its own MySQL
schema (database-per-service), layered architecture, JWT security, OpenFeign inter-service
communication, Bean Validation, global exception handling, and SLF4J logging.

## Services & Ports

| Service                | Port | Database (MySQL)        | Responsibility |
|------------------------|------|-------------------------|----------------|
| eureka-server          | 8761 | —                       | Service discovery |
| config-server          | 8888 | —                       | Centralized config (Git backend) |
| api-gateway            | 8080 | —                       | Routing + JWT validation + RBAC |
| auth-service           | 8081 | `locrms_auth`           | Register, login, JWT, user/role admin |
| customer-service       | 8082 | `locrms_customer`       | Customer profile, KYC |
| loan-service           | 8083 | `locrms_loan`           | Loan application, eligibility, approval |
| credit-service         | 8084 | `locrms_credit`         | Bureau/internal score, risk grade |
| disbursement-service   | 8085 | `locrms_disbursement`   | Disbursement, EMI schedule, repayments |
| collection-service     | 8086 | `locrms_collection`     | Delinquency scan/flag, agent assignment, recovery |

## Roles

`ROLE_ADMIN`, `ROLE_CUSTOMER`, `ROLE_LOAN_OFFICER`, `ROLE_CREDIT_ANALYST`,
`ROLE_UNDERWRITER`, `ROLE_COLLECTION_AGENT`

> The Loan Officer owns disbursement: after the Underwriter approves a loan, the Loan
> Officer executes disbursement by invoking the Disbursement Service, which generates the
> EMI schedule and marks the loan `DISBURSED`.

### Gateway route security
- `/auth/**`, `/public/**` → permit all
- `/customer/**` → CUSTOMER, ADMIN
- `/loan/**` → CUSTOMER, LOAN_OFFICER, CREDIT_ANALYST, UNDERWRITER, ADMIN
- `/credit/**` → CUSTOMER, CREDIT_ANALYST, UNDERWRITER, ADMIN
- `/disbursement/**` → CUSTOMER, LOAN_OFFICER, UNDERWRITER, COLLECTION_AGENT, ADMIN
- `/collection/**` → COLLECTION_AGENT, ADMIN
- `/admin/**` → ADMIN only

## Inter-service calls (OpenFeign)
- Loan → Customer (verify customer) and Loan → Credit (calculate score)
- Disbursement → Loan (fetch approved loan)
- Collection → Disbursement (fetch overdue EMI details)

The inbound JWT is forwarded automatically on every Feign call via a `RequestInterceptor`.

## Prerequisites
- JDK 21
- MySQL running on `localhost:3306` with user `root` / password `root`
  (override in each service's `application.properties`). Schemas are auto-created.

## Centralized configuration (Spring Cloud Config)

All service configuration lives in a **separate public GitHub repository** and is
served by the Config Server (Git backend):

```
https://github.com/2503491-ROHIT/locrms-config-repo.git
```

The configuration files live **only** in that GitHub repository (the
`config-repo/` folder is no longer kept in this project). The repo contains:
- `application.properties` — shared settings applied to every service
  (Eureka, JPA/Hibernate, JWT secret, logging).
- `<service>.properties` — per-service settings (port, datasource, routes).

To edit configuration, change the files in the
`locrms-config-repo` GitHub repository (the Config Server picks them up on
restart, or via `/actuator/refresh` if Spring Boot Actuator is enabled).

Each business service and the gateway keep only a minimal local
`application.properties` (just `spring.application.name` + the Config Server
import); everything else is fetched from the Config Server at startup. Override
the repo location with the `CONFIG_REPO_URI` environment variable if needed.

> Because the Config Server is now the single source of truth, it **must be
> running before** the business services and the gateway start.

## Startup order
1. `eureka-server`
2. `config-server`
3. `api-gateway`
4. Business services (any order): auth, customer, loan, credit, disbursement, collection

Run a service:
```powershell
cd auth-service; .\mvnw.cmd spring-boot:run
```

A default admin is seeded in auth-service on first start:
`username=admin`, `password=Admin@123`.

## Key user journeys

### 1. Customer self-registers from the portal
```
POST /auth/register        { username, email, password }   -> ROLE_CUSTOMER
POST /auth/login           { username, password }           -> JWT
POST /customer/register    (Bearer JWT) customer profile
POST /customer/{id}/kyc    upload KYC
```

### 2. Admin registers staff users
```
POST /admin/users          (Bearer admin JWT) { username, email, password, role }
PATCH /admin/users/{id}/activate | /deactivate | /role
```

### 3. Loan lifecycle
```
POST  /loan/apply           verifies customer + pulls credit score (Feign) -> SUBMITTED
PATCH /loan/{id}/forward    loan officer forwards an eligible application   -> UNDER_REVIEW
PATCH /loan/{id}/reject     loan officer rejects an ineligible application  -> REJECTED
PATCH /loan/{id}/approve    underwriter approves                            -> APPROVED
POST  /disbursement/disburse  { loanId } -> generates EMI schedule          -> DISBURSED
```

### 4. Admin flags delinquents and assigns agents
```
POST /collection/scan                 (admin) pulls overdue EMIs (Feign), flags accounts
POST /collection/auto-assign          (admin) { availableAgentIds:[...] } round-robin assign
POST /collection/{id}/assign          (admin) assign a single case to an agent
POST /collection/{id}/recovery        agent records recovery action
PATCH /collection/{id}/write-off      write off
```

## Build
```powershell
.\auth-service\mvnw.cmd -f pom.xml compile
```

## Notes
- `application.properties` is used everywhere (no YAML).
- Entities are never exposed; all I/O uses DTOs (suffixed `DTO`) via mapper classes.
- Constructor injection only; business logic lives in `service/impl`.
- Java Streams are used across aggregation, mapping, scanning, and assignment logic.

