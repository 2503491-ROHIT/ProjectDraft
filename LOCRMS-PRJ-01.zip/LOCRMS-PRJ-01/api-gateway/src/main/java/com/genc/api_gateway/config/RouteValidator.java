package com.genc.api_gateway.config;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Defines public (no-JWT) routes and the role-based access rules per route prefix.
 */
@Component
public class RouteValidator {

    public static final List<String> OPEN_API_ENDPOINTS = List.of(
            "/auth",
            "/public",
            "/eureka"
    );

    private static final Map<String, Set<String>> ROLE_RULES = Map.of(
            // Coarse gateway gate: any role that needs *some* /customer access passes here;
            // customer-service enforces the fine-grained method+path rules (e.g. KYC verify = Loan Officer).
            "/customer", Set.of("ROLE_CUSTOMER", "ROLE_LOAN_OFFICER", "ROLE_CREDIT_ANALYST",
                    "ROLE_UNDERWRITER", "ROLE_ADMIN"),
            "/loan", Set.of("ROLE_CUSTOMER", "ROLE_LOAN_OFFICER", "ROLE_CREDIT_ANALYST",
                    "ROLE_UNDERWRITER", "ROLE_ADMIN"),
            "/credit", Set.of("ROLE_CUSTOMER", "ROLE_LOAN_OFFICER", "ROLE_CREDIT_ANALYST", "ROLE_UNDERWRITER", "ROLE_ADMIN"),
            "/disbursement", Set.of("ROLE_CUSTOMER", "ROLE_LOAN_OFFICER", "ROLE_UNDERWRITER",
                    "ROLE_COLLECTION_AGENT", "ROLE_ADMIN"),
            "/collection", Set.of("ROLE_COLLECTION_AGENT", "ROLE_ADMIN"),
            "/admin", Set.of("ROLE_ADMIN")
    );

    public boolean isSecured(String path) {
        return OPEN_API_ENDPOINTS.stream().noneMatch(path::startsWith);
    }

    /** True if any of the user's roles is permitted for the path (open if no rule matches). */
    public boolean isAuthorized(String path, List<String> userRoles) {
        return ROLE_RULES.entrySet().stream()
                .filter(entry -> path.startsWith(entry.getKey()))
                .findFirst()
                .map(entry -> userRoles.stream().anyMatch(entry.getValue()::contains))
                .orElse(true);
    }
}

