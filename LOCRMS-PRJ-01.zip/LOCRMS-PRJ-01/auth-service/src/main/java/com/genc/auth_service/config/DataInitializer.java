package com.genc.auth_service.config;

import com.genc.auth_service.model.Role;
import com.genc.auth_service.model.RoleName;
import com.genc.auth_service.model.User;
import com.genc.auth_service.repository.RoleRepository;
import com.genc.auth_service.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Arrays;
import java.util.Set;

/**
 * Seeds the roles table and a default administrator on startup.
 */
@Configuration
public class DataInitializer {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    @Bean
    public ApplicationRunner seedData(RoleRepository roleRepository,
                                      UserRepository userRepository,
                                      PasswordEncoder passwordEncoder) {
        return args -> {
            Arrays.stream(RoleName.values())
                    .filter(name -> roleRepository.findByName(name).isEmpty())
                    .forEach(name -> {
                        roleRepository.save(Role.builder().name(name).build());
                        log.info("Seeded role {}", name);
                    });

            if (!userRepository.existsByUsername("admin")) {
                Role adminRole = roleRepository.findByName(RoleName.ROLE_ADMIN).orElseThrow();
                User admin = User.builder()
                        .username("admin")
                        .email("admin@locrms.com")
                        .password(passwordEncoder.encode("Admin@123"))
                        .active(true)
                        .roles(Set.of(adminRole))
                        .build();
                userRepository.save(admin);
                log.info("Seeded default admin user (username='admin')");
            }
        };
    }
}

