package com.genc.auth_service.controller;

import com.genc.auth_service.dto.PasswordResetDTO;
import com.genc.auth_service.dto.RoleChangeDTO;
import com.genc.auth_service.dto.StaffRegistrationDTO;
import com.genc.auth_service.dto.UserResponseDTO;
import com.genc.auth_service.service.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Admin-only endpoints for managing internal staff users.
 */
@RestController
@RequestMapping("/admin/users")
public class AdminUserController {

    private static final Logger log = LoggerFactory.getLogger(AdminUserController.class);

    private final UserService userService;

    public AdminUserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<UserResponseDTO> registerStaff(@Valid @RequestBody StaffRegistrationDTO request) {
        log.info("POST /admin/users registering staff '{}'", request.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.registerStaff(request));
    }

    @GetMapping
    public ResponseEntity<List<UserResponseDTO>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponseDTO> getUser(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @PatchMapping("/{id}/activate")
    public ResponseEntity<UserResponseDTO> activate(@PathVariable Long id) {
        return ResponseEntity.ok(userService.setActive(id, true));
    }

    @PatchMapping("/{id}/deactivate")
    public ResponseEntity<UserResponseDTO> deactivate(@PathVariable Long id) {
        return ResponseEntity.ok(userService.setActive(id, false));
    }

    @PatchMapping("/{id}/role")
    public ResponseEntity<UserResponseDTO> changeRole(@PathVariable Long id,
                                                      @Valid @RequestBody RoleChangeDTO request) {
        return ResponseEntity.ok(userService.changeRole(id, request.getRole()));
    }

    @PatchMapping("/{id}/password")
    public ResponseEntity<UserResponseDTO> resetPassword(@PathVariable Long id,
                                                         @Valid @RequestBody PasswordResetDTO request) {
        log.info("PATCH /admin/users/{}/password resetting password", id);
        return ResponseEntity.ok(userService.resetPassword(id, request.getNewPassword()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
}

