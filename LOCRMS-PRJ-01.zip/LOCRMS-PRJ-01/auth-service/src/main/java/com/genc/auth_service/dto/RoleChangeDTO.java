package com.genc.auth_service.dto;

import com.genc.auth_service.model.RoleName;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoleChangeDTO {

    @NotNull(message = "Role is required")
    private RoleName role;
}

