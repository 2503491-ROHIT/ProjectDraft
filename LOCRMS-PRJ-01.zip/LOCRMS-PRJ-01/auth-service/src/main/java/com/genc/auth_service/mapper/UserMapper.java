package com.genc.auth_service.mapper;

import com.genc.auth_service.dto.UserResponseDTO;
import com.genc.auth_service.model.Role;
import com.genc.auth_service.model.User;
import org.springframework.stereotype.Component;

/**
 * Converts between {@link User} entities and their DTO representations.
 */
@Component
public class UserMapper {

    public UserResponseDTO toResponseDTO(User user) {
        return UserResponseDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .active(user.isActive())
                .roles(user.getRoles().stream()
                        .map(Role::getName)
                        .map(Enum::name)
                        .sorted()
                        .toList())
                .build();
    }
}

