package com.genc.auth_service.model;

/**
 * The set of roles supported by the platform.
 */
public enum RoleName {
    ROLE_ADMIN,
    ROLE_CUSTOMER,
    ROLE_LOAN_OFFICER,
    ROLE_CREDIT_ANALYST,
    ROLE_UNDERWRITER,
    ROLE_COLLECTION_AGENT
}

