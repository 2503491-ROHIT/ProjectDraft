package com.genc.auth_service.service;

import com.genc.auth_service.dto.AuthResponseDTO;
import com.genc.auth_service.dto.LoginRequestDTO;
import com.genc.auth_service.dto.RegisterRequestDTO;
import com.genc.auth_service.dto.UserResponseDTO;

public interface AuthService {

    /** Self-registration for portal customers (assigned ROLE_CUSTOMER). */
    UserResponseDTO registerCustomer(RegisterRequestDTO request);

    /** Authenticates a user and issues a JWT. */
    AuthResponseDTO login(LoginRequestDTO request);
}

