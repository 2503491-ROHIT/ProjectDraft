package com.genc.auth_service.service;

import com.genc.auth_service.dto.StaffRegistrationDTO;
import com.genc.auth_service.dto.UserResponseDTO;
import com.genc.auth_service.model.RoleName;

import java.util.List;

public interface UserService {

    /** Admin registers an internal staff user with a specific role. */
    UserResponseDTO registerStaff(StaffRegistrationDTO request);

    List<UserResponseDTO> getAllUsers();

    UserResponseDTO getUserById(Long id);

    UserResponseDTO setActive(Long id, boolean active);

    UserResponseDTO changeRole(Long id, RoleName role);

    /** Admin resets an employee's password. */
    UserResponseDTO resetPassword(Long id, String newPassword);

    void deleteUser(Long id);
}

