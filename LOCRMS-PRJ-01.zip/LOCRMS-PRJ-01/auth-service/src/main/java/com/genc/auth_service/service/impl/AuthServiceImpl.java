package com.genc.auth_service.service.impl;

import com.genc.auth_service.dto.AuthResponseDTO;
import com.genc.auth_service.dto.LoginRequestDTO;
import com.genc.auth_service.dto.RegisterRequestDTO;
import com.genc.auth_service.dto.UserResponseDTO;
import com.genc.auth_service.exception.DuplicateResourceException;
import com.genc.auth_service.exception.ResourceNotFoundException;
import com.genc.auth_service.mapper.UserMapper;
import com.genc.auth_service.model.Role;
import com.genc.auth_service.model.RoleName;
import com.genc.auth_service.model.User;
import com.genc.auth_service.repository.RoleRepository;
import com.genc.auth_service.repository.UserRepository;
import com.genc.auth_service.security.JwtService;
import com.genc.auth_service.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Service
public class AuthServiceImpl implements AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthServiceImpl.class);

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final UserMapper userMapper;

    public AuthServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           PasswordEncoder passwordEncoder,
                           AuthenticationManager authenticationManager,
                           JwtService jwtService,
                           UserMapper userMapper) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
        this.userMapper = userMapper;
    }

    @Override
    @Transactional
    public UserResponseDTO registerCustomer(RegisterRequestDTO request) {
        log.trace("Entering registerCustomer with request={}", request);
        log.info("Registering new customer with username '{}'", request.getUsername());
        validateUniqueness(request.getUsername(), request.getEmail());

        log.debug("Resolving default ROLE_CUSTOMER for new customer '{}'", request.getUsername());
        Role customerRole = roleRepository.findByName(RoleName.ROLE_CUSTOMER)
                .orElseThrow(() -> new ResourceNotFoundException("Default role ROLE_CUSTOMER not configured"));

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .active(true)
                .roles(Set.of(customerRole))
                .build();

        log.debug("Persisting new customer entity for username '{}'", request.getUsername());
        User saved = userRepository.save(user);
        log.info("Customer '{}' registered with id {}", saved.getUsername(), saved.getId());
        UserResponseDTO response = userMapper.toResponseDTO(saved);
        log.trace("Exiting registerCustomer, returning={}", response);
        return response;
    }

    @Override
    public AuthResponseDTO login(LoginRequestDTO request) {
        log.trace("Entering login for username '{}'", request.getUsername());
        log.info("Authenticating user '{}'", request.getUsername());
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        log.debug("Credentials verified for '{}', generating JWT", userDetails.getUsername());

        User user = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userDetails.getUsername()));

        String token = jwtService.generateToken(userDetails, user.getId(), user.getEmail());
        log.debug("JWT generated for user '{}'", userDetails.getUsername());

        return AuthResponseDTO.builder()
                .id(user.getId())
                .token(token)
                .tokenType("Bearer")
                .username(userDetails.getUsername())
                .roles(userDetails.getAuthorities().stream()
                        .map(GrantedAuthority::getAuthority)
                        .sorted()
                        .toList())
                .build();
    }

    private void validateUniqueness(String username, String email) {
        log.debug("Validating uniqueness of username='{}' and email='{}'", username, email);
        if (userRepository.existsByUsername(username)) {
            throw new DuplicateResourceException("Username already taken: " + username);
        }
        if (userRepository.existsByEmail(email)) {
            throw new DuplicateResourceException("Email already registered: " + email);
        }
    }
}

