package com.genc.auth_service.service.impl;

import com.genc.auth_service.dto.StaffRegistrationDTO;
import com.genc.auth_service.dto.UserResponseDTO;
import com.genc.auth_service.exception.DuplicateResourceException;
import com.genc.auth_service.exception.InvalidRequestException;
import com.genc.auth_service.exception.ResourceNotFoundException;
import com.genc.auth_service.mapper.UserMapper;
import com.genc.auth_service.model.Role;
import com.genc.auth_service.model.RoleName;
import com.genc.auth_service.model.User;
import com.genc.auth_service.repository.RoleRepository;
import com.genc.auth_service.repository.UserRepository;
import com.genc.auth_service.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;

    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           PasswordEncoder passwordEncoder,
                           UserMapper userMapper) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.userMapper = userMapper;
    }

    @Override
    @Transactional
    public UserResponseDTO registerStaff(StaffRegistrationDTO request) {
        log.trace("Entering registerStaff with request={}", request);
        log.info("Admin registering staff user '{}' with role {}", request.getUsername(), request.getRole());

        if (request.getRole() == RoleName.ROLE_CUSTOMER) {
            throw new InvalidRequestException("Customers must self-register via the portal");
        }
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username already taken: " + request.getUsername());
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already registered: " + request.getEmail());
        }

        log.debug("Resolving role {} for staff '{}'", request.getRole(), request.getUsername());
        Role role = roleRepository.findByName(request.getRole())
                .orElseThrow(() -> new ResourceNotFoundException("Role not configured: " + request.getRole()));

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .active(true)
                .roles(Set.of(role))
                .build();

        UserResponseDTO response = userMapper.toResponseDTO(userRepository.save(user));
        log.trace("Exiting registerStaff, returning={}", response);
        return response;
    }

    @Override
    public List<UserResponseDTO> getAllUsers() {
        log.debug("Fetching all users");
        List<UserResponseDTO> users = userRepository.findAll().stream()
                .map(userMapper::toResponseDTO)
                .toList();
        log.debug("Retrieved {} user(s)", users.size());
        return users;
    }

    @Override
    public UserResponseDTO getUserById(Long id) {
        log.trace("Entering getUserById with id={}", id);
        return userMapper.toResponseDTO(findUser(id));
    }

    @Override
    @Transactional
    public UserResponseDTO setActive(Long id, boolean active) {
        log.trace("Entering setActive with id={}, active={}", id, active);
        User user = findUser(id);
        user.setActive(active);
        log.info("User {} active status set to {}", id, active);
        return userMapper.toResponseDTO(userRepository.save(user));
    }

    @Override
    @Transactional
    public UserResponseDTO changeRole(Long id, RoleName roleName) {
        log.trace("Entering changeRole with id={}, roleName={}", id, roleName);
        User user = findUser(id);
        log.debug("Resolving role {} for user {}", roleName, id);
        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new ResourceNotFoundException("Role not configured: " + roleName));
        user.setRoles(Set.of(role));
        log.info("User {} role changed to {}", id, roleName);
        return userMapper.toResponseDTO(userRepository.save(user));
    }

    @Override
    @Transactional
    public UserResponseDTO resetPassword(Long id, String newPassword) {
        log.trace("Entering resetPassword with id={}", id);
        User user = findUser(id);
        user.setPassword(passwordEncoder.encode(newPassword));
        log.info("Password reset for user {}", id);
        return userMapper.toResponseDTO(userRepository.save(user));
    }

    @Override
    @Transactional
    public void deleteUser(Long id) {
        log.trace("Entering deleteUser with id={}", id);
        User user = findUser(id);
        userRepository.delete(user);
        log.info("User {} deleted", id);
    }

    private User findUser(Long id) {
        log.debug("Looking up user by id={}", id);
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }
}

