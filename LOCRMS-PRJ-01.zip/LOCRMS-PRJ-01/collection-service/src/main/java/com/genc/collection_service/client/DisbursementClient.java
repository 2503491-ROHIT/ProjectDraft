package com.genc.collection_service.client;

import com.genc.collection_service.dto.OverdueRepaymentDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * Feign client used to fetch overdue EMI details from Disbursement Service.
 */
@FeignClient(name = "disbursement-service")
public interface DisbursementClient {

    @GetMapping("/disbursement/overdue")
    List<OverdueRepaymentDTO> getOverdueRepayments();
}

