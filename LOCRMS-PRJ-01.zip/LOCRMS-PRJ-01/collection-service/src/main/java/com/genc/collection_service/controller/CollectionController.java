package com.genc.collection_service.controller;

import com.genc.collection_service.dto.AgentAssignmentDTO;
import com.genc.collection_service.dto.AutoAssignmentDTO;
import com.genc.collection_service.dto.CollectionLogDTO;
import com.genc.collection_service.dto.RecoveryActionDTO;
import com.genc.collection_service.dto.RecoveryStatusUpdateDTO;
import com.genc.collection_service.service.CollectionService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/collection")
public class CollectionController {

    private static final Logger log = LoggerFactory.getLogger(CollectionController.class);

    private final CollectionService collectionService;

    public CollectionController(CollectionService collectionService) {
        this.collectionService = collectionService;
    }

    @PostMapping("/scan")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<CollectionLogDTO>> scanAndFlag() {
        log.info("POST /collection/scan triggered");
        return ResponseEntity.status(HttpStatus.CREATED).body(collectionService.scanAndFlagDelinquents());
    }

    @PostMapping("/auto-assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<CollectionLogDTO>> autoAssign(@Valid @RequestBody AutoAssignmentDTO request) {
        log.info("POST /collection/auto-assign across {} agent(s)", request.getAvailableAgentIds().size());
        return ResponseEntity.ok(collectionService.autoAssignAgents(request.getAvailableAgentIds()));
    }

    @PostMapping("/{id}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CollectionLogDTO> assignAgent(@PathVariable Long id,
                                                        @Valid @RequestBody AgentAssignmentDTO request) {
        return ResponseEntity.ok(collectionService.assignAgent(id, request.getAgentId()));
    }

    @PostMapping("/{id}/recovery")
    public ResponseEntity<CollectionLogDTO> addRecovery(@PathVariable Long id,
                                                        @Valid @RequestBody RecoveryActionDTO request) {
        return ResponseEntity.ok(collectionService.addRecoveryAction(id, request));
    }

    @GetMapping
    public ResponseEntity<List<CollectionLogDTO>> getAll() {
        return ResponseEntity.ok(collectionService.getAllCollections());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CollectionLogDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(collectionService.getById(id));
    }

    @GetMapping("/agent/{agentId}")
    public ResponseEntity<List<CollectionLogDTO>> getByAgent(@PathVariable Long agentId) {
        return ResponseEntity.ok(collectionService.getByAgent(agentId));
    }

    @GetMapping("/history/{loanId}")
    public ResponseEntity<List<CollectionLogDTO>> getHistory(@PathVariable Long loanId) {
        return ResponseEntity.ok(collectionService.getHistoryByLoan(loanId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CollectionLogDTO> update(@PathVariable Long id,
                                                   @Valid @RequestBody RecoveryActionDTO request) {
        return ResponseEntity.ok(collectionService.updateCollectionRecord(id, request));
    }

    @PatchMapping("/{id}/recovery-status")
    public ResponseEntity<CollectionLogDTO> updateRecoveryStatus(@PathVariable Long id,
                                                                 @Valid @RequestBody RecoveryStatusUpdateDTO request) {
        return ResponseEntity.ok(collectionService.updateRecoveryStatus(id, request.getStatus()));
    }

    @PatchMapping("/{id}/write-off")
    public ResponseEntity<CollectionLogDTO> writeOff(@PathVariable Long id,
                                                     @RequestBody(required = false) RecoveryStatusUpdateDTO request) {
        String remarks = request != null ? request.getRemarks() : "Written off";
        return ResponseEntity.ok(collectionService.writeOff(id, remarks));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        collectionService.deleteCollection(id);
        return ResponseEntity.noContent().build();
    }
}

