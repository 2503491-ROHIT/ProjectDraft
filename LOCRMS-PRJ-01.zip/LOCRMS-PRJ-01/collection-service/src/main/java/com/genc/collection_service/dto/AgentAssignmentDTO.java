package com.genc.collection_service.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request to assign a single delinquent case to a collection agent.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgentAssignmentDTO {

    @NotNull(message = "Agent id is required")
    @Positive(message = "Agent id must be positive")
    private Long agentId;
}

