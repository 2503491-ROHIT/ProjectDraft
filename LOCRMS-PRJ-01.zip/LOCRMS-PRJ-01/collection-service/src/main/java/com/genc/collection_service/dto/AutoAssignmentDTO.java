package com.genc.collection_service.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Request to auto-distribute all unassigned flagged cases across the supplied
 * list of available collection agents.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AutoAssignmentDTO {

    @NotEmpty(message = "At least one available agent id is required")
    private List<Long> availableAgentIds;
}

