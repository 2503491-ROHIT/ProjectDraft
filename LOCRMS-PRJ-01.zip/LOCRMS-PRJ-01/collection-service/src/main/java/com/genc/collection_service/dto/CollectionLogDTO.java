package com.genc.collection_service.dto;

import com.genc.collection_service.model.CollectionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CollectionLogDTO {

    private Long id;
    private Long loanId;
    private Long customerId;
    private BigDecimal overdueAmount;
    private Integer daysPastDue;
    private CollectionStatus status;
    private Long assignedAgentId;
    private String actionTaken;
    private LocalDate actionDate;
    private LocalDateTime createdAt;
}
