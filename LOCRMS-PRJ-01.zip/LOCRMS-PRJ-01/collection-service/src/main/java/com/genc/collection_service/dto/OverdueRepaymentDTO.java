package com.genc.collection_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Overdue EMI details fetched from Disbursement Service.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OverdueRepaymentDTO {

    private Long id;
    private Long loanId;
    private Long customerId;
    private Integer installmentNumber;
    private BigDecimal emiAmount;
    private LocalDate dueDate;
    private String status;
}

