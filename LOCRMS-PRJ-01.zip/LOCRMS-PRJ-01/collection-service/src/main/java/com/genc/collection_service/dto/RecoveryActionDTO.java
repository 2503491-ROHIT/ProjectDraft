package com.genc.collection_service.dto;

import com.genc.collection_service.model.CollectionStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecoveryActionDTO {

    @NotNull(message = "Status is required")
    private CollectionStatus status;

    @Size(max = 500, message = "Remarks cannot exceed 500 characters")
    private String remarks;
}

