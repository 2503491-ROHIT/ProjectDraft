package com.genc.collection_service.mapper;

import com.genc.collection_service.dto.CollectionLogDTO;
import com.genc.collection_service.model.CollectionLog;
import org.springframework.stereotype.Component;

@Component
public class CollectionLogMapper {

    public CollectionLogDTO toDTO(CollectionLog log) {
        return CollectionLogDTO.builder()
                .id(log.getId())
                .loanId(log.getLoanId())
                .customerId(log.getCustomerId())
                .overdueAmount(log.getOverdueAmount())
                .daysPastDue(log.getDaysPastDue())
                .status(log.getStatus())
                .assignedAgentId(log.getAssignedAgentId())
                .actionTaken(log.getActionTaken())
                .actionDate(log.getActionDate())
                .createdAt(log.getCreatedAt())
                .build();
    }
}
