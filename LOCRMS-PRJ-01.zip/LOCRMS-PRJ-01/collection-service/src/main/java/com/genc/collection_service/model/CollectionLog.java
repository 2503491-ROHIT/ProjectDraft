package com.genc.collection_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "collection_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CollectionLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "logId")
    private Long id;

    @Column(name = "applicationId", nullable = false)
    private Long loanId;

    @Column(nullable = false)
    private Long customerId;

    @Column(nullable = false)
    private BigDecimal overdueAmount;

    @Column(nullable = false)
    @Builder.Default
    private Integer daysPastDue = 0;

    @Enumerated(EnumType.STRING)
    @Column(name = "recoveryStatus", nullable = false, length = 15)
    @Builder.Default
    private CollectionStatus status = CollectionStatus.PENDING;

    /** The collection agent (user id) assigned to recover this account. */
    private Long assignedAgentId;

    @Column(length = 255)
    private String actionTaken;

    private LocalDate actionDate;

    @Column(nullable = false, updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
}
