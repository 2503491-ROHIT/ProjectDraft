package com.genc.collection_service.model;

public enum CollectionStatus {
    PENDING,
    RECOVERED,
    WRITTEN_OFF
}
