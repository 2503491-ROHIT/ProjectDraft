package com.genc.collection_service.repository;

import com.genc.collection_service.model.CollectionLog;
import com.genc.collection_service.model.CollectionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CollectionLogRepository extends JpaRepository<CollectionLog, Long> {

    List<CollectionLog> findByLoanId(Long loanId);

    List<CollectionLog> findByAssignedAgentId(Long agentId);

    List<CollectionLog> findByStatus(CollectionStatus status);

    boolean existsByLoanIdAndStatusNot(Long loanId, CollectionStatus status);
}

