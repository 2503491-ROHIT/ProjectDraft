package com.genc.collection_service.service;

import com.genc.collection_service.dto.CollectionLogDTO;
import com.genc.collection_service.dto.RecoveryActionDTO;
import com.genc.collection_service.model.CollectionStatus;

import java.util.List;

public interface CollectionService {

    /** Admin scans overdue EMIs and flags delinquent accounts. */
    List<CollectionLogDTO> scanAndFlagDelinquents();

    /** Auto-distributes unassigned flagged cases across available agents. */
    List<CollectionLogDTO> autoAssignAgents(List<Long> availableAgentIds);

    CollectionLogDTO assignAgent(Long collectionId, Long agentId);

    CollectionLogDTO addRecoveryAction(Long collectionId, RecoveryActionDTO action);

    List<CollectionLogDTO> getAllCollections();

    CollectionLogDTO getById(Long id);

    List<CollectionLogDTO> getByAgent(Long agentId);

    List<CollectionLogDTO> getHistoryByLoan(Long loanId);

    CollectionLogDTO updateCollectionRecord(Long id, RecoveryActionDTO action);

    CollectionLogDTO updateRecoveryStatus(Long id, CollectionStatus status);

    CollectionLogDTO writeOff(Long id, String remarks);

    void deleteCollection(Long id);
}

