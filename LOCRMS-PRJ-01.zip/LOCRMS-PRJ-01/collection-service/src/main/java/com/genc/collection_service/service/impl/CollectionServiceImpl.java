package com.genc.collection_service.service.impl;

import com.genc.collection_service.client.DisbursementClient;
import com.genc.collection_service.dto.CollectionLogDTO;
import com.genc.collection_service.dto.OverdueRepaymentDTO;
import com.genc.collection_service.dto.RecoveryActionDTO;
import com.genc.collection_service.exception.InvalidRequestException;
import com.genc.collection_service.exception.ResourceNotFoundException;
import com.genc.collection_service.mapper.CollectionLogMapper;
import com.genc.collection_service.model.CollectionLog;
import com.genc.collection_service.model.CollectionStatus;
import com.genc.collection_service.repository.CollectionLogRepository;
import com.genc.collection_service.service.CollectionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class CollectionServiceImpl implements CollectionService {

    private static final Logger log = LoggerFactory.getLogger(CollectionServiceImpl.class);

    private final CollectionLogRepository collectionLogRepository;
    private final CollectionLogMapper collectionLogMapper;
    private final DisbursementClient disbursementClient;

    public CollectionServiceImpl(CollectionLogRepository collectionLogRepository,
                                 CollectionLogMapper collectionLogMapper,
                                 DisbursementClient disbursementClient) {
        this.collectionLogRepository = collectionLogRepository;
        this.collectionLogMapper = collectionLogMapper;
        this.disbursementClient = disbursementClient;
    }

    @Override
    @Transactional
    public List<CollectionLogDTO> scanAndFlagDelinquents() {
        log.trace("Entering scanAndFlagDelinquents");
        log.info("Scanning for delinquent accounts via Disbursement Service");
        List<OverdueRepaymentDTO> overdue = fetchOverdueRepayments();
        log.debug("Fetched {} overdue installment(s) from Disbursement Service", overdue.size());

        // Group all overdue installments by their loan.
        Map<Long, List<OverdueRepaymentDTO>> overdueByLoan = overdue.stream()
                .collect(Collectors.groupingBy(OverdueRepaymentDTO::getLoanId));
        log.debug("Overdue installments span {} distinct loan(s)", overdueByLoan.size());

        // Flag only loans that do not already have an active collection case.
        List<CollectionLog> newlyFlagged = overdueByLoan.values().stream()
                .filter(installments -> !collectionLogRepository
                        .existsByLoanIdAndStatusNot(installments.get(0).getLoanId(), CollectionStatus.WRITTEN_OFF))
                .map(this::buildFlaggedLog)
                .toList();

        List<CollectionLog> saved = collectionLogRepository.saveAll(newlyFlagged);
        log.info("Flagged {} new delinquent account(s)", saved.size());
        List<CollectionLogDTO> response = saved.stream().map(collectionLogMapper::toDTO).toList();
        log.trace("Exiting scanAndFlagDelinquents, returning {} record(s)", response.size());
        return response;
    }

    /** Builds a PENDING collection log for one loan from its overdue installments. */
    private CollectionLog buildFlaggedLog(List<OverdueRepaymentDTO> installments) {
        BigDecimal totalOverdue = installments.stream()
                .map(OverdueRepaymentDTO::getEmiAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        int daysPastDue = installments.stream()
                .map(OverdueRepaymentDTO::getDueDate)
                .min(LocalDate::compareTo)
                .map(earliest -> (int) ChronoUnit.DAYS.between(earliest, LocalDate.now()))
                .orElse(0);

        OverdueRepaymentDTO first = installments.get(0);
        return CollectionLog.builder()
                .loanId(first.getLoanId())
                .customerId(first.getCustomerId())
                .overdueAmount(totalOverdue)
                .daysPastDue(Math.max(daysPastDue, 0))
                .status(CollectionStatus.PENDING)
                .build();
    }

    @Override
    @Transactional
    public List<CollectionLogDTO> autoAssignAgents(List<Long> availableAgentIds) {
        log.trace("Entering autoAssignAgents with availableAgentIds={}", availableAgentIds);
        if (availableAgentIds == null || availableAgentIds.isEmpty()) {
            throw new InvalidRequestException("At least one available agent is required");
        }

        List<CollectionLog> unassigned = collectionLogRepository.findByStatus(CollectionStatus.PENDING).stream()
                .filter(item -> item.getAssignedAgentId() == null)
                .toList();
        log.debug("Found {} unassigned pending case(s)", unassigned.size());

        if (unassigned.isEmpty()) {
            log.info("No unassigned pending cases to distribute");
            return List.of();
        }

        // Round-robin distribution across the available agents using streams.
        List<CollectionLog> assigned = IntStream.range(0, unassigned.size())
                .mapToObj(index -> {
                    CollectionLog item = unassigned.get(index);
                    Long agentId = availableAgentIds.get(index % availableAgentIds.size());
                    item.setAssignedAgentId(agentId);
                    item.setActionTaken("Assigned to agent");
                    item.setActionDate(LocalDate.now());
                    log.trace("Assigning case {} to agent {}", item.getId(), agentId);
                    return item;
                })
                .toList();

        List<CollectionLog> saved = collectionLogRepository.saveAll(assigned);
        log.info("Auto-assigned {} case(s) across {} agent(s)", saved.size(), availableAgentIds.size());
        return saved.stream().map(collectionLogMapper::toDTO).toList();
    }

    @Override
    @Transactional
    public CollectionLogDTO assignAgent(Long collectionId, Long agentId) {
        log.trace("Entering assignAgent with collectionId={}, agentId={}", collectionId, agentId);
        CollectionLog item = findLog(collectionId);
        item.setAssignedAgentId(agentId);
        item.setActionTaken("Assigned to agent " + agentId);
        item.setActionDate(LocalDate.now());
        log.info("Collection case {} assigned to agent {}", collectionId, agentId);
        return collectionLogMapper.toDTO(collectionLogRepository.save(item));
    }

    @Override
    @Transactional
    public CollectionLogDTO addRecoveryAction(Long collectionId, RecoveryActionDTO action) {
        log.trace("Entering addRecoveryAction with collectionId={}, action={}", collectionId, action);
        CollectionLog item = findLog(collectionId);
        item.setStatus(action.getStatus());
        item.setActionTaken(action.getRemarks());
        item.setActionDate(LocalDate.now());
        log.info("Recovery action recorded for collection case {} (status {})", collectionId, action.getStatus());
        return collectionLogMapper.toDTO(collectionLogRepository.save(item));
    }

    @Override
    public List<CollectionLogDTO> getAllCollections() {
        log.debug("Fetching all collection records");
        return collectionLogRepository.findAll().stream()
                .map(collectionLogMapper::toDTO)
                .toList();
    }

    @Override
    public CollectionLogDTO getById(Long id) {
        log.trace("Entering getById with id={}", id);
        return collectionLogMapper.toDTO(findLog(id));
    }

    @Override
    public List<CollectionLogDTO> getByAgent(Long agentId) {
        log.debug("Fetching collection cases for agent {}", agentId);
        return collectionLogRepository.findByAssignedAgentId(agentId).stream()
                .map(collectionLogMapper::toDTO)
                .toList();
    }

    @Override
    public List<CollectionLogDTO> getHistoryByLoan(Long loanId) {
        log.debug("Fetching collection history for loan {}", loanId);
        return collectionLogRepository.findByLoanId(loanId).stream()
                .map(collectionLogMapper::toDTO)
                .toList();
    }

    @Override
    @Transactional
    public CollectionLogDTO updateCollectionRecord(Long id, RecoveryActionDTO action) {
        log.trace("Entering updateCollectionRecord with id={}, action={}", id, action);
        CollectionLog item = findLog(id);
        item.setStatus(action.getStatus());
        item.setActionTaken(action.getRemarks());
        item.setActionDate(LocalDate.now());
        return collectionLogMapper.toDTO(collectionLogRepository.save(item));
    }

    @Override
    @Transactional
    public CollectionLogDTO updateRecoveryStatus(Long id, CollectionStatus status) {
        log.trace("Entering updateRecoveryStatus with id={}, status={}", id, status);
        CollectionLog item = findLog(id);
        item.setStatus(status);
        item.setActionDate(LocalDate.now());
        log.info("Recovery status for collection case {} updated to {}", id, status);
        return collectionLogMapper.toDTO(collectionLogRepository.save(item));
    }

    @Override
    @Transactional
    public CollectionLogDTO writeOff(Long id, String remarks) {
        log.trace("Entering writeOff with id={}", id);
        CollectionLog item = findLog(id);
        if (item.getStatus() == CollectionStatus.RECOVERED) {
            throw new InvalidRequestException("Recovered accounts cannot be written off");
        }
        item.setStatus(CollectionStatus.WRITTEN_OFF);
        item.setActionTaken(remarks);
        item.setActionDate(LocalDate.now());
        log.info("Collection case {} written off", id);
        return collectionLogMapper.toDTO(collectionLogRepository.save(item));
    }

    @Override
    @Transactional
    public void deleteCollection(Long id) {
        log.trace("Entering deleteCollection with id={}", id);
        CollectionLog item = findLog(id);
        collectionLogRepository.delete(item);
        log.info("Collection case {} deleted", id);
    }

    private List<OverdueRepaymentDTO> fetchOverdueRepayments() {
        try {
            List<OverdueRepaymentDTO> overdue = disbursementClient.getOverdueRepayments();
            log.debug("Disbursement Service returned {} overdue repayment(s)", overdue.size());
            return overdue;
        } catch (Exception ex) {
            log.error("Failed to fetch overdue repayments: {}", ex.getMessage());
            throw new ResourceNotFoundException("Unable to fetch overdue EMI details from Disbursement Service");
        }
    }

    private CollectionLog findLog(Long id) {
        log.debug("Looking up collection record by id={}", id);
        return collectionLogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Collection record not found with id: " + id));
    }
}
