package com.genc.credit_service.config;

import com.genc.credit_service.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/public/**").permitAll()
                        // Viewing scores: Loan Officer checks eligibility; Credit Analyst/Underwriter act on them;
                        // Admin monitors; Customer sees own.
                        .requestMatchers(HttpMethod.GET, "/credit/**")
                            .hasAnyRole("CUSTOMER", "LOAN_OFFICER", "CREDIT_ANALYST", "UNDERWRITER", "ADMIN")
                        // Generating/updating an evaluation is the Credit Analyst's job.
                        // CUSTOMER is permitted because loan-service forwards the customer's JWT
                        // when auto-generating a score during loan application (internal Feign call).
                        .requestMatchers("/credit/**").hasAnyRole("CUSTOMER", "CREDIT_ANALYST")
                        .anyRequest().authenticated())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}

