package com.genc.credit_service.controller;

import com.genc.credit_service.dto.CreditScoreDTO;
import com.genc.credit_service.dto.CreditScoreRequestDTO;
import com.genc.credit_service.service.CreditScoreService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/credit")
public class CreditScoreController {

    private static final Logger log = LoggerFactory.getLogger(CreditScoreController.class);

    private final CreditScoreService creditScoreService;

    public CreditScoreController(CreditScoreService creditScoreService) {
        this.creditScoreService = creditScoreService;
    }

    @PostMapping("/generate")
    public ResponseEntity<CreditScoreDTO> generate(@Valid @RequestBody CreditScoreRequestDTO request) {
        log.info("POST /credit/generate for customer {}", request.getCustomerId());
        return ResponseEntity.status(HttpStatus.CREATED).body(creditScoreService.generateScore(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CreditScoreDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(creditScoreService.getById(id));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<CreditScoreDTO>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(creditScoreService.getByCustomerId(customerId));
    }

    @GetMapping("/customer/{customerId}/latest")
    public ResponseEntity<CreditScoreDTO> getLatest(@PathVariable Long customerId) {
        return ResponseEntity.ok(creditScoreService.getLatestForCustomer(customerId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CreditScoreDTO> update(@PathVariable Long id,
                                                 @Valid @RequestBody CreditScoreRequestDTO request) {
        return ResponseEntity.ok(creditScoreService.updateEvaluation(id, request));
    }
}

