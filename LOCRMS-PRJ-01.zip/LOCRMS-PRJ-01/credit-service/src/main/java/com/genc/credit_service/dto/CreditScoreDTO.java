package com.genc.credit_service.dto;

import com.genc.credit_service.model.RiskGrade;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditScoreDTO {

    private Long id;
    private Long customerId;
    private BigDecimal monthlyIncome;
    private BigDecimal existingObligations;
    private Integer bureauScore;
    private Integer internalScore;
    private RiskGrade riskGrade;
    private LocalDate evaluationDate;
}
