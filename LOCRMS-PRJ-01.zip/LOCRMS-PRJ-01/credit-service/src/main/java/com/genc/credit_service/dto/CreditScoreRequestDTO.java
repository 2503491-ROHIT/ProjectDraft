package com.genc.credit_service.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Request used to generate a credit score for a customer.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditScoreRequestDTO {

    @NotNull(message = "Customer id is required")
    @Positive(message = "Customer id must be positive")
    private Long customerId;

    @NotNull(message = "Monthly income is required")
    @Positive(message = "Monthly income must be positive")
    private BigDecimal monthlyIncome;

    @NotNull(message = "Existing obligations are required")
    @PositiveOrZero(message = "Existing obligations cannot be negative")
    private BigDecimal existingObligations;

    @NotNull(message = "Requested loan amount is required")
    @Positive(message = "Requested loan amount must be positive")
    private BigDecimal requestedAmount;
}

