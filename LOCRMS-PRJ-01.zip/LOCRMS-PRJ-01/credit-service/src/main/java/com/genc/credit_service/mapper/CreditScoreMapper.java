package com.genc.credit_service.mapper;

import com.genc.credit_service.dto.CreditScoreDTO;
import com.genc.credit_service.model.CreditScore;
import org.springframework.stereotype.Component;

@Component
public class CreditScoreMapper {

    public CreditScoreDTO toDTO(CreditScore creditScore) {
        return CreditScoreDTO.builder()
                .id(creditScore.getId())
                .customerId(creditScore.getCustomerId())
                .monthlyIncome(creditScore.getMonthlyIncome())
                .existingObligations(creditScore.getExistingObligations())
                .bureauScore(creditScore.getBureauScore())
                .internalScore(creditScore.getInternalScore())
                .riskGrade(creditScore.getRiskGrade())
                .evaluationDate(creditScore.getEvaluationDate())
                .build();
    }
}
