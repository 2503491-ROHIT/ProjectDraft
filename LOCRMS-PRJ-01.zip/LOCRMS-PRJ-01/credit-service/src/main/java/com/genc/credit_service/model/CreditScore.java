package com.genc.credit_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "credit_scores")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditScore {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "scoreId")
    private Long id;

    @Column(nullable = false)
    private Long customerId;

    @Column(precision = 15, scale = 2)
    private java.math.BigDecimal monthlyIncome;

    @Column(precision = 15, scale = 2)
    private java.math.BigDecimal existingObligations;

    @Column(nullable = false)
    private Integer bureauScore;

    @Column(nullable = false)
    private Integer internalScore;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private RiskGrade riskGrade;

    @Column(name = "evaluationDate", nullable = false, updatable = false)
    @Builder.Default
    private LocalDate evaluationDate = LocalDate.now();
}
