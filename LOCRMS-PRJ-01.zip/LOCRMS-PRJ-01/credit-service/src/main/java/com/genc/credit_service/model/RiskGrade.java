package com.genc.credit_service.model;

public enum RiskGrade {
    LOW, MEDIUM, HIGH
}
