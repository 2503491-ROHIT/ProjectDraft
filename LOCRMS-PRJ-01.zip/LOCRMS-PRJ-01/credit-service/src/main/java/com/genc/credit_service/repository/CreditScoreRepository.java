package com.genc.credit_service.repository;

import com.genc.credit_service.model.CreditScore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditScoreRepository extends JpaRepository<CreditScore, Long> {

    List<CreditScore> findByCustomerIdOrderByEvaluationDateDesc(Long customerId);
}
