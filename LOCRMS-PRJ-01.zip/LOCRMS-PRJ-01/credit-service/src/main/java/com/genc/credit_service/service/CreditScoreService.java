package com.genc.credit_service.service;

import com.genc.credit_service.dto.CreditScoreDTO;
import com.genc.credit_service.dto.CreditScoreRequestDTO;

import java.util.List;

public interface CreditScoreService {

    CreditScoreDTO generateScore(CreditScoreRequestDTO request);

    CreditScoreDTO getById(Long id);

    List<CreditScoreDTO> getByCustomerId(Long customerId);

    CreditScoreDTO getLatestForCustomer(Long customerId);

    CreditScoreDTO updateEvaluation(Long id, CreditScoreRequestDTO request);
}

