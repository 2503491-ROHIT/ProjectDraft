package com.genc.credit_service.service.impl;

import com.genc.credit_service.dto.CreditScoreDTO;
import com.genc.credit_service.dto.CreditScoreRequestDTO;
import com.genc.credit_service.exception.ResourceNotFoundException;
import com.genc.credit_service.mapper.CreditScoreMapper;
import com.genc.credit_service.model.CreditScore;
import com.genc.credit_service.model.RiskGrade;
import com.genc.credit_service.repository.CreditScoreRepository;
import com.genc.credit_service.service.CreditScoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class CreditScoreServiceImpl implements CreditScoreService {

    private static final Logger log = LoggerFactory.getLogger(CreditScoreServiceImpl.class);

    private final CreditScoreRepository creditScoreRepository;
    private final CreditScoreMapper creditScoreMapper;

    public CreditScoreServiceImpl(CreditScoreRepository creditScoreRepository, CreditScoreMapper creditScoreMapper) {
        this.creditScoreRepository = creditScoreRepository;
        this.creditScoreMapper = creditScoreMapper;
    }

    @Override
    @Transactional
    public CreditScoreDTO generateScore(CreditScoreRequestDTO request) {
        log.trace("Entering generateScore with request={}", request);
        log.info("Generating credit score for customer {}", request.getCustomerId());
        CreditScore creditScore = evaluate(request);
        CreditScore saved = creditScoreRepository.save(creditScore);
        log.info("Credit score {} generated for customer {} (grade {})",
                saved.getInternalScore(), saved.getCustomerId(), saved.getRiskGrade());
        CreditScoreDTO response = creditScoreMapper.toDTO(saved);
        log.trace("Exiting generateScore, returning={}", response);
        return response;
    }

    @Override
    public CreditScoreDTO getById(Long id) {
        log.trace("Entering getById with id={}", id);
        return creditScoreMapper.toDTO(findScore(id));
    }

    @Override
    public List<CreditScoreDTO> getByCustomerId(Long customerId) {
        log.debug("Fetching credit score history for customer {}", customerId);
        return creditScoreRepository.findByCustomerIdOrderByEvaluationDateDesc(customerId).stream()
                .map(creditScoreMapper::toDTO)
                .toList();
    }

    @Override
    public CreditScoreDTO getLatestForCustomer(Long customerId) {
        log.debug("Fetching latest credit score for customer {}", customerId);
        return creditScoreRepository.findByCustomerIdOrderByEvaluationDateDesc(customerId).stream()
                .findFirst()
                .map(creditScoreMapper::toDTO)
                .orElseThrow(() -> new ResourceNotFoundException("No credit score found for customer: " + customerId));
    }

    @Override
    @Transactional
    public CreditScoreDTO updateEvaluation(Long id, CreditScoreRequestDTO request) {
        log.trace("Entering updateEvaluation with id={}, request={}", id, request);
        CreditScore existing = findScore(id);
        CreditScore recalculated = evaluate(request);
        existing.setMonthlyIncome(recalculated.getMonthlyIncome());
        existing.setExistingObligations(recalculated.getExistingObligations());
        existing.setBureauScore(recalculated.getBureauScore());
        existing.setInternalScore(recalculated.getInternalScore());
        existing.setRiskGrade(recalculated.getRiskGrade());
        log.info("Credit evaluation {} updated", id);
        return creditScoreMapper.toDTO(creditScoreRepository.save(existing));
    }

    /**
     * Simple deterministic scoring model based on the debt-to-income ratio.
     */
    private CreditScore evaluate(CreditScoreRequestDTO request) {
        BigDecimal totalObligations = request.getExistingObligations().add(request.getRequestedAmount());
        BigDecimal dti = totalObligations.divide(request.getMonthlyIncome(), 4, RoundingMode.HALF_UP);

        int internalScore = computeInternalScore(dti);
        int bureauScore = 300 + (internalScore * 11) / 2; // derive a 300-850 style bureau score
        RiskGrade riskGrade = computeRiskGrade(internalScore);
        log.debug("Evaluated customer {}: dti={}, internalScore={}, bureauScore={}, riskGrade={}",
                request.getCustomerId(), dti, internalScore, Math.min(bureauScore, 850), riskGrade);

        return CreditScore.builder()
                .customerId(request.getCustomerId())
                .monthlyIncome(request.getMonthlyIncome())
                .existingObligations(request.getExistingObligations())
                .internalScore(internalScore)
                .bureauScore(Math.min(bureauScore, 850))
                .riskGrade(riskGrade)
                .build();
    }

    private int computeInternalScore(BigDecimal dti) {
        double ratio = dti.doubleValue();
        if (ratio <= 0.20) return 95;
        if (ratio <= 0.35) return 80;
        if (ratio <= 0.50) return 65;
        if (ratio <= 0.75) return 45;
        return 25;
    }

    private RiskGrade computeRiskGrade(int internalScore) {
        if (internalScore >= 75) return RiskGrade.LOW;
        if (internalScore >= 50) return RiskGrade.MEDIUM;
        return RiskGrade.HIGH;
    }

    private CreditScore findScore(Long id) {
        log.debug("Looking up credit score by id={}", id);
        return creditScoreRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Credit score not found with id: " + id));
    }
}
