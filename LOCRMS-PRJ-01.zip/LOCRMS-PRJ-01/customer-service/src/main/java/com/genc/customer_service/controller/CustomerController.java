package com.genc.customer_service.controller;

import com.genc.customer_service.dto.CustomerRequestDTO;
import com.genc.customer_service.dto.CustomerResponseDTO;
import com.genc.customer_service.dto.KycUploadDTO;
import com.genc.customer_service.dto.KycVerificationDTO;
import com.genc.customer_service.service.CustomerService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    private static final Logger log = LoggerFactory.getLogger(CustomerController.class);

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping("/register")
    public ResponseEntity<CustomerResponseDTO> register(@Valid @RequestBody CustomerRequestDTO request) {
        log.info("POST /customer/register for email '{}'", request.getEmail());
        return ResponseEntity.status(HttpStatus.CREATED).body(customerService.registerCustomer(request));
    }

    @GetMapping
    public ResponseEntity<List<CustomerResponseDTO>> getAll() {
        return ResponseEntity.ok(customerService.getAllCustomers());
    }

    @GetMapping("/me")
    public ResponseEntity<CustomerResponseDTO> getMine() {
        log.info("GET /customer/me resolving profile for authenticated user");
        return ResponseEntity.ok(customerService.getMyCustomer());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerResponseDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.getCustomerById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CustomerResponseDTO> update(@PathVariable Long id,
                                                      @Valid @RequestBody CustomerRequestDTO request) {
        return ResponseEntity.ok(customerService.updateCustomer(id, request));
    }

    @PostMapping("/{id}/kyc")
    public ResponseEntity<CustomerResponseDTO> uploadKyc(@PathVariable Long id,
                                                         @Valid @RequestBody KycUploadDTO request) {
        return ResponseEntity.ok(customerService.uploadKyc(id, request));
    }

    @PatchMapping("/{id}/kyc/verify")
    public ResponseEntity<CustomerResponseDTO> verifyKyc(@PathVariable Long id,
                                                         @Valid @RequestBody KycVerificationDTO request) {
        return ResponseEntity.ok(customerService.verifyKyc(id, request.getKycStatus()));
    }

    @PatchMapping("/{id}/deactivate")
    public ResponseEntity<CustomerResponseDTO> deactivate(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.deactivateCustomer(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
}

