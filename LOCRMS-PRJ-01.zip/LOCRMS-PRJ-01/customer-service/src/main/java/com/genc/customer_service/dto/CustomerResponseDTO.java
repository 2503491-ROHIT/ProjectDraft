package com.genc.customer_service.dto;

import com.genc.customer_service.model.KycStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerResponseDTO {

    private Long id;
    private Long userId;
    private String fullName;
    private String email;
    private String phone;
    private String address;
    private String panNumber;
    private String aadhaarNumber;
    private KycStatus kycStatus;
    private boolean active;
    private LocalDate registrationDate;
}
