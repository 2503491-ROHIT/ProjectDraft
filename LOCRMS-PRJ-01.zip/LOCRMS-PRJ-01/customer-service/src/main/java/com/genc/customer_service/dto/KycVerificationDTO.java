package com.genc.customer_service.dto;

import com.genc.customer_service.model.KycStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KycVerificationDTO {

    @NotNull(message = "KYC status is required")
    private KycStatus kycStatus;
}

