package com.genc.customer_service.model;

public enum KycStatus {
    PENDING,
    VERIFIED,
    REJECTED
}
