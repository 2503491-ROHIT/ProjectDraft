package com.genc.customer_service.security;

/**
 * Identity extracted from the JWT and attached to the Authentication details,
 * so services can attribute ownership without trusting client-supplied values.
 */
public record AuthPrincipal(Long userId, String email) {
}

