package com.genc.customer_service.service;

import com.genc.customer_service.dto.CustomerRequestDTO;
import com.genc.customer_service.dto.CustomerResponseDTO;
import com.genc.customer_service.dto.KycUploadDTO;
import com.genc.customer_service.model.KycStatus;

import java.util.List;

public interface CustomerService {

    CustomerResponseDTO registerCustomer(CustomerRequestDTO request);

    List<CustomerResponseDTO> getAllCustomers();

    CustomerResponseDTO getCustomerById(Long id);

    /** The profile owned by the currently authenticated user (resolved from the JWT). */
    CustomerResponseDTO getMyCustomer();

    CustomerResponseDTO updateCustomer(Long id, CustomerRequestDTO request);

    CustomerResponseDTO uploadKyc(Long id, KycUploadDTO request);

    CustomerResponseDTO verifyKyc(Long id, KycStatus status);

    CustomerResponseDTO deactivateCustomer(Long id);

    void deleteCustomer(Long id);
}
