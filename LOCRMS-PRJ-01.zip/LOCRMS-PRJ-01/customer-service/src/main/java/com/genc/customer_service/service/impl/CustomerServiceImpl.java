package com.genc.customer_service.service.impl;

import com.genc.customer_service.dto.CustomerRequestDTO;
import com.genc.customer_service.dto.CustomerResponseDTO;
import com.genc.customer_service.dto.KycUploadDTO;
import com.genc.customer_service.exception.DuplicateResourceException;
import com.genc.customer_service.exception.InvalidRequestException;
import com.genc.customer_service.exception.ResourceNotFoundException;
import com.genc.customer_service.mapper.CustomerMapper;
import com.genc.customer_service.model.Customer;
import com.genc.customer_service.model.KycStatus;
import com.genc.customer_service.repository.CustomerRepository;
import com.genc.customer_service.security.AuthPrincipal;
import com.genc.customer_service.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    private static final Logger log = LoggerFactory.getLogger(CustomerServiceImpl.class);

    private final CustomerRepository customerRepository;
    private final CustomerMapper customerMapper;

    public CustomerServiceImpl(CustomerRepository customerRepository, CustomerMapper customerMapper) {
        this.customerRepository = customerRepository;
        this.customerMapper = customerMapper;
    }

    @Override
    @Transactional
    public CustomerResponseDTO registerCustomer(CustomerRequestDTO request) {
        log.trace("Entering registerCustomer with request={}", request);
        log.info("Registering customer profile for email '{}'", request.getEmail());
        if (customerRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Customer already exists with email: " + request.getEmail());
        }
        Customer entity = customerMapper.toEntity(request);
        // Attribute ownership from the authenticated JWT (never trust a client-supplied id).
        // Falls back to the request value for older tokens that lack the userId claim.
        Long authUserId = currentUserId();
        if (authUserId != null) {
            entity.setUserId(authUserId);
        }
        if (entity.getUserId() == null) {
            log.warn("Customer profile for '{}' is being created without a linked userId", request.getEmail());
        }
        log.debug("Persisting new customer profile for email '{}'", request.getEmail());
        Customer saved = customerRepository.save(entity);
        log.info("Customer profile created with id {} (userId {})", saved.getId(), saved.getUserId());
        CustomerResponseDTO response = customerMapper.toResponseDTO(saved);
        log.trace("Exiting registerCustomer, returning={}", response);
        return response;
    }

    /** The authenticated user's id, carried on the Authentication details by the JWT filter. */
    private Long currentUserId() {
        AuthPrincipal p = currentPrincipal();
        return p != null ? p.userId() : null;
    }

    /** The authenticated user's email, carried on the Authentication details by the JWT filter. */
    private String currentUserEmail() {
        AuthPrincipal p = currentPrincipal();
        return p != null ? p.email() : null;
    }

    private AuthPrincipal currentPrincipal() {
        var auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getDetails() instanceof AuthPrincipal p) {
            return p;
        }
        return null;
    }

    @Override
    public List<CustomerResponseDTO> getAllCustomers() {
        log.debug("Fetching all customer profiles");
        List<CustomerResponseDTO> customers = customerRepository.findAll().stream()
                .map(customerMapper::toResponseDTO)
                .toList();
        log.debug("Retrieved {} customer profile(s)", customers.size());
        return customers;
    }

    @Override
    public CustomerResponseDTO getCustomerById(Long id) {
        log.trace("Entering getCustomerById with id={}", id);
        return customerMapper.toResponseDTO(findCustomer(id));
    }

    @Override
    @Transactional
    public CustomerResponseDTO getMyCustomer() {
        Long userId = currentUserId();
        String email = currentUserEmail();
        log.trace("Entering getMyCustomer for authenticated userId={}, email={}", userId, email);

        // 1. Preferred: resolve by the linked user id.
        if (userId != null) {
            var byUser = customerRepository.findByUserId(userId);
            if (byUser.isPresent()) {
                return customerMapper.toResponseDTO(byUser.get());
            }
        }

        // 2. Fallback for legacy profiles created before ownership linking: match the
        //    authenticated user's email and backfill the userId so it self-heals.
        if (email != null) {
            var byEmail = customerRepository.findByEmail(email);
            if (byEmail.isPresent()) {
                Customer customer = byEmail.get();
                if (customer.getUserId() == null && userId != null) {
                    customer.setUserId(userId);
                    customer = customerRepository.save(customer);
                    log.info("Backfilled userId {} onto customer {} via email match", userId, customer.getId());
                }
                return customerMapper.toResponseDTO(customer);
            }
        }

        throw new ResourceNotFoundException("No customer profile for current user");
    }

    @Override
    @Transactional
    public CustomerResponseDTO updateCustomer(Long id, CustomerRequestDTO request) {
        log.trace("Entering updateCustomer with id={}, request={}", id, request);
        Customer customer = findCustomer(id);
        customer.setFullName(request.getFullName());
        customer.setPhone(request.getPhone());
        customer.setAddress(request.getAddress());
        customer.setPanNumber(request.getPanNumber());
        customer.setAadhaarNumber(request.getAadhaarNumber());
        log.info("Customer {} profile updated", id);
        return customerMapper.toResponseDTO(customerRepository.save(customer));
    }

    @Override
    @Transactional
    public CustomerResponseDTO uploadKyc(Long id, KycUploadDTO request) {
        log.trace("Entering uploadKyc with id={}", id);
        Customer customer = findCustomer(id);
        customer.setKycDocumentReference(request.getKycDocumentReference());
        customer.setPanNumber(request.getPanNumber());
        customer.setAadhaarNumber(request.getAadhaarNumber());
        // Documents uploaded; status remains PENDING until an officer verifies it.
        customer.setKycStatus(KycStatus.PENDING);
        log.info("KYC documents uploaded for customer {}", id);
        return customerMapper.toResponseDTO(customerRepository.save(customer));
    }

    @Override
    @Transactional
    public CustomerResponseDTO verifyKyc(Long id, KycStatus status) {
        log.trace("Entering verifyKyc with id={}, status={}", id, status);
        Customer customer = findCustomer(id);
        if (customer.getKycDocumentReference() == null) {
            throw new InvalidRequestException("Customer has not uploaded KYC documents yet");
        }
        customer.setKycStatus(status);
        log.info("KYC status for customer {} set to {}", id, status);
        return customerMapper.toResponseDTO(customerRepository.save(customer));
    }

    @Override
    @Transactional
    public CustomerResponseDTO deactivateCustomer(Long id) {
        log.trace("Entering deactivateCustomer with id={}", id);
        Customer customer = findCustomer(id);
        customer.setActive(false);
        log.info("Customer {} deactivated", id);
        return customerMapper.toResponseDTO(customerRepository.save(customer));
    }

    @Override
    @Transactional
    public void deleteCustomer(Long id) {
        log.trace("Entering deleteCustomer with id={}", id);
        Customer customer = findCustomer(id);
        customerRepository.delete(customer);
        log.info("Customer {} deleted", id);
    }

    private Customer findCustomer(Long id) {
        log.debug("Looking up customer by id={}", id);
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + id));
    }
}
