package com.genc.disbursement_service.client;

import com.genc.disbursement_service.dto.LoanResponseDTO;
import com.genc.disbursement_service.dto.LoanStatusUpdateRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client used to fetch approved loan details from Loan Service
 * and to update the loan status after disbursement.
 */
@FeignClient(name = "loan-service")
public interface LoanClient {

    @GetMapping("/loan/{id}")
    LoanResponseDTO getLoanById(@PathVariable("id") Long id);

    /** Marks the loan as DISBURSED in the owning Loan Service (no cross-DB write). */
    @PatchMapping("/loan/{id}/status")
    LoanResponseDTO updateStatus(@PathVariable("id") Long id, @RequestBody LoanStatusUpdateRequest request);
}

