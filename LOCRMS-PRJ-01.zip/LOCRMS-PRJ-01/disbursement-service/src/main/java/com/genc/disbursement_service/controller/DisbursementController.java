package com.genc.disbursement_service.controller;

import com.genc.disbursement_service.dto.DisbursementRequestDTO;
import com.genc.disbursement_service.dto.RepaymentDTO;
import com.genc.disbursement_service.dto.RepaymentStatusUpdateDTO;
import com.genc.disbursement_service.service.DisbursementService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/disbursement")
public class DisbursementController {

    private static final Logger log = LoggerFactory.getLogger(DisbursementController.class);

    private final DisbursementService disbursementService;

    public DisbursementController(DisbursementService disbursementService) {
        this.disbursementService = disbursementService;
    }

    @PostMapping("/disburse")
    public ResponseEntity<List<RepaymentDTO>> disburse(@Valid @RequestBody DisbursementRequestDTO request) {
        log.info("POST /disbursement/disburse for loan {}", request.getLoanId());
        return ResponseEntity.status(HttpStatus.CREATED).body(disbursementService.disburseLoan(request.getLoanId()));
    }

    @GetMapping("/{loanId}/schedule")
    public ResponseEntity<List<RepaymentDTO>> getSchedule(@PathVariable Long loanId) {
        return ResponseEntity.ok(disbursementService.getScheduleForLoan(loanId));
    }

    @GetMapping("/{loanId}/history")
    public ResponseEntity<List<RepaymentDTO>> getHistory(@PathVariable Long loanId) {
        return ResponseEntity.ok(disbursementService.getPaymentHistory(loanId));
    }

    @GetMapping("/repayment/{id}")
    public ResponseEntity<RepaymentDTO> getRepayment(@PathVariable Long id) {
        return ResponseEntity.ok(disbursementService.getRepaymentById(id));
    }

    @PostMapping("/repayment/{id}")
    public ResponseEntity<RepaymentDTO> recordRepayment(@PathVariable Long id) {
        return ResponseEntity.ok(disbursementService.recordRepayment(id));
    }

    @PatchMapping("/repayment/{id}/status")
    public ResponseEntity<RepaymentDTO> updateStatus(@PathVariable Long id,
                                                     @Valid @RequestBody RepaymentStatusUpdateDTO request) {
        return ResponseEntity.ok(disbursementService.updateRepaymentStatus(id, request.getStatus()));
    }

    @PatchMapping("/repayment/{id}/paid")
    public ResponseEntity<RepaymentDTO> markPaid(@PathVariable Long id) {
        return ResponseEntity.ok(disbursementService.markEmiPaid(id));
    }

    /** Exposed for Collection Service to fetch overdue EMI details. */
    @GetMapping("/overdue")
    public ResponseEntity<List<RepaymentDTO>> getOverdue() {
        return ResponseEntity.ok(disbursementService.getOverdueRepayments());
    }
}

