package com.genc.disbursement_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request body sent to Loan Service to change a loan's status
 * (e.g. to DISBURSED after a successful disbursement).
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanStatusUpdateRequest {

    private String status;
    private String remarks;
}

