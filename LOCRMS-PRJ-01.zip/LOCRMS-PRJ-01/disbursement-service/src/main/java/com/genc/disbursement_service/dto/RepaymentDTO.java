package com.genc.disbursement_service.dto;

import com.genc.disbursement_service.model.RepaymentStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RepaymentDTO {

    private Long id;
    private Long loanId;
    private Long customerId;
    private Integer installmentNumber;
    private BigDecimal emiAmount;
    private BigDecimal paidAmount;
    private LocalDate dueDate;
    private LocalDate paidDate;
    private RepaymentStatus status;
}
