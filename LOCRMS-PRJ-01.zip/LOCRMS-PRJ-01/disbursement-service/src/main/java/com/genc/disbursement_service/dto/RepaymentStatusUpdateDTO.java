package com.genc.disbursement_service.dto;

import com.genc.disbursement_service.model.RepaymentStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RepaymentStatusUpdateDTO {

    @NotNull(message = "Status is required")
    private RepaymentStatus status;
}

