package com.genc.disbursement_service.mapper;

import com.genc.disbursement_service.dto.RepaymentDTO;
import com.genc.disbursement_service.model.Repayment;
import org.springframework.stereotype.Component;

@Component
public class RepaymentMapper {

    public RepaymentDTO toDTO(Repayment repayment) {
        return RepaymentDTO.builder()
                .id(repayment.getId())
                .loanId(repayment.getLoanId())
                .customerId(repayment.getCustomerId())
                .installmentNumber(repayment.getInstallmentNumber())
                .emiAmount(repayment.getEmiAmount())
                .paidAmount(repayment.getPaidAmount())
                .dueDate(repayment.getDueDate())
                .paidDate(repayment.getPaidDate())
                .status(repayment.getStatus())
                .build();
    }
}
