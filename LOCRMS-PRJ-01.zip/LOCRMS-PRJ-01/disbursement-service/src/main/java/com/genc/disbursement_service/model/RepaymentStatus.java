package com.genc.disbursement_service.model;

public enum RepaymentStatus {
    PENDING,
    PAID,
    OVERDUE
}

