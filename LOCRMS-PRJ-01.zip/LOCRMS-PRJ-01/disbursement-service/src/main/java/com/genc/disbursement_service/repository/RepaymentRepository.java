package com.genc.disbursement_service.repository;

import com.genc.disbursement_service.model.Repayment;
import com.genc.disbursement_service.model.RepaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface RepaymentRepository extends JpaRepository<Repayment, Long> {

    List<Repayment> findByLoanIdOrderByInstallmentNumberAsc(Long loanId);

    List<Repayment> findByStatus(RepaymentStatus status);

    List<Repayment> findByStatusAndDueDateBefore(RepaymentStatus status, LocalDate date);

    boolean existsByLoanId(Long loanId);
}

