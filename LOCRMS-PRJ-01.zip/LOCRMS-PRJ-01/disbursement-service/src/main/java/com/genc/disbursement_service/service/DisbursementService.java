package com.genc.disbursement_service.service;

import com.genc.disbursement_service.dto.RepaymentDTO;
import com.genc.disbursement_service.model.RepaymentStatus;

import java.util.List;

public interface DisbursementService {

    List<RepaymentDTO> disburseLoan(Long loanId);

    List<RepaymentDTO> getScheduleForLoan(Long loanId);

    RepaymentDTO getRepaymentById(Long id);

    List<RepaymentDTO> getPaymentHistory(Long loanId);

    RepaymentDTO recordRepayment(Long repaymentId);

    RepaymentDTO updateRepaymentStatus(Long id, RepaymentStatus status);

    RepaymentDTO markEmiPaid(Long id);

    List<RepaymentDTO> getOverdueRepayments();
}

