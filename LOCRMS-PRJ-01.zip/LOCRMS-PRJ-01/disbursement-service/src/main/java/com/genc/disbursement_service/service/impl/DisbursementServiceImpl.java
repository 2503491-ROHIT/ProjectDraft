package com.genc.disbursement_service.service.impl;

import com.genc.disbursement_service.client.LoanClient;
import com.genc.disbursement_service.dto.LoanResponseDTO;
import com.genc.disbursement_service.dto.LoanStatusUpdateRequest;
import com.genc.disbursement_service.dto.RepaymentDTO;
import com.genc.disbursement_service.exception.DuplicateResourceException;
import com.genc.disbursement_service.exception.InvalidRequestException;
import com.genc.disbursement_service.exception.ResourceNotFoundException;
import com.genc.disbursement_service.mapper.RepaymentMapper;
import com.genc.disbursement_service.model.Repayment;
import com.genc.disbursement_service.model.RepaymentStatus;
import com.genc.disbursement_service.repository.RepaymentRepository;
import com.genc.disbursement_service.service.DisbursementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.IntStream;

@Service
public class DisbursementServiceImpl implements DisbursementService {

    private static final Logger log = LoggerFactory.getLogger(DisbursementServiceImpl.class);

    private final RepaymentRepository repaymentRepository;
    private final RepaymentMapper repaymentMapper;
    private final LoanClient loanClient;

    public DisbursementServiceImpl(RepaymentRepository repaymentRepository,
                                   RepaymentMapper repaymentMapper,
                                   LoanClient loanClient) {
        this.repaymentRepository = repaymentRepository;
        this.repaymentMapper = repaymentMapper;
        this.loanClient = loanClient;
    }

    @Override
    @Transactional
    public List<RepaymentDTO> disburseLoan(Long loanId) {
        log.trace("Entering disburseLoan with loanId={}", loanId);
        log.info("Disbursing loan {}", loanId);
        if (repaymentRepository.existsByLoanId(loanId)) {
            throw new DuplicateResourceException("Loan already disbursed: " + loanId);
        }

        log.debug("Fetching approved loan {} via Loan Service", loanId);
        LoanResponseDTO loan = fetchApprovedLoan(loanId);
        BigDecimal emi = calculateEmi(loan.getRequestedAmount(), loan.getInterestRate(), loan.getTenureMonths());
        log.debug("Calculated EMI {} for loan {} over {} months", emi, loanId, loan.getTenureMonths());

        List<Repayment> schedule = IntStream.rangeClosed(1, loan.getTenureMonths())
                .mapToObj(installment -> Repayment.builder()
                        .loanId(loan.getId())
                        .customerId(loan.getCustomerId())
                        .installmentNumber(installment)
                        .emiAmount(emi)
                        .dueDate(LocalDate.now().plusMonths(installment))
                        .status(RepaymentStatus.PENDING)
                        .build())
                .toList();

        List<Repayment> saved = repaymentRepository.saveAll(schedule);
        log.info("Generated EMI schedule of {} installments for loan {}", saved.size(), loanId);

        // Update the loan status to DISBURSED in the owning Loan Service (Feign, no cross-DB write).
        try {
            loanClient.updateStatus(loanId, LoanStatusUpdateRequest.builder()
                    .status("DISBURSED")
                    .remarks("Loan disbursed and EMI schedule generated")
                    .build());
            log.info("Loan {} status updated to DISBURSED via Loan Service", loanId);
        } catch (Exception ex) {
            log.error("Failed to update loan {} status to DISBURSED: {}", loanId, ex.getMessage());
            throw new InvalidRequestException("Disbursement recorded but loan status update failed for loan: " + loanId);
        }

        List<RepaymentDTO> response = saved.stream().map(repaymentMapper::toDTO).toList();
        log.trace("Exiting disburseLoan, returning {} installment(s)", response.size());
        return response;
    }

    @Override
    public List<RepaymentDTO> getScheduleForLoan(Long loanId) {
        log.debug("Fetching repayment schedule for loan {}", loanId);
        return repaymentRepository.findByLoanIdOrderByInstallmentNumberAsc(loanId).stream()
                .map(repaymentMapper::toDTO)
                .toList();
    }

    @Override
    public RepaymentDTO getRepaymentById(Long id) {
        log.trace("Entering getRepaymentById with id={}", id);
        return repaymentMapper.toDTO(findRepayment(id));
    }

    @Override
    public List<RepaymentDTO> getPaymentHistory(Long loanId) {
        log.debug("Fetching payment history (PAID installments) for loan {}", loanId);
        return repaymentRepository.findByLoanIdOrderByInstallmentNumberAsc(loanId).stream()
                .filter(repayment -> repayment.getStatus() == RepaymentStatus.PAID)
                .map(repaymentMapper::toDTO)
                .toList();
    }

    @Override
    @Transactional
    public RepaymentDTO recordRepayment(Long repaymentId) {
        log.trace("Entering recordRepayment with repaymentId={}", repaymentId);
        return markEmiPaid(repaymentId);
    }

    @Override
    @Transactional
    public RepaymentDTO updateRepaymentStatus(Long id, RepaymentStatus status) {
        log.trace("Entering updateRepaymentStatus with id={}, status={}", id, status);
        Repayment repayment = findRepayment(id);
        repayment.setStatus(status);
        if (status == RepaymentStatus.PAID) {
            repayment.setPaidDate(LocalDate.now());
        }
        log.info("Repayment {} status updated to {}", id, status);
        return repaymentMapper.toDTO(repaymentRepository.save(repayment));
    }

    @Override
    @Transactional
    public RepaymentDTO markEmiPaid(Long id) {
        log.trace("Entering markEmiPaid with id={}", id);
        Repayment repayment = findRepayment(id);
        if (repayment.getStatus() == RepaymentStatus.PAID) {
            throw new InvalidRequestException("Installment already paid");
        }
        repayment.setStatus(RepaymentStatus.PAID);
        repayment.setPaidDate(LocalDate.now());
        repayment.setPaidAmount(repayment.getEmiAmount());
        log.info("Installment {} of loan {} marked paid", repayment.getInstallmentNumber(), repayment.getLoanId());
        return repaymentMapper.toDTO(repaymentRepository.save(repayment));
    }

    @Override
    @Transactional
    public List<RepaymentDTO> getOverdueRepayments() {
        log.debug("Scanning for overdue repayments as of {}", LocalDate.now());
        // Flag pending installments whose due date has passed as OVERDUE, then return them.
        List<Repayment> newlyOverdue = repaymentRepository
                .findByStatusAndDueDateBefore(RepaymentStatus.PENDING, LocalDate.now());
        newlyOverdue.forEach(repayment -> repayment.setStatus(RepaymentStatus.OVERDUE));
        repaymentRepository.saveAll(newlyOverdue);
        log.debug("Flagged {} newly overdue installment(s)", newlyOverdue.size());

        return repaymentRepository.findByStatus(RepaymentStatus.OVERDUE).stream()
                .map(repaymentMapper::toDTO)
                .toList();
    }

    private LoanResponseDTO fetchApprovedLoan(Long loanId) {
        LoanResponseDTO loan;
        try {
            loan = loanClient.getLoanById(loanId);
            log.debug("Loan {} fetched with status {}", loanId, loan.getStatus());
        } catch (Exception ex) {
            log.error("Failed to fetch loan {}: {}", loanId, ex.getMessage());
            throw new ResourceNotFoundException("Loan not found or unavailable: " + loanId);
        }
        if (!"APPROVED".equalsIgnoreCase(loan.getStatus())) {
            throw new InvalidRequestException("Only approved loans can be disbursed. Current status: " + loan.getStatus());
        }
        return loan;
    }

    /**
     * Standard reducing-balance EMI formula.
     */
    private BigDecimal calculateEmi(BigDecimal principal, BigDecimal annualRate, int tenureMonths) {
        double monthlyRate = annualRate.doubleValue() / 12 / 100;
        double factor = Math.pow(1 + monthlyRate, tenureMonths);
        double emi = principal.doubleValue() * monthlyRate * factor / (factor - 1);
        log.trace("EMI calc: principal={}, annualRate={}, tenure={}, monthlyRate={}", principal, annualRate, tenureMonths, monthlyRate);
        return BigDecimal.valueOf(emi).setScale(2, RoundingMode.HALF_UP);
    }

    private Repayment findRepayment(Long id) {
        log.debug("Looking up repayment by id={}", id);
        return repaymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Repayment not found with id: " + id));
    }
}

