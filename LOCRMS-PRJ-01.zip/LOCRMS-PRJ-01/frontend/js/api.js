/* api.js — REST client for the API Gateway. */
const API_BASE = "http://localhost:8081";

const Token = {
  get: () => localStorage.getItem("locrms_token"),
  set: (t) => localStorage.setItem("locrms_token", t),
  clear: () => localStorage.removeItem("locrms_token"),
};

async function request(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth && Token.get()) headers["Authorization"] = "Bearer " + Token.get();
  const res = await fetch(API_BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });

  if (res.status === 401) {
    Token.clear();
    if (!location.pathname.endsWith("index.html")) location.href = rootPath() + "index.html";
    throw new Error("Session expired. Please log in again.");
  }
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error((data && (data.message || data.error)) || "Request failed (" + res.status + ")");
  return data;
}

const Api = {
  login: (username, password) => request("/auth/login", { method: "POST", auth: false, body: { username, password } }),
  registerCustomer: (p) => request("/auth/register", { method: "POST", auth: false, body: p }),

  users: {
    list: () => request("/admin/users"),
    get: (id) => request(`/admin/users/${id}`),
    create: (p) => request("/admin/users", { method: "POST", body: p }),
    activate: (id) => request(`/admin/users/${id}/activate`, { method: "PATCH" }),
    deactivate: (id) => request(`/admin/users/${id}/deactivate`, { method: "PATCH" }),
    changeRole: (id, role) => request(`/admin/users/${id}/role`, { method: "PATCH", body: { role } }),
    resetPassword: (id, newPassword) => request(`/admin/users/${id}/password`, { method: "PATCH", body: { newPassword } }),
    remove: (id) => request(`/admin/users/${id}`, { method: "DELETE" }),
  },
  customers: {
    list: () => request("/customer"),
    me: () => request("/customer/me"),
    get: (id) => request(`/customer/${id}`),
    register: (p) => request("/customer/register", { method: "POST", body: p }),
    update: (id, p) => request(`/customer/${id}`, { method: "PUT", body: p }),
    uploadKyc: (id, p) => request(`/customer/${id}/kyc`, { method: "POST", body: p }),
    verifyKyc: (id, kycStatus) => request(`/customer/${id}/kyc/verify`, { method: "PATCH", body: { kycStatus } }),
    deactivate: (id) => request(`/customer/${id}/deactivate`, { method: "PATCH" }),
    remove: (id) => request(`/customer/${id}`, { method: "DELETE" }),
  },
  loans: {
    apply: (p) => request("/loan/apply", { method: "POST", body: p }),
    list: () => request("/loan"),
    byStatus: (status) => request(`/loan/status/${status}`),
    get: (id) => request(`/loan/${id}`),
    byCustomer: (cid) => request(`/loan/customer/${cid}`),
    forward: (id, remarks) => request(`/loan/${id}/forward`, { method: "PATCH", body: { remarks } }),
    evaluate: (id, remarks) => request(`/loan/${id}/evaluate`, { method: "PATCH", body: { remarks } }),
    approve: (id, decision) => request(`/loan/${id}/approve`, { method: "PATCH", body: decision }),
    reject: (id, remarks) => request(`/loan/${id}/reject`, { method: "PATCH", body: { remarks } }),
    changeStatus: (id, status, remarks) => request(`/loan/${id}/status`, { method: "PATCH", body: { status, remarks } }),
    remove: (id) => request(`/loan/${id}`, { method: "DELETE" }),
  },
  credit: {
    generate: (p) => request("/credit/generate", { method: "POST", body: p }),
    get: (id) => request(`/credit/${id}`),
    byCustomer: (cid) => request(`/credit/customer/${cid}`),
    latest: (cid) => request(`/credit/customer/${cid}/latest`),
  },
  disbursement: {
    disburse: (loanId) => request("/disbursement/disburse", { method: "POST", body: { loanId } }),
    schedule: (loanId) => request(`/disbursement/${loanId}/schedule`),
    history: (loanId) => request(`/disbursement/${loanId}/history`),
    markPaid: (id) => request(`/disbursement/repayment/${id}/paid`, { method: "PATCH" }),
    overdue: () => request("/disbursement/overdue"),
  },
  collection: {
    scan: () => request("/collection/scan", { method: "POST" }),
    autoAssign: (availableAgentIds) => request("/collection/auto-assign", { method: "POST", body: { availableAgentIds } }),
    assign: (id, agentId) => request(`/collection/${id}/assign`, { method: "POST", body: { agentId } }),
    list: () => request("/collection"),
    get: (id) => request(`/collection/${id}`),
    byAgent: (agentId) => request(`/collection/agent/${agentId}`),
    addRecovery: (id, p) => request(`/collection/${id}/recovery`, { method: "POST", body: p }),
    updateRecoveryStatus: (id, status) => request(`/collection/${id}/recovery-status`, { method: "PATCH", body: { status } }),
    writeOff: (id, remarks) => request(`/collection/${id}/write-off`, { method: "PATCH", body: { remarks } }),
    remove: (id) => request(`/collection/${id}`, { method: "DELETE" }),
  },
};
