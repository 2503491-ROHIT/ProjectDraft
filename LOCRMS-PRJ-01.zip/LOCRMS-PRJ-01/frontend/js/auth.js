/* auth.js — session, roles, guards. */

const Session = {
  save(res) {
    Token.set(res.token);
    localStorage.setItem("locrms_user", JSON.stringify({ id: res.id ?? null, username: res.username, roles: res.roles || [] }));
  },
  user() { try { return JSON.parse(localStorage.getItem("locrms_user")) || null; } catch { return null; } },
  role() { const u = Session.user(); return u && u.roles && u.roles.length ? u.roles[0] : null; },
  userId() { const u = Session.user(); return u ? u.id : null; },
  clear() { Token.clear(); localStorage.removeItem("locrms_user"); _myCustomerId = null; },
};

const ROLE_HOME = {
  ROLE_ADMIN: "pages/admin/dashboard.html",
  ROLE_CUSTOMER: "pages/customer/dashboard.html",
  ROLE_LOAN_OFFICER: "pages/loan-officer/dashboard.html",
  ROLE_CREDIT_ANALYST: "pages/credit-analyst/dashboard.html",
  ROLE_UNDERWRITER: "pages/underwriter/dashboard.html",
  ROLE_COLLECTION_AGENT: "pages/collection-agent/dashboard.html",
};

const ROLE_LABEL = {
  ROLE_ADMIN: "Administrator",
  ROLE_CUSTOMER: "Customer",
  ROLE_LOAN_OFFICER: "Loan Officer",
  ROLE_CREDIT_ANALYST: "Credit Analyst",
  ROLE_UNDERWRITER: "Underwriter",
  ROLE_COLLECTION_AGENT: "Collection Agent",
};

/* which sidebar fragment each role uses */
const ROLE_SIDEBAR = {
  ROLE_ADMIN: "sidebar-admin.html",
  ROLE_CUSTOMER: "sidebar-customer.html",
  ROLE_LOAN_OFFICER: "sidebar-loan-officer.html",
  ROLE_CREDIT_ANALYST: "sidebar-credit-analyst.html",
  ROLE_UNDERWRITER: "sidebar-underwriter.html",
  ROLE_COLLECTION_AGENT: "sidebar-collection-agent.html",
};

function roleHome(role) { return ROLE_HOME[role] || "index.html"; }

/* Guard a page. Accepts a single role string or an array of allowed roles. */
function requireRole(allowed) {
  const role = Session.role();
  if (!Token.get() || !role) { location.href = rootPath() + "index.html"; return false; }
  const list = Array.isArray(allowed) ? allowed : (allowed ? [allowed] : null);
  if (list && !list.includes(role)) { location.href = rootPath() + "unauthorized.html"; return false; }
  return true;
}

/* The customer's own profile id is resolved from the backend each session and
   cached only in memory — it is never written to localStorage. */
let _myCustomerId = null;
function setMyCustomerId(id) { _myCustomerId = id != null ? Number(id) : null; }
function getMyCustomerId() { return _myCustomerId; }

/* Resolve (and cache) the logged-in customer's profile id from the backend.
   Returns null when the user is not a customer or has no profile yet. */
async function ensureMyCustomerId() {
  if (_myCustomerId) return _myCustomerId;
  if (Session.role() !== "ROLE_CUSTOMER") return null;
  try {
    const c = await Api.customers.me();
    _myCustomerId = c && c.id != null ? Number(c.id) : null;
  } catch { _myCustomerId = null; }
  return _myCustomerId;
}
