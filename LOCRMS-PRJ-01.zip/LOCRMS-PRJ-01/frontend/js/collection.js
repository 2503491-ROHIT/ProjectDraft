﻿/* collection.js - collection cases: scan, assign, recovery action, write-off, delete.
   Page may set data-status (PENDING/RECOVERED/WRITTEN_OFF), data-assign="true" (admin),
   data-agent="true" (scope to logged-in agent). Optional elements: #search, #statusFilter, #pager. */
const CollectionUI = {
  cache: [],
  pager: null,
  async load() {
    const body = document.getElementById("collBody");
    const filter = document.body.dataset.status || "";
    const agentScoped = document.body.dataset.agent === "true";
    loadingRow(body, 7);
    try {
      const agentId = Session.userId();
      let cases = (agentScoped && agentId)
        ? await Api.collection.byAgent(agentId)
        : await Api.collection.list();
      if (filter) cases = cases.filter((c) => c.status === filter);
      CollectionUI.cache = cases;
      CollectionUI.apply();
    } catch (e) { messageRow(body, 7, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
  rowHtml(c, canAssign) {
    return `<tr>
      <td>${c.id}</td><td>${c.loanId}</td><td>${c.customerId}</td><td>${fmt.money(c.overdueAmount)}</td>
      <td>${c.daysPastDue ?? "-"}</td><td>${statusBadge(c.status)} ${c.assignedAgentId ? `<span class="badge text-bg-info">Agent #${c.assignedAgentId}</span>` : '<span class="badge text-bg-warning">Unassigned</span>'}</td>
      <td><div class="btn-group btn-group-sm">
        ${canAssign ? `<button class="btn btn-outline-success" onclick="CollectionUI.openAssign(${c.id})" title="Assign to agent"><i class="fa-solid fa-user-plus"></i></button>` : ""}
        <button class="btn btn-outline-primary" onclick="CollectionUI.openRecovery(${c.id})" title="Recovery action"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-outline-dark" onclick="CollectionUI.writeOff(${c.id})" title="Write off"><i class="fa-solid fa-file-circle-xmark"></i></button>
        ${canAssign ? `<button class="btn btn-outline-danger" onclick="CollectionUI.remove(${c.id})" title="Delete"><i class="fa-solid fa-trash"></i></button>` : ""}
      </div></td>
    </tr>`;
  },
  apply() {
    const body = document.getElementById("collBody");
    const canAssign = document.body.dataset.assign === "true";
    const term = (document.getElementById("search")?.value || "").toLowerCase();
    const status = document.getElementById("statusFilter")?.value || "";
    let rows = CollectionUI.cache;
    if (status) rows = rows.filter((c) => c.status === status);
    if (term) rows = rows.filter((c) =>
      [c.id, c.loanId, c.customerId, c.status, c.assignedAgentId].join(" ").toLowerCase().includes(term));
    const draw = (pageRows) => renderRows(body, pageRows, (c) => CollectionUI.rowHtml(c, canAssign), 7, "No collection cases.");
    if (document.getElementById("pager")) {
      if (!CollectionUI.pager) { CollectionUI.pager = new Paginator(rows, 10, draw); CollectionUI.pager.mount("pager"); }
      else { CollectionUI.pager.render = draw; CollectionUI.pager.setRows(rows); }
    } else {
      draw(rows);
    }
  },
  async scan() {
    const btn = document.getElementById("scanBtn"); if (btn) btn.disabled = true;
    try { const flagged = await Api.collection.scan(); toast(`Scan complete - ${flagged.length} case(s) flagged`); CollectionUI.load(); }
    catch (e) { toast(e.message, "danger"); }
    finally { if (btn) btn.disabled = false; }
  },
  openAssign(id) {
    document.getElementById("assignCaseId").value = id;
    document.getElementById("assignAgentId").value = "";
    bootstrap.Modal.getOrCreateInstance(document.getElementById("assignModal")).show();
  },
  async saveAssign() {
    const id = document.getElementById("assignCaseId").value;
    const agentId = Number.parseInt(document.getElementById("assignAgentId").value, 10);
    if (!agentId || agentId < 1) { toast("Enter a valid agent id", "danger"); return; }
    try {
      await Api.collection.assign(id, agentId);
      bootstrap.Modal.getInstance(document.getElementById("assignModal")).hide();
      toast("Case assigned to agent #" + agentId); CollectionUI.load();
    } catch (e) { toast(e.message, "danger"); }
  },
  openRecovery(id) {
    document.getElementById("recId").value = id;
    document.getElementById("recRemarks").value = "";
    bootstrap.Modal.getOrCreateInstance(document.getElementById("recoveryModal")).show();
  },
  async saveRecovery() {
    const id = document.getElementById("recId").value;
    try {
      await Api.collection.addRecovery(id, { status: document.getElementById("recStatus").value, remarks: document.getElementById("recRemarks").value.trim() });
      bootstrap.Modal.getInstance(document.getElementById("recoveryModal")).hide(); toast("Recovery action saved"); CollectionUI.load();
    } catch (e) { toast(e.message, "danger"); }
  },
  async writeOff(id) {
    if (!confirm("Write off collection case #" + id + "?")) return;
    try { await Api.collection.writeOff(id, "Written off by agent"); toast("Case written off"); CollectionUI.load(); }
    catch (e) { toast(e.message, "danger"); }
  },
  async remove(id) {
    if (!confirm("Delete this collection case?")) return;
    try { await Api.collection.remove(id); toast("Case deleted"); CollectionUI.load(); }
    catch (e) { toast(e.message, "danger"); }
  },
};
document.addEventListener("layout:ready", () => {
  if (document.getElementById("collBody")) {
    CollectionUI.load();
    document.getElementById("refreshBtn")?.addEventListener("click", CollectionUI.load);
    document.getElementById("scanBtn")?.addEventListener("click", CollectionUI.scan);
    document.getElementById("recSaveBtn")?.addEventListener("click", CollectionUI.saveRecovery);
    document.getElementById("assignSaveBtn")?.addEventListener("click", CollectionUI.saveAssign);
    document.getElementById("search")?.addEventListener("input", CollectionUI.apply);
    wireSelectFilter("statusFilter", CollectionUI.apply);
  }
});
