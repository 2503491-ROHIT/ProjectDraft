/* credit.js — credit analyst evaluation + lookup (admin gets read-only lookup). */
const CreditUI = {
  initEvaluate() {
    document.getElementById("creditForm")?.addEventListener("submit", CreditUI.generate);
    document.getElementById("lookupBtn")?.addEventListener("click", CreditUI.lookup);
  },
  initLookupOnly() {
    document.getElementById("lookupBtn")?.addEventListener("click", CreditUI.lookup);
  },
  async generate(e) {
    e.preventDefault();
    if (!validateForm(e.target)) return;
    const g = (id) => document.getElementById(id).value.trim();
    try {
      const res = await Api.credit.generate({ customerId: Number(g("cCustomer")), monthlyIncome: Number(g("cIncome")),
        existingObligations: Number(g("cObligations")), requestedAmount: Number(g("cAmount")) });
      toast("Score generated"); CreditUI.show(res);
    } catch (err) { toast(err.message, "danger"); }
  },
  async lookup() {
    const id = document.getElementById("lookupId").value;
    if (!id) return;
    try { CreditUI.show(await Api.credit.latest(id)); }
    catch (e) { document.getElementById("creditResult").innerHTML = `<div class="alert alert-danger mb-0">${escapeHtml(e.message)}</div>`; }
  },
  show(c) {
    const dti = c.monthlyIncome ? (Number(c.existingObligations || 0) / Number(c.monthlyIncome)).toFixed(2) : "-";
    document.getElementById("creditResult").innerHTML = `
      <div class="row text-center g-3 mb-3">
        <div class="col-4"><div class="border rounded p-2"><div class="text-muted small">Bureau</div><div class="h4 mb-0">${c.bureauScore ?? "-"}</div></div></div>
        <div class="col-4"><div class="border rounded p-2"><div class="text-muted small">Internal</div><div class="h4 mb-0">${c.internalScore ?? "-"}</div></div></div>
        <div class="col-4"><div class="border rounded p-2"><div class="text-muted small">Risk Grade</div><div class="h5 mb-0 mt-1">${statusBadge(c.riskGrade)}</div></div></div>
      </div>
      <dl class="row mb-0"><dt class="col-6">Customer ID</dt><dd class="col-6">${c.customerId}</dd>
        <dt class="col-6">Debt-to-Income</dt><dd class="col-6">${dti}</dd>
        <dt class="col-6">Evaluation ID</dt><dd class="col-6">${c.id ?? "-"}</dd></dl>`;
  },
};
document.addEventListener("layout:ready", () => {
  const page = document.body.dataset.page;
  if (page === "analyst-evaluate") CreditUI.initEvaluate();
  else if (page === "admin-credit") CreditUI.initLookupOnly();
});

