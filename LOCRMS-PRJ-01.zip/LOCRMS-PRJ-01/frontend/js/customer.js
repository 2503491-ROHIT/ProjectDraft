/* customer.js — customer self-service pages + admin customer management. */

const CustomerUI = {
  cache: [],
  pager: null,
  myCache: [],
  myPager: null,
  /* ---- Admin: customer list ---- */
  async adminList() {
    const body = document.getElementById("custBody");
    loadingRow(body, 7);
    try {
      CustomerUI.cache = await Api.customers.list();
      CustomerUI.applyAdmin();
    } catch (e) { messageRow(body, 7, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
  custRow(c) {
    return `<tr>
      <td>${c.id}</td><td>${escapeHtml(c.fullName)}</td><td>${escapeHtml(c.email)}</td><td>${escapeHtml(c.phone)}</td>
      <td>${statusBadge(c.kycStatus)}</td>
      <td>${c.active ? '<i class="fa-solid fa-circle-check text-success"></i>' : '<i class="fa-solid fa-circle-xmark text-secondary"></i>'}</td>
      <td><span class="text-muted small">View only</span></td>
    </tr>`;
  },
  applyAdmin() {
    const body = document.getElementById("custBody");
    const term = (document.getElementById("search")?.value || "").toLowerCase();
    const status = document.getElementById("statusFilter")?.value || "";
    let rows = CustomerUI.cache;
    if (status) rows = rows.filter((c) => c.kycStatus === status);
    if (term) rows = rows.filter((c) =>
      [c.id, c.fullName, c.email, c.phone, c.kycStatus].join(" ").toLowerCase().includes(term));
    const draw = (pageRows) => renderRows(body, pageRows, CustomerUI.custRow, 7, "No customers found.");
    if (document.getElementById("pager")) {
      if (!CustomerUI.pager) { CustomerUI.pager = new Paginator(rows, 10, draw); CustomerUI.pager.mount("pager"); }
      else { CustomerUI.pager.render = draw; CustomerUI.pager.setRows(rows); }
    } else {
      draw(rows);
    }
  },

  /* ---- Loan Officer: KYC verification list (no ID typing) ---- */
  async officerKycList() {
    const body = document.getElementById("custBody");
    loadingRow(body, 6);
    try {
      CustomerUI.cache = await Api.customers.list();
      CustomerUI.applyOfficer();
    } catch (e) { messageRow(body, 6, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
  officerRow(c) {
    const actions = c.kycStatus === "PENDING"
      ? `<button class="btn btn-outline-success" onclick="CustomerUI.verifyKyc(${c.id},'VERIFIED')" title="Verify KYC"><i class="fa-solid fa-user-check"></i> Verify</button>
         <button class="btn btn-outline-danger" onclick="CustomerUI.verifyKyc(${c.id},'REJECTED')" title="Reject KYC"><i class="fa-solid fa-ban"></i> Reject</button>`
      : '<span class="text-muted small">No action</span>';
    return `<tr>
      <td>${c.id}</td><td>${escapeHtml(c.fullName)}</td><td>${escapeHtml(c.email)}</td><td>${escapeHtml(c.phone)}</td>
      <td>${statusBadge(c.kycStatus)}</td>
      <td><div class="btn-group btn-group-sm">${actions}</div></td>
    </tr>`;
  },
  applyOfficer() {
    const body = document.getElementById("custBody");
    const term = (document.getElementById("search")?.value || "").toLowerCase();
    const status = document.getElementById("statusFilter")?.value ?? "PENDING";
    let rows = CustomerUI.cache;
    if (status) rows = rows.filter((c) => c.kycStatus === status);
    if (term) rows = rows.filter((c) =>
      [c.id, c.fullName, c.email, c.phone, c.kycStatus].join(" ").toLowerCase().includes(term));
    const draw = (pageRows) => renderRows(body, pageRows, CustomerUI.officerRow, 6, "No customers found.");
    if (document.getElementById("pager")) {
      if (!CustomerUI.pager) { CustomerUI.pager = new Paginator(rows, 10, draw); CustomerUI.pager.mount("pager"); }
      else { CustomerUI.pager.render = draw; CustomerUI.pager.setRows(rows); }
    } else {
      draw(rows);
    }
  },
  async verifyKyc(id, decision) {
    try {
      await Api.customers.verifyKyc(id, decision);
      toast("KYC " + decision.toLowerCase());
      CustomerUI.officerKycList();
    } catch (e) { toast(e.message, "danger"); }
  },

  /* ---- Customer: profile + KYC ---- */
  // Auto-generate a unique KYC document reference (no manual entry).
  genDocRef() {
    const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
    const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
    return `KYC-${stamp}-${rand}`;
  },
  // Show a reference in #kycDoc: reuse an existing one, else keep current, else generate a fresh one.
  ensureDocRef(existing) {
    const el = document.getElementById("kycDoc");
    if (!el) return;
    el.value = existing || el.value || CustomerUI.genDocRef();
    el.readOnly = true;
  },
  async profilePrefill() {
    const cid = await ensureMyCustomerId();
    if (!cid) return;
    const c = await Api.customers.get(cid).catch(() => null);
    if (!c) return;
    const setv = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ""; };
    setv("fullName", c.fullName); setv("email", c.email); setv("phone", c.phone);
    setv("pan", c.panNumber); setv("address", c.address); setv("aadhaar", c.aadhaarNumber);
    setv("kycPan", c.panNumber); setv("kycAadhaar", c.aadhaarNumber);
    CustomerUI.ensureDocRef(c.kycDocumentReference);
    const ks = document.getElementById("kycStatus"); if (ks) ks.innerHTML = statusBadge(c.kycStatus);
    const lbl = document.getElementById("profileBtnLabel"); if (lbl) lbl.textContent = "Update";
    const kbtn = document.getElementById("kycBtn"); if (kbtn) kbtn.disabled = false;
  },
  async saveProfile(e) {
    e.preventDefault();
    if (!validateForm(e.target)) return;
    const g = (id) => document.getElementById(id).value.trim();
    const payload = { fullName: g("fullName"), email: g("email"), phone: g("phone"),
      address: g("address"), panNumber: g("pan").toUpperCase() || null, aadhaarNumber: g("aadhaar") || null };
    const cid = await ensureMyCustomerId();
    try {
      if (cid) {
        await Api.customers.update(cid, payload);
      } else {
        // New profile: ownership (userId) is attributed server-side from the JWT.
        const saved = await Api.customers.register(payload);
        setMyCustomerId(saved.id);
      }
      toast("Profile saved"); CustomerUI.profilePrefill();
    } catch (err) { toast(err.message, "danger"); }
  },
  async uploadKyc(e) {
    e.preventDefault();
    const cid = await ensureMyCustomerId();
    if (!cid) { toast("Create your profile first", "warning"); return; }
    if (!validateForm(e.target)) return;
    const g = (id) => document.getElementById(id).value.trim();
    try {
      await Api.customers.uploadKyc(cid, { kycDocumentReference: g("kycDoc"), panNumber: g("kycPan").toUpperCase(), aadhaarNumber: g("kycAadhaar") });
      toast("KYC uploaded — awaiting verification"); CustomerUI.profilePrefill();
    } catch (err) { toast(err.message, "danger"); }
  },

  /* ---- Customer: apply for loan ---- */
  async initApply() {
    const cid = await ensureMyCustomerId();
    if (!cid) { document.getElementById("noProfile")?.classList.remove("d-none"); document.getElementById("formCard")?.classList.add("d-none"); return; }
    document.getElementById("loanForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!validateForm(e.target)) return;
      const g = (id) => document.getElementById(id).value.trim();
      const btn = document.getElementById("applyBtn"); btn.disabled = true;
      try {
        await Api.loans.apply({ customerId: Number(cid), loanType: g("loanType"), requestedAmount: Number(g("amount")),
          tenureMonths: Number(g("tenure")), monthlyIncome: Number(g("income")), purpose: g("purpose") });
        toast("Application submitted"); setTimeout(() => location.href = "my-applications.html", 800);
      } catch (err) { toast(err.message, "danger"); btn.disabled = false; }
    });
  },

  /* ---- Customer: my applications ---- */
  async myApplications() {
    const cid = await ensureMyCustomerId();
    if (!cid) { document.getElementById("noProfile")?.classList.remove("d-none"); document.getElementById("tableCard")?.classList.add("d-none"); return; }
    const body = document.getElementById("myLoansBody");
    loadingRow(body, 8);
    try {
      const loans = await Api.loans.byCustomer(cid);
      renderRows(body, loans, (l) => `
        <tr>
          <td>${l.id}</td><td>${escapeHtml(l.loanType)}</td><td>${fmt.money(l.requestedAmount)}</td>
          <td>${l.tenureMonths || "-"} mo</td><td>${l.interestRate != null ? l.interestRate + "%" : "-"}</td>
          <td>${statusBadge(l.riskGrade)}</td><td>${statusBadge(l.status)}</td>
          <td>${l.status === "APPROVED" ? `<button class="btn btn-sm btn-outline-primary" onclick="CustomerUI.schedule(${l.id})"><i class="fa-solid fa-calendar-days"></i></button>` : "-"}</td>
        </tr>`, 8, "You have no applications yet.");
    } catch (e) { messageRow(body, 8, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
  async schedule(loanId) {
    const body = document.getElementById("emiBody");
    body.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary"></div></div>';
    bootstrap.Modal.getOrCreateInstance(document.getElementById("emiModal")).show();
    try {
      const rows = await Api.disbursement.schedule(loanId);
      body.innerHTML = rows.length ? `<div class="table-responsive"><table class="table table-sm table-striped">
        <thead><tr><th>#</th><th>Due Date</th><th>EMI</th><th>Status</th></tr></thead>
        <tbody>${rows.map(r => `<tr><td>${r.installmentNumber}</td><td>${fmt.date(r.dueDate)}</td><td>${fmt.money(r.emiAmount)}</td><td>${statusBadge(r.status)}</td></tr>`).join("")}</tbody></table></div>`
        : '<p class="text-muted mb-0">No schedule yet — loan not disbursed.</p>';
    } catch (e) { body.innerHTML = `<div class="alert alert-danger mb-0">${escapeHtml(e.message)}</div>`; }
  },

  /* ---- Customer: credit score ---- */
  async creditScore() {
    const cid = await ensureMyCustomerId();
    const box = document.getElementById("scoreBox");
    if (!cid) { box.innerHTML = '<div class="alert alert-info mb-0">Complete your profile first.</div>'; return; }
    try {
      const c = await Api.credit.latest(cid);
      box.innerHTML = `<div class="row text-center g-3">
        <div class="col-4"><div class="border rounded p-3"><div class="text-muted small">Bureau</div><div class="h3 mb-0">${c.bureauScore ?? "-"}</div></div></div>
        <div class="col-4"><div class="border rounded p-3"><div class="text-muted small">Internal</div><div class="h3 mb-0">${c.internalScore ?? "-"}</div></div></div>
        <div class="col-4"><div class="border rounded p-3"><div class="text-muted small">Risk</div><div class="h5 mb-0 mt-2">${statusBadge(c.riskGrade)}</div></div></div>
      </div>`;
    } catch { box.innerHTML = '<div class="alert alert-warning mb-0">No credit evaluation found yet.</div>'; }
  },
};

document.addEventListener("layout:ready", () => {
  switch (document.body.dataset.page) {
    case "admin-customers":
      CustomerUI.adminList();
      document.getElementById("refreshBtn")?.addEventListener("click", CustomerUI.adminList);
      document.getElementById("search")?.addEventListener("input", CustomerUI.applyAdmin);
      wireSelectFilter("statusFilter", CustomerUI.applyAdmin);
      break;
    case "officer-kyc":
      CustomerUI.officerKycList();
      document.getElementById("refreshBtn")?.addEventListener("click", CustomerUI.officerKycList);
      document.getElementById("search")?.addEventListener("input", CustomerUI.applyOfficer);
      wireSelectFilter("statusFilter", CustomerUI.applyOfficer);
      break;
    case "customer-profile":
      document.getElementById("profileForm")?.addEventListener("submit", CustomerUI.saveProfile);
      document.getElementById("kycForm")?.addEventListener("submit", CustomerUI.uploadKyc);
      // Seed an auto-generated reference immediately (profilePrefill overrides it if one already exists).
      CustomerUI.ensureDocRef(null);
      document.getElementById("kycDocCopy")?.addEventListener("click", () => {
        const el = document.getElementById("kycDoc");
        if (el?.value) { navigator.clipboard?.writeText(el.value); toast("Reference copied"); }
      });
      CustomerUI.profilePrefill();
      break;
    case "customer-apply": CustomerUI.initApply(); break;
    case "customer-my-applications":
      CustomerUI.myApplications();
      document.getElementById("refreshBtn")?.addEventListener("click", CustomerUI.myApplications);
      document.getElementById("search")?.addEventListener("input", CustomerUI.applyMy);
      wireSelectFilter("statusFilter", CustomerUI.applyMy);
      break;
    case "customer-credit-score": CustomerUI.creditScore(); break;
  }
});

// Safety net: seed the auto-generated KYC reference as soon as the DOM is ready,
// independent of the layout:ready event (covers slow chrome / cached loads).
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("kycDoc")) CustomerUI.ensureDocRef(null);
});
