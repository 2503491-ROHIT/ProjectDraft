/* dashboard.js — live stat cards for every role dashboard.
   Fills elements by id; pages provide the card skeletons in HTML. */

const set = (id, v) => { const el = document.getElementById(id); if (el) el.innerHTML = v; };
const cnt = (a, fn) => (a || []).filter(fn).length;
const tot = (a, fn) => (a || []).reduce((s, x) => s + (Number(fn(x)) || 0), 0);

const Dashboards = {
  async admin() {
    const [users, customers, loans, collections] = await Promise.all([
      Api.users.list().catch(() => []), Api.customers.list().catch(() => []),
      Api.loans.list().catch(() => []), Api.collection.list().catch(() => []),
    ]);
    set("statUsers", fmt.num(users.length));
    set("statCustomers", fmt.num(customers.length));
    set("statLoans", fmt.num(loans.length));
    set("statApproved", fmt.num(cnt(loans, l => l.status === "APPROVED")));
    set("statRejected", fmt.num(cnt(loans, l => l.status === "REJECTED")));
    set("statReview", fmt.num(cnt(loans, l => l.status === "UNDER_REVIEW")));
    set("statCollections", fmt.num(collections.length));
    set("statAmount", fmt.money(tot(loans.filter(l => l.status === "APPROVED"), l => l.requestedAmount)));
  },

  async customer() {
    const u = Session.user();
    set("welcomeName", u ? escapeHtml(u.username) : "");
    const cid = await ensureMyCustomerId();
    if (!cid) { document.getElementById("noProfile")?.classList.remove("d-none"); document.getElementById("cards")?.classList.add("d-none"); return; }
    const [customer, loans, credit] = await Promise.all([
      Api.customers.get(cid).catch(() => null), Api.loans.byCustomer(cid).catch(() => []), Api.credit.latest(cid).catch(() => null),
    ]);
    const active = (loans || []).find(l => l.status === "APPROVED");
    set("cKyc", customer ? statusBadge(customer.kycStatus) : "-");
    set("cApps", fmt.num((loans || []).length));
    set("cActive", active ? fmt.money(active.requestedAmount) : "None");
    set("cScore", credit ? credit.internalScore : "N/A");
  },

  async officer() {
    const loans = await Api.loans.list().catch(() => []);
    set("statTotal", fmt.num(loans.length));
    // New applications waiting for the Loan Officer (eligibility + forward).
    set("statReview", fmt.num(cnt(loans, l => l.status === "SUBMITTED")));
    // Approved by the Underwriter, waiting for the Loan Officer to disburse.
    set("statApproved", fmt.num(cnt(loans, l => l.status === "APPROVED")));
    // Recently disbursed by the Loan Officer.
    set("statRejected", fmt.num(cnt(loans, l => l.status === "DISBURSED")));
    set("statDisbursed", fmt.num(cnt(loans, l => l.status === "DISBURSED")));
  },

  async analyst() {
    const loans = await Api.loans.list().catch(() => []);
    // Forwarded by the Loan Officer, waiting for credit evaluation.
    set("statPending", fmt.num(cnt(loans, l => l.status === "UNDER_REVIEW")));
    set("statHigh", fmt.num(cnt(loans, l => l.riskGrade === "HIGH")));
    set("statMedium", fmt.num(cnt(loans, l => l.riskGrade === "MEDIUM")));
    set("statLow", fmt.num(cnt(loans, l => l.riskGrade === "LOW")));
  },

  async underwriter() {
    const loans = await Api.loans.list().catch(() => []);
    // Credit-evaluated applications awaiting the underwriter's final decision.
    set("statAwaiting", fmt.num(cnt(loans, l => l.status === "CREDIT_EVALUATED")));
    set("statApproved", fmt.num(cnt(loans, l => l.status === "APPROVED")));
    set("statRejected", fmt.num(cnt(loans, l => l.status === "REJECTED")));
    set("statSanctioned", fmt.money(tot(loans.filter(l => l.status === "APPROVED"), l => l.requestedAmount)));
  },

  async disbursement() {
    const [loans, overdue] = await Promise.all([Api.loans.list().catch(() => []), Api.disbursement.overdue().catch(() => [])]);
    const approved = loans.filter(l => l.status === "APPROVED");
    set("statPending", fmt.num(approved.length));
    set("statDisbursed", fmt.money(tot(approved, l => l.requestedAmount)));
    set("statOverdue", fmt.num((overdue || []).length));
  },

  async collection() {
    const [cases, overdue] = await Promise.all([Api.collection.list().catch(() => []), Api.disbursement.overdue().catch(() => [])]);
    set("statCases", fmt.num(cases.length));
    set("statPending", fmt.num(cnt(cases, c => c.status === "PENDING")));
    set("statRecovered", fmt.num(cnt(cases, c => c.status === "RECOVERED")));
    set("statOverdue", fmt.num((overdue || []).length));
  },
};

document.addEventListener("layout:ready", () => {
  const map = {
    "admin-dashboard": Dashboards.admin, "customer-dashboard": Dashboards.customer,
    "officer-dashboard": Dashboards.officer, "analyst-dashboard": Dashboards.analyst,
    "underwriter-dashboard": Dashboards.underwriter,
    "collection-dashboard": Dashboards.collection,
  };
  const fn = map[document.body.dataset.page];
  if (fn) fn();
});
