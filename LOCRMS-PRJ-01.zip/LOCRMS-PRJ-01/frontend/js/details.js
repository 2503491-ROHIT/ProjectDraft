﻿/* details.js - lookup, detail, report and settings pages, dispatched by <body data-page>.
   Lookup pages provide #dInput + #dBtn + #dResult; no-input pages just provide #dResult. */
const DetailsUI = {
  el(id) { return document.getElementById(id); },
  result(html) { const r = DetailsUI.el("dResult"); if (r) r.innerHTML = html; },
  err(msg) { DetailsUI.result(`<div class="alert alert-danger mb-0">${escapeHtml(msg)}</div>`); },
  spin() { DetailsUI.result('<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>'); },
  dl(rows) {
    return `<div class="card shadow-sm"><div class="card-body"><dl class="row mb-0">${rows.map(([k, v]) => `<dt class="col-sm-4">${k}</dt><dd class="col-sm-8">${v}</dd>`).join("")}</dl></div></div>`;
  },
  input() { return (DetailsUI.el("dSelect")?.value || DetailsUI.el("dInput")?.value || "").trim(); },
  async loan() {
    const id = DetailsUI.input(); if (!id) return;
    DetailsUI.spin();
    try {
      const l = await Api.loans.get(id);
      DetailsUI.result(DetailsUI.dl([
        ["Application ID", l.id], ["Customer ID", l.customerId], ["Loan Type", escapeHtml(l.loanType)],
        ["Requested Amount", fmt.money(l.requestedAmount)], ["Tenure", (l.tenureMonths || "-") + " months"],
        ["Interest Rate", l.interestRate != null ? l.interestRate + "%" : "-"], ["Credit Score", l.creditScore ?? "-"],
        ["Risk Grade", statusBadge(l.riskGrade)], ["Status", statusBadge(l.status)], ["Remarks", escapeHtml(l.decisionRemarks || "-")],
      ]));
    } catch (e) { DetailsUI.err(e.message); }
  },
  async customer() {
    const id = DetailsUI.input(); if (!id) return;
    DetailsUI.spin();
    try {
      const c = await Api.customers.get(id);
      // Only a Loan Officer may verify KYC, and only while it is PENDING.
      let actions = "";
      if (c.kycStatus === "PENDING" && Session.role() === "ROLE_LOAN_OFFICER") {
        actions = `<div class="mt-3 d-flex gap-2">
          <button class="btn btn-success" onclick="DetailsUI.verifyKyc(${c.id},'VERIFIED')"><i class="fa-solid fa-user-check me-1"></i>Verify KYC</button>
          <button class="btn btn-outline-danger" onclick="DetailsUI.verifyKyc(${c.id},'REJECTED')"><i class="fa-solid fa-ban me-1"></i>Reject KYC</button></div>`;
      }
      DetailsUI.result(DetailsUI.dl([
        ["Customer ID", c.id], ["Full Name", escapeHtml(c.fullName)], ["Email", escapeHtml(c.email)],
        ["Phone", escapeHtml(c.phone)], ["Address", escapeHtml(c.address || "-")], ["PAN", escapeHtml(c.panNumber || "-")],
        ["Aadhaar", escapeHtml(c.aadhaarNumber || "-")], ["KYC Status", statusBadge(c.kycStatus)],
        ["Account", c.active ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Inactive</span>'],
      ]) + actions);
    } catch (e) { DetailsUI.err(e.message); }
  },
  async verifyKyc(id, decision) {
    try {
      await Api.customers.verifyKyc(id, decision);
      toast("KYC " + decision.toLowerCase());
      const sel = DetailsUI.el("dSelect");
      if (sel) sel.value = id;
      else if (DetailsUI.el("dInput")) DetailsUI.el("dInput").value = id;
      DetailsUI.customer();
    } catch (e) { toast(e.message, "danger"); }
  },
  async user() {
    const id = DetailsUI.input(); if (!id) return;
    DetailsUI.spin();
    try {
      const u = await Api.users.get(id);
      DetailsUI.result(DetailsUI.dl([
        ["User ID", u.id], ["Username", escapeHtml(u.username)], ["Email", escapeHtml(u.email)],
        ["Roles", (u.roles || []).map(r => `<span class="badge text-bg-light border">${escapeHtml(r)}</span>`).join(" ")],
        ["Status", u.active ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Inactive</span>'],
      ]));
    } catch (e) { DetailsUI.err(e.message); }
  },
  async credit() {
    const id = DetailsUI.input(); if (!id) return;
    DetailsUI.spin();
    try {
      const c = await Api.credit.latest(id);
      const dti = c.monthlyIncome ? (Number(c.existingObligations || 0) / Number(c.monthlyIncome)).toFixed(2) : "-";
      DetailsUI.result(`<div class="card shadow-sm"><div class="card-body">
        <div class="row text-center g-3 mb-3">
          <div class="col-4"><div class="border rounded p-3"><div class="text-muted small">Bureau Score</div><div class="h3 mb-0">${c.bureauScore ?? "-"}</div></div></div>
          <div class="col-4"><div class="border rounded p-3"><div class="text-muted small">Internal Score</div><div class="h3 mb-0">${c.internalScore ?? "-"}</div></div></div>
          <div class="col-4"><div class="border rounded p-3"><div class="text-muted small">Risk Grade</div><div class="h5 mb-0 mt-2">${statusBadge(c.riskGrade)}</div></div></div>
        </div>
        <dl class="row mb-0">
          <dt class="col-sm-4">Customer ID</dt><dd class="col-sm-8">${c.customerId}</dd>
          <dt class="col-sm-4">Monthly Income</dt><dd class="col-sm-8">${c.monthlyIncome != null ? fmt.money(c.monthlyIncome) : "-"}</dd>
          <dt class="col-sm-4">Existing Obligations</dt><dd class="col-sm-8">${c.existingObligations != null ? fmt.money(c.existingObligations) : "-"}</dd>
          <dt class="col-sm-4">Debt-to-Income</dt><dd class="col-sm-8">${dti}</dd>
          <dt class="col-sm-4">Evaluation ID</dt><dd class="col-sm-8">${c.id ?? "-"}</dd>
        </dl></div></div>`);
    } catch (e) { DetailsUI.err("No credit evaluation found for this customer."); }
  },
  scheduleTable(rows, withPaid) {
    if (!rows.length) return '<div class="alert alert-info mb-0">No schedule found. The loan may not be disbursed yet.</div>';
    const head = withPaid ? "<th>#</th><th>Due Date</th><th>EMI</th><th>Paid Date</th><th>Status</th>" : "<th>#</th><th>Due Date</th><th>EMI</th><th>Status</th>";
    const body = rows.map(r => withPaid
      ? `<tr><td>${r.installmentNumber}</td><td>${fmt.date(r.dueDate)}</td><td>${fmt.money(r.emiAmount)}</td><td>${fmt.date(r.paidDate)}</td><td>${statusBadge(r.status)}</td></tr>`
      : `<tr><td>${r.installmentNumber}</td><td>${fmt.date(r.dueDate)}</td><td>${fmt.money(r.emiAmount)}</td><td>${statusBadge(r.status)}</td></tr>`).join("");
    return `<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead class="table-light"><tr>${head}</tr></thead><tbody>${body}</tbody></table></div></div>`;
  },
  async emi() {
    const id = DetailsUI.input(); if (!id) return;
    DetailsUI.spin();
    try { DetailsUI.result(DetailsUI.scheduleTable(await Api.disbursement.schedule(id), false)); }
    catch (e) { DetailsUI.err(e.message); }
  },
  async history() {
    const id = DetailsUI.input(); if (!id) return;
    DetailsUI.spin();
    try { DetailsUI.result(DetailsUI.scheduleTable(await Api.disbursement.history(id), true)); }
    catch (e) { DetailsUI.err(e.message); }
  },
  async disburse() {
    const id = DetailsUI.input(); if (!id) return;
    if (!confirm("Disburse loan #" + id + " and generate the EMI schedule?")) return;
    DetailsUI.spin();
    try {
      const rows = await Api.disbursement.disburse(id);
      toast("Loan disbursed - EMI schedule generated");
      DetailsUI.result(DetailsUI.scheduleTable(rows, false));
    } catch (e) { DetailsUI.err(e.message); }
  },
  async eligibility() {
    const id = DetailsUI.input(); if (!id) return;
    DetailsUI.spin();
    try {
      const c = await Api.customers.get(id);
      let credit = null; try { credit = await Api.credit.latest(id); } catch { /* none yet */ }
      const eligible = c.active && c.kycStatus === "VERIFIED";
      const verdict = eligible
        ? '<span class="badge text-bg-success">Eligible to proceed</span>'
        : '<span class="badge text-bg-danger">Not eligible</span>';
      DetailsUI.result(DetailsUI.dl([
        ["Customer ID", c.id], ["Full Name", escapeHtml(c.fullName)],
        ["Account", c.active ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Inactive</span>'],
        ["KYC Status", statusBadge(c.kycStatus)],
        ["Latest Internal Score", credit ? credit.internalScore : "Not evaluated"],
        ["Risk Grade", credit ? statusBadge(credit.riskGrade) : "-"],
        ["Eligibility", verdict],
      ]));
    } catch (e) { DetailsUI.err(e.message); }
  },
  async reports() {
    DetailsUI.spin();
    try {
      const [loans, customers, collections, users] = await Promise.all([
        Api.loans.list().catch(() => []), Api.customers.list().catch(() => []),
        Api.collection.list().catch(() => []), Api.users.list().catch(() => []),
      ]);
      const cnt = (a, f) => a.filter(f).length;
      const sum = (a, f) => a.reduce((s, x) => s + (Number(f(x)) || 0), 0);
      DetailsUI.result(`
        <div class="row g-3 mb-3">
          <div class="col-sm-6 col-xl-3"><div class="card stat-card shadow-sm h-100"><div class="card-body"><div class="text-muted small text-uppercase">Total Applications</div><div class="stat-value">${fmt.num(loans.length)}</div></div></div></div>
          <div class="col-sm-6 col-xl-3"><div class="card stat-card shadow-sm h-100" style="border-left-color:#198754"><div class="card-body"><div class="text-muted small text-uppercase">Approved Amount</div><div class="stat-value">${fmt.money(sum(loans.filter(l => l.status === "APPROVED"), l => l.requestedAmount))}</div></div></div></div>
          <div class="col-sm-6 col-xl-3"><div class="card stat-card shadow-sm h-100" style="border-left-color:#0dcaf0"><div class="card-body"><div class="text-muted small text-uppercase">Customers</div><div class="stat-value">${fmt.num(customers.length)}</div></div></div></div>
          <div class="col-sm-6 col-xl-3"><div class="card stat-card shadow-sm h-100" style="border-left-color:#dc3545"><div class="card-body"><div class="text-muted small text-uppercase">Collection Cases</div><div class="stat-value">${fmt.num(collections.length)}</div></div></div></div>
        </div>
        <div class="card shadow-sm"><div class="card-body"><h6 class="fw-bold">Applications by Status</h6>
        <dl class="row mb-0">
          <dt class="col-sm-4">Submitted</dt><dd class="col-sm-8">${cnt(loans, l => l.status === "SUBMITTED")}</dd>
          <dt class="col-sm-4">Under Review</dt><dd class="col-sm-8">${cnt(loans, l => l.status === "UNDER_REVIEW")}</dd>
          <dt class="col-sm-4">Approved</dt><dd class="col-sm-8">${cnt(loans, l => l.status === "APPROVED")}</dd>
          <dt class="col-sm-4">Rejected</dt><dd class="col-sm-8">${cnt(loans, l => l.status === "REJECTED")}</dd>
          <dt class="col-sm-4">Disbursed</dt><dd class="col-sm-8">${cnt(loans, l => l.status === "DISBURSED")}</dd>
          <dt class="col-sm-4">Registered Staff/Users</dt><dd class="col-sm-8">${users.length}</dd>
        </dl></div></div>`);
    } catch (e) { DetailsUI.err(e.message); }
  },
  async roles() {
    DetailsUI.spin();
    try {
      const users = await Api.users.list();
      const counts = {};
      users.forEach(u => (u.roles || []).forEach(r => counts[r] = (counts[r] || 0) + 1));
      const rows = Object.keys(counts).sort().map(r => `<tr><td><span class="badge text-bg-light border">${escapeHtml(r)}</span></td><td>${counts[r]}</td></tr>`).join("");
      DetailsUI.result(`<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
        <thead class="table-light"><tr><th>Role</th><th>Users</th></tr></thead><tbody>${rows || '<tr><td colspan="2" class="text-center text-muted">No users.</td></tr>'}</tbody></table></div></div>`);
    } catch (e) { DetailsUI.err(e.message); }
  },
  settings() {
    const u = Session.user();
    const role = Session.role();
    DetailsUI.result(DetailsUI.dl([
      ["Signed in as", u ? escapeHtml(u.username) : "-"],
      ["User ID", u && u.id != null ? u.id : "-"],
      ["Role", ROLE_LABEL[role] || role || "-"],
      ["API Gateway", escapeHtml(API_BASE)],
      ["Session", '<span class="badge text-bg-success">Active</span>'],
    ]) + '<div class="alert alert-info mt-3 mb-0"><i class="fa-solid fa-circle-info me-2"></i>Account changes (password, profile) are managed by your administrator.</div>');
  },
};
document.addEventListener("layout:ready", () => {
  const page = document.body.dataset.page;
  const lookups = {
    "lookup-loan": DetailsUI.loan, "lookup-customer": DetailsUI.customer, "lookup-user": DetailsUI.user,
    "lookup-credit": DetailsUI.credit, "lookup-emi": DetailsUI.emi, "lookup-history": DetailsUI.history,
    "disburse-loan": DetailsUI.disburse, "eligibility": DetailsUI.eligibility,
  };

  // Source lists for the searchable dropdown (#dSelect), so users pick instead of typing an ID.
  const loanOpt = (l) => [l.id, `#${l.id} · ${l.loanType} · ${fmt.money(l.requestedAmount)} · ${l.status}`];
  const custOpt = (c) => [c.id, `#${c.id} · ${c.fullName} (${c.kycStatus})`];
  const userOpt = (u) => [u.id, `#${u.id} · ${u.username}`];
  const myLoans = async (filter) => {
    if (Session.role() === "ROLE_CUSTOMER") {
      const cid = await ensureMyCustomerId();
      if (!cid) return [];
      let rows = await Api.loans.byCustomer(cid);
      return (filter ? rows.filter(filter) : rows).map(loanOpt);
    }
    let rows = await Api.loans.list();
    return (filter ? rows.filter(filter) : rows).map(loanOpt);
  };
  const sources = {
    "lookup-loan": () => myLoans(null),
    "lookup-customer": async () => (await Api.customers.list()).map(custOpt),
    "lookup-user": async () => (await Api.users.list()).map(userOpt),
    "lookup-credit": async () => (await Api.customers.list()).map(custOpt),
    "lookup-emi": () => myLoans(null),
    "lookup-history": () => myLoans(null),
    "disburse-loan": async () => (await Api.loans.list()).filter((l) => l.status === "APPROVED").map(loanOpt),
    "eligibility": async () => (await Api.customers.list()).map(custOpt),
  };

  async function populateSelect(sel) {
    // disburse-loan must not auto-run (it confirms+disburses); user clicks the button instead.
    const autoRun = page !== "disburse-loan";
    try {
      const opts = await sources[page]();
      sel.innerHTML = opts.length
        ? opts.map(([v, label]) => `<option value="${v}">${escapeHtml(String(label))}</option>`).join("")
        : '<option value="">No records available</option>';
      sel.addEventListener("change", () => { if (sel.value) lookups[page](); });
      if (autoRun && opts.length) lookups[page]();
    } catch (e) { DetailsUI.err(e.message); }
  }

  if (lookups[page]) {
    const sel = DetailsUI.el("dSelect");
    if (sel && sources[page]) populateSelect(sel);
    DetailsUI.el("dBtn")?.addEventListener("click", lookups[page]);
    DetailsUI.el("dInput")?.addEventListener("keydown", (e) => { if (e.key === "Enter") lookups[page](); });
  } else if (page === "reports") { DetailsUI.reports(); }
  else if (page === "roles-summary") { DetailsUI.roles(); }
  else if (page === "settings") { DetailsUI.settings(); }
});
