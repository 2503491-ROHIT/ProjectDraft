/* disbursement.js — disburse approved loans, view EMI schedule & history. */
const DisbUI = {
  /* pending disbursements = approved loans */
  async pending() {
    const body = document.getElementById("disbBody");
    loadingRow(body, 6);
    try {
      const loans = (await Api.loans.list()).filter((l) => l.status === "APPROVED");
      renderRows(body, loans, (l) => `
        <tr>
          <td>${l.id}</td><td>${l.customerId}</td><td>${escapeHtml(l.loanType)}</td>
          <td>${fmt.money(l.requestedAmount)}</td><td>${l.tenureMonths || "-"} mo</td>
          <td><div class="btn-group btn-group-sm">
            <button class="btn btn-outline-info" onclick="DisbUI.disburse(${l.id})" title="Disburse"><i class="fa-solid fa-money-bill-transfer"></i></button>
            <button class="btn btn-outline-primary" onclick="DisbUI.viewSchedule(${l.id})" title="EMI schedule"><i class="fa-solid fa-calendar-days"></i></button>
          </div></td>
        </tr>`, 6, "No approved loans awaiting disbursement.");
    } catch (e) { messageRow(body, 6, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
  async disburse(id) {
    if (!confirm("Disburse loan #" + id + " and generate the EMI schedule?")) return;
    try { await Api.disbursement.disburse(id); toast("Loan disbursed"); DisbUI.pending(); }
    catch (e) { toast(e.message, "danger"); }
  },
  async viewSchedule(loanId) {
    const body = document.getElementById("emiBody");
    body.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary"></div></div>';
    bootstrap.Modal.getOrCreateInstance(document.getElementById("emiModal")).show();
    try {
      const rows = await Api.disbursement.schedule(loanId);
      body.innerHTML = rows.length ? `<div class="table-responsive"><table class="table table-sm table-striped">
        <thead><tr><th>#</th><th>Due Date</th><th>EMI</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows.map(r => `<tr><td>${r.installmentNumber}</td><td>${fmt.date(r.dueDate)}</td><td>${fmt.money(r.emiAmount)}</td><td>${statusBadge(r.status)}</td>
          <td>${r.status !== "PAID" ? `<button class="btn btn-sm btn-outline-success" onclick="DisbUI.markPaid(${r.id}, ${loanId})">Mark Paid</button>` : ""}</td></tr>`).join("")}</tbody></table></div>`
        : '<p class="text-muted mb-0">No schedule yet.</p>';
    } catch (e) { body.innerHTML = `<div class="alert alert-danger mb-0">${escapeHtml(e.message)}</div>`; }
  },
  async markPaid(id, loanId) {
    try { await Api.disbursement.markPaid(id); toast("EMI marked paid"); DisbUI.viewSchedule(loanId); }
    catch (e) { toast(e.message, "danger"); }
  },

  /* repayment history lookup by loan id */
  initHistory() {
    document.getElementById("histBtn")?.addEventListener("click", DisbUI.loadHistory);
  },
  async loadHistory() {
    const loanId = document.getElementById("histLoanId").value;
    const body = document.getElementById("histBody");
    if (!loanId) return;
    loadingRow(body, 5);
    try {
      const rows = await Api.disbursement.history(loanId);
      renderRows(body, rows, (r) => `
        <tr><td>${r.installmentNumber}</td><td>${fmt.date(r.dueDate)}</td><td>${fmt.money(r.emiAmount)}</td>
        <td>${fmt.date(r.paidDate)}</td><td>${statusBadge(r.status)}</td></tr>`, 5, "No repayment history found.");
    } catch (e) { messageRow(body, 5, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
};
document.addEventListener("layout:ready", () => {
  switch (document.body.dataset.page) {
    case "disbursement-pending":
      DisbUI.pending();
      document.getElementById("refreshBtn")?.addEventListener("click", DisbUI.pending);
      wireSearch("search", "disbBody");
      break;
    case "disbursement-history":
    case "admin-repayments":
      DisbUI.initHistory();
      break;
  }
});

