﻿/* filters.js - dropdown filter for a list. Calls back with the selected value
   so the page can re-render its (already paginated) data set.
   wireSelectFilter('statusFilter', (val) => {...}) */
function wireSelectFilter(selectId, onChange) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  sel.addEventListener("change", () => onChange(sel.value || ""));
}
