﻿/* loan.js - role-based loan queues & workflow actions.
   Page selects behaviour via <body data-mode="officer|analyst|underwriter|admin">
   and <body data-status="..."> (the queue this page shows).
   Optional elements: #search, #statusFilter, #pager and approve fields
   #approveFields / #approveAmount / #approveRate / #approveTenure on the underwriter page. */
const LoanUI = {
  cache: [],
  pager: null,
  rowHtml(l, mode) {
    return `<tr>
      <td>${l.id}</td><td>${l.customerId}</td><td>${escapeHtml(l.loanType)}</td>
      <td>${fmt.money(l.requestedAmount)}</td><td>${statusBadge(l.riskGrade)}</td>
      <td>${statusBadge(l.status)}</td><td>${LoanUI.rowActions(l, mode)}</td>
    </tr>`;
  },
  rowActions(l, mode) {
    const view = `<button class="btn btn-outline-primary" onclick="LoanUI.view(${l.id})" title="View"><i class="fa-solid fa-eye"></i></button>`;
    let extra = "";
    if (mode === "officer") {
      if (l.status === "SUBMITTED")
        extra = `<button class="btn btn-outline-success" onclick="LoanUI.openAction(${l.id},'forward')" title="Forward to Credit Analyst"><i class="fa-solid fa-paper-plane"></i></button>
                 <button class="btn btn-outline-danger" onclick="LoanUI.openAction(${l.id},'reject')" title="Reject"><i class="fa-solid fa-ban"></i></button>`;
      else if (l.status === "APPROVED")
        extra = `<button class="btn btn-outline-info" onclick="LoanUI.disburse(${l.id})" title="Disburse & generate schedule"><i class="fa-solid fa-money-bill-transfer"></i></button>`;
    } else if (mode === "analyst") {
      if (l.status === "UNDER_REVIEW")
        extra = `<button class="btn btn-outline-success" onclick="LoanUI.openAction(${l.id},'evaluate')" title="Evaluate credit & forward to Underwriter"><i class="fa-solid fa-calculator"></i></button>`;
    } else if (mode === "underwriter") {
      if (l.status === "CREDIT_EVALUATED")
        extra = `<button class="btn btn-outline-success" onclick="LoanUI.openAction(${l.id},'approve')" title="Approve"><i class="fa-solid fa-check"></i></button>
                 <button class="btn btn-outline-danger" onclick="LoanUI.openAction(${l.id},'reject')" title="Reject"><i class="fa-solid fa-xmark"></i></button>`;
    }
    return `<div class="btn-group btn-group-sm">${view}${extra}</div>`;
  },
  async load() {
    const body = document.getElementById("loansBody");
    const filter = document.body.dataset.status || "";
    loadingRow(body, 7);
    try {
      // Fetch only this page's queue when a status is declared (task-oriented dashboards).
      let loans = filter ? await Api.loans.byStatus(filter) : await Api.loans.list();
      LoanUI.cache = loans;
      LoanUI.apply();
    } catch (e) { messageRow(body, 7, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
  apply() {
    const body = document.getElementById("loansBody");
    const mode = document.body.dataset.mode || "admin";
    const term = (document.getElementById("search")?.value || "").toLowerCase();
    const status = document.getElementById("statusFilter")?.value || "";
    let rows = LoanUI.cache;
    if (status) rows = rows.filter((l) => l.status === status);
    if (term) rows = rows.filter((l) =>
      [l.id, l.customerId, l.loanType, l.riskGrade, l.status].join(" ").toLowerCase().includes(term));
    const draw = (pageRows) => renderRows(body, pageRows, (l) => LoanUI.rowHtml(l, mode), 7, "No applications found.");
    if (document.getElementById("pager")) {
      if (!LoanUI.pager) { LoanUI.pager = new Paginator(rows, 10, draw); LoanUI.pager.mount("pager"); }
      else { LoanUI.pager.render = draw; LoanUI.pager.setRows(rows); }
    } else {
      draw(rows);
    }
  },
  view(id) {
    const l = LoanUI.cache.find((x) => x.id === id);
    const body = document.getElementById("detailsBody");
    if (body) { body.innerHTML = LoanUI.detailsHtml(l); bootstrap.Modal.getOrCreateInstance(document.getElementById("detailsModal")).show(); }
  },
  detailsHtml(l) {
    return `<dl class="row mb-0">
      <dt class="col-5">Application ID</dt><dd class="col-7">${l.id}</dd>
      <dt class="col-5">Customer ID</dt><dd class="col-7">${l.customerId}</dd>
      <dt class="col-5">Loan Type</dt><dd class="col-7">${escapeHtml(l.loanType)}</dd>
      <dt class="col-5">Requested Amount</dt><dd class="col-7">${fmt.money(l.requestedAmount)}</dd>
      <dt class="col-5">Monthly Income</dt><dd class="col-7">${l.monthlyIncome != null ? fmt.money(l.monthlyIncome) : "-"}</dd>
      <dt class="col-5">Tenure</dt><dd class="col-7">${l.tenureMonths || "-"} months</dd>
      <dt class="col-5">Interest Rate</dt><dd class="col-7">${l.interestRate != null ? l.interestRate + "%" : "-"}</dd>
      <dt class="col-5">Credit Score</dt><dd class="col-7">${l.creditScore ?? "-"}</dd>
      <dt class="col-5">Risk Grade</dt><dd class="col-7">${statusBadge(l.riskGrade)}</dd>
      <dt class="col-5">Status</dt><dd class="col-7">${statusBadge(l.status)}</dd>
      <dt class="col-5">Remarks</dt><dd class="col-7">${escapeHtml(l.decisionRemarks || "-")}</dd>
    </dl>`;
  },
  openAction(id, type) {
    const l = LoanUI.cache.find((x) => x.id === id) || {};
    document.getElementById("actionId").value = id;
    document.getElementById("actionType").value = type;
    document.getElementById("actionRemarks").value = "";
    // The underwriter's approve form shows sanctioned amount / rate / tenure (prefilled).
    const approveFields = document.getElementById("approveFields");
    if (approveFields) {
      const show = type === "approve";
      approveFields.classList.toggle("d-none", !show);
      if (show) {
        const set = (eid, v) => { const el = document.getElementById(eid); if (el) el.value = v ?? ""; };
        set("approveAmount", l.requestedAmount);
        set("approveRate", l.interestRate);
        set("approveTenure", l.tenureMonths);
      }
    }
    const titles = { approve: "Approve", reject: "Reject", forward: "Forward to Credit Analyst —", evaluate: "Evaluate & Forward to Underwriter —" };
    document.getElementById("remarksTitle").textContent = (titles[type] || "Action") + " Application #" + id;
    bootstrap.Modal.getOrCreateInstance(document.getElementById("remarksModal")).show();
  },
  async submitAction() {
    const id = document.getElementById("actionId").value;
    const type = document.getElementById("actionType").value;
    const remarks = document.getElementById("actionRemarks").value.trim();
    const num = (eid) => { const el = document.getElementById(eid); return el && el.value !== "" ? Number(el.value) : null; };
    try {
      if (type === "approve") {
        await Api.loans.approve(id, {
          approvedAmount: num("approveAmount"), interestRate: num("approveRate"),
          tenureMonths: num("approveTenure"), remarks: remarks || "Approved",
        });
      } else if (type === "forward") {
        await Api.loans.forward(id, remarks || "Forwarded to credit analyst");
      } else if (type === "evaluate") {
        await Api.loans.evaluate(id, remarks || "Credit evaluation completed");
      } else {
        await Api.loans.reject(id, remarks || "Rejected");
      }
      bootstrap.Modal.getInstance(document.getElementById("remarksModal")).hide();
      const done = { approve: "approved", reject: "rejected", forward: "forwarded to credit analyst", evaluate: "evaluated & forwarded to underwriter" };
      toast("Loan " + (done[type] || "updated"));
      LoanUI.load();
    } catch (e) { toast(e.message, "danger"); }
  },
  async disburse(id) {
    if (!confirm("Disburse loan #" + id + " and generate the EMI schedule?")) return;
    try { await Api.disbursement.disburse(id); toast("Loan disbursed - EMI schedule generated"); LoanUI.load(); }
    catch (e) { toast(e.message, "danger"); }
  },
};
document.addEventListener("layout:ready", () => {
  if (document.getElementById("loansBody")) {
    LoanUI.load();
    document.getElementById("refreshBtn")?.addEventListener("click", LoanUI.load);
    document.getElementById("actionSaveBtn")?.addEventListener("click", LoanUI.submitAction);
    document.getElementById("search")?.addEventListener("input", LoanUI.apply);
    wireSelectFilter("statusFilter", LoanUI.apply);
  }
});
