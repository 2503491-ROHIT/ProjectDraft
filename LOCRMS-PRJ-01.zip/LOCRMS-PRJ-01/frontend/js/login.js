/* login.js — common login page. */
document.addEventListener("DOMContentLoaded", () => {
  if (Token.get() && Session.role()) { location.href = roleHome(Session.role()); return; }
  const form = document.getElementById("loginForm");
  const alertBox = document.getElementById("alert");
  const btn = document.getElementById("loginBtn");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    alertBox.innerHTML = "";
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;
    if (!username || !password) { alertBox.innerHTML = '<div class="alert alert-warning py-2">Please enter username and password.</div>'; return; }
    btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Signing in...';
    try {
      const res = await Api.login(username, password);
      Session.save(res);
      location.href = roleHome(Session.role());
    } catch (err) { alertBox.innerHTML = '<div class="alert alert-danger py-2">' + err.message + "</div>"; }
    finally { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-right-to-bracket me-1"></i> Login'; }
  });
});

