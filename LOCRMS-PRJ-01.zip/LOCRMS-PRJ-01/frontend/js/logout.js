/* logout.js — logout action + binder. */
function logout() {
  Session.clear();
  location.href = rootPath() + "index.html";
}
function bindLogout() {
  const btn = document.getElementById("logoutBtn");
  if (btn) btn.addEventListener("click", logout);
}

