/* navbar.js — guards the page, injects navbar + footer fragments, fills user info.
   Pages must set: <body data-role="ROLE_X" data-active="key"> and include
   <div id="navbarMount"></div> ... <div id="footerMount"></div>. */

async function loadFragment(mountId, file) {
  const mount = document.getElementById(mountId);
  if (!mount) return;
  try {
    const res = await fetch(rootPath() + "fragments/" + file);
    mount.innerHTML = await res.text();
  } catch {
    mount.innerHTML = "";
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  const role = document.body.dataset.role;
  if (role && !requireRole(role.split(","))) return;

  await loadFragment("navbarMount", "navbar.html");
  await loadFragment("footerMount", "footer.html");

  const user = Session.user();
  const nameEl = document.getElementById("navUsername");
  const roleEl = document.getElementById("navRole");
  if (nameEl && user) nameEl.textContent = user.username;
  if (roleEl && role) roleEl.textContent = ROLE_LABEL[role] || role;

  const toggle = document.getElementById("sidebarToggle");
  if (toggle) toggle.addEventListener("click", () =>
    document.getElementById("sidebar").classList.toggle("collapsed"));

  bindLogout();

  // notify page that chrome is ready
  document.dispatchEvent(new CustomEvent("layout:ready"));
});

