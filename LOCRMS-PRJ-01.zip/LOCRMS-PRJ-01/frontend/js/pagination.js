﻿/* pagination.js - simple client-side paginator over an in-memory array.
   const pager = new Paginator(rows, 10, render); pager.mount('pagerEl');
   render(pageRows) is called whenever the page changes. */
class Paginator {
  constructor(rows, pageSize, render) {
    this.rows = rows || [];
    this.size = pageSize || 10;
    this.render = render;
    this.page = 1;
  }
  get pages() { return Math.max(1, Math.ceil(this.rows.length / this.size)); }
  slice() { return this.rows.slice((this.page - 1) * this.size, this.page * this.size); }
  setRows(rows) { this.rows = rows || []; this.page = 1; this.draw(); }
  mount(elId) {
    this.el = document.getElementById(elId);
    this.draw();
  }
  draw() {
    this.render(this.slice());
    if (!this.el) return;
    if (this.pages <= 1) { this.el.innerHTML = ""; return; }
    let items = "";
    for (let p = 1; p <= this.pages; p++)
      items += `<li class="page-item ${p === this.page ? "active" : ""}"><a class="page-link" href="#" data-p="${p}">${p}</a></li>`;
    this.el.innerHTML = `<ul class="pagination pagination-sm mb-0 justify-content-end">${items}</ul>`;
    this.el.querySelectorAll("[data-p]").forEach((a) =>
      a.addEventListener("click", (e) => { e.preventDefault(); this.page = +a.dataset.p; this.draw(); }));
  }
}
