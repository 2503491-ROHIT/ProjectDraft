/* profile.js — read-only "My Profile" for any logged-in user.
   Fills #pfUsername, #pfRole, and (for customers) #pfCustomer block. */
const ProfileUI = {
  async load() {
    const u = Session.user();
    const role = Session.role();
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set("pfUsername", u ? u.username : "-");
    set("pfRole", ROLE_LABEL[role] || role || "-");

    const block = document.getElementById("pfCustomer");
    if (block && role === "ROLE_CUSTOMER") {
      const cid = await ensureMyCustomerId();
      if (!cid) { block.innerHTML = '<div class="alert alert-info mb-0">No customer profile yet. Use Edit Profile to create one.</div>'; return; }
      try {
        const c = await Api.customers.get(cid);
        block.innerHTML = `<dl class="row mb-0">
          <dt class="col-4">Full Name</dt><dd class="col-8">${escapeHtml(c.fullName)}</dd>
          <dt class="col-4">Email</dt><dd class="col-8">${escapeHtml(c.email)}</dd>
          <dt class="col-4">Phone</dt><dd class="col-8">${escapeHtml(c.phone)}</dd>
          <dt class="col-4">PAN</dt><dd class="col-8">${escapeHtml(c.panNumber || "-")}</dd>
          <dt class="col-4">KYC</dt><dd class="col-8">${statusBadge(c.kycStatus)}</dd></dl>`;
      } catch { block.innerHTML = ""; }
    }
  },
};
document.addEventListener("layout:ready", () => {
  if (document.body.dataset.page === "profile") ProfileUI.load();
});
