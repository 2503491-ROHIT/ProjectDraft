/* register.js — customer self-registration page. */
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registerForm");
  const alertBox = document.getElementById("alert");
  const btn = document.getElementById("regBtn");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    alertBox.innerHTML = "";
    if (!validateForm(form)) return;
    btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Registering...';
    try {
      await Api.registerCustomer({ username: document.getElementById("username").value.trim(),
        email: document.getElementById("email").value.trim(), password: document.getElementById("password").value });
      alertBox.innerHTML = '<div class="alert alert-success py-2">Account created! Redirecting to login...</div>';
      setTimeout(() => location.href = "index.html", 1500);
    } catch (err) { alertBox.innerHTML = '<div class="alert alert-danger py-2">' + err.message + "</div>"; }
    finally { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-user-plus me-1"></i> Register'; }
  });
});

