/* search.js — live client-side row search. */
function wireSearch(inputId, tbodyId) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener("input", () => {
    const term = input.value.toLowerCase();
    $$(`#${tbodyId} tr`).forEach((tr) => {
      tr.style.display = tr.textContent.toLowerCase().includes(term) ? "" : "none";
    });
  });
}

