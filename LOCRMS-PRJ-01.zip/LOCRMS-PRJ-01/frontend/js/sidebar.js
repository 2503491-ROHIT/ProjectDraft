/* sidebar.js — injects the role-specific sidebar fragment and highlights the
   active link based on <body data-active="key">. */

document.addEventListener("DOMContentLoaded", async () => {
  const role = document.body.dataset.role;
  const active = document.body.dataset.active;
  const mount = document.getElementById("sidebarMount");
  if (!mount || !role) return;

  const fragment = ROLE_SIDEBAR[role] || "sidebar-admin.html";
  try {
    const res = await fetch(rootPath() + "fragments/" + fragment);
    mount.innerHTML = await res.text();
  } catch { return; }

  if (active) {
    const link = mount.querySelector(`[data-key="${active}"]`);
    if (link) link.classList.add("active");
  }
});

