/* tables.js — render data rows into a tbody. */
function renderRows(tbody, rows, mapFn, colspan, empty = "No records found.") {
  if (!rows || !rows.length) { messageRow(tbody, colspan, empty); return; }
  tbody.innerHTML = rows.map(mapFn).join("");
}

