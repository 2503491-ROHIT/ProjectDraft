﻿/* users.js - admin user management + role management.
   Optional page elements: #search, #statusFilter (role filter), #pager. */
const STAFF_ROLES = ["ROLE_LOAN_OFFICER", "ROLE_CREDIT_ANALYST", "ROLE_UNDERWRITER", "ROLE_COLLECTION_AGENT", "ROLE_ADMIN"];
const UsersUI = {
  cache: [],
  pager: null,
  async load() {
    const body = document.getElementById("usersBody");
    loadingRow(body, 6);
    try {
      UsersUI.cache = await Api.users.list();
      UsersUI.apply();
    } catch (e) { messageRow(body, 6, `<span class="text-danger">${escapeHtml(e.message)}</span>`); }
  },
  rowHtml(u) {
    return `<tr>
      <td>${u.id}</td><td>${escapeHtml(u.username)}</td><td>${escapeHtml(u.email)}</td>
      <td>${(u.roles || []).map(r => `<span class="badge text-bg-light border">${escapeHtml(r)}</span>`).join(" ")}</td>
      <td>${u.active ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Inactive</span>'}</td>
      <td><div class="btn-group btn-group-sm">
        <button class="btn btn-outline-secondary" onclick="UsersUI.toggle(${u.id}, ${u.active})" title="${u.active ? "Deactivate" : "Activate"}"><i class="fa-solid ${u.active ? "fa-user-slash" : "fa-user-check"}"></i></button>
        <button class="btn btn-outline-primary" onclick="UsersUI.openRole(${u.id})" title="Change role"><i class="fa-solid fa-user-tag"></i></button>
        <button class="btn btn-outline-warning" onclick="UsersUI.openReset(${u.id})" title="Reset password"><i class="fa-solid fa-key"></i></button>
        <button class="btn btn-outline-danger" onclick="UsersUI.remove(${u.id})" title="Delete"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`;
  },
  apply() {
    const body = document.getElementById("usersBody");
    const term = (document.getElementById("search")?.value || "").toLowerCase();
    const role = document.getElementById("statusFilter")?.value || "";
    let rows = UsersUI.cache;
    if (role) rows = rows.filter((u) => (u.roles || []).includes(role));
    if (term) rows = rows.filter((u) =>
      [u.id, u.username, u.email, (u.roles || []).join(" "), u.active ? "active" : "inactive"].join(" ").toLowerCase().includes(term));
    const draw = (pageRows) => renderRows(body, pageRows, UsersUI.rowHtml, 6, "No users found.");
    if (document.getElementById("pager")) {
      if (!UsersUI.pager) { UsersUI.pager = new Paginator(rows, 10, draw); UsersUI.pager.mount("pager"); }
      else { UsersUI.pager.render = draw; UsersUI.pager.setRows(rows); }
    } else {
      draw(rows);
    }
  },
  async create(e) {
    e.preventDefault();
    if (!validateForm(e.target)) return;
    try {
      await Api.users.create({ username: document.getElementById("sUser").value.trim(), email: document.getElementById("sEmail").value.trim(),
        password: document.getElementById("sPass").value, role: document.getElementById("sRole").value });
      bootstrap.Modal.getInstance(document.getElementById("staffModal")).hide();
      e.target.reset(); e.target.classList.remove("was-validated");
      toast("Staff user created"); UsersUI.load();
    } catch (err) { toast(err.message, "danger"); }
  },
  async toggle(id, active) {
    try { active ? await Api.users.deactivate(id) : await Api.users.activate(id); toast("Updated"); UsersUI.load(); }
    catch (e) { toast(e.message, "danger"); }
  },
  openRole(id) { document.getElementById("roleUserId").value = id; bootstrap.Modal.getOrCreateInstance(document.getElementById("roleModal")).show(); },
  async saveRole() {
    const id = document.getElementById("roleUserId").value;
    try { await Api.users.changeRole(id, document.getElementById("roleSelect").value); bootstrap.Modal.getInstance(document.getElementById("roleModal")).hide(); toast("Role updated"); UsersUI.load(); }
    catch (e) { toast(e.message, "danger"); }
  },
  openReset(id) { document.getElementById("resetUserId").value = id; document.getElementById("resetPassword").value = ""; bootstrap.Modal.getOrCreateInstance(document.getElementById("resetModal")).show(); },
  async saveReset() {
    const id = document.getElementById("resetUserId").value;
    const pwd = document.getElementById("resetPassword").value;
    if (!pwd || pwd.length < 6) { toast("Password must be at least 6 characters", "danger"); return; }
    try { await Api.users.resetPassword(id, pwd); bootstrap.Modal.getInstance(document.getElementById("resetModal")).hide(); toast("Password reset"); }
    catch (e) { toast(e.message, "danger"); }
  },
  async remove(id) {
    if (!confirm("Delete this user permanently?")) return;
    try { await Api.users.remove(id); toast("User deleted"); UsersUI.load(); }
    catch (e) { toast(e.message, "danger"); }
  },
};
document.addEventListener("layout:ready", () => {
  if (document.getElementById("usersBody")) {
    UsersUI.load();
    document.getElementById("refreshBtn")?.addEventListener("click", UsersUI.load);
    document.getElementById("staffForm")?.addEventListener("submit", UsersUI.create);
    document.getElementById("roleSaveBtn")?.addEventListener("click", UsersUI.saveRole);
    document.getElementById("resetSaveBtn")?.addEventListener("click", UsersUI.saveReset);
    document.getElementById("search")?.addEventListener("input", UsersUI.apply);
    wireSelectFilter("statusFilter", UsersUI.apply);
  }
});
