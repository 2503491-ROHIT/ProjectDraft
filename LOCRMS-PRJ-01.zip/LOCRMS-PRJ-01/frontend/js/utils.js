/* utils.js — shared helpers (selectors, formatters, toast, query params). */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/* path back to frontend root from any page depth */
function rootPath() {
  return location.pathname.includes("/pages/") ? "../../" : "";
}

function getParam(name) {
  return new URLSearchParams(location.search).get(name);
}

const fmt = {
  money: (v) => v == null ? "-" : "₹" + Number(v).toLocaleString("en-IN", { maximumFractionDigits: 2 }),
  date: (v) => !v ? "-" : new Date(v).toLocaleDateString("en-IN"),
  num: (v) => v == null ? "0" : Number(v).toLocaleString("en-IN"),
};

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function statusBadge(status) {
  const map = {
    APPROVED: "success", VERIFIED: "success", PAID: "success", RECOVERED: "success", LOW: "success", ACTIVE: "success", DISBURSED: "success",
    REJECTED: "danger", OVERDUE: "danger", HIGH: "danger", WRITTEN_OFF: "dark",
    PENDING: "warning", UNDER_REVIEW: "info", MEDIUM: "warning",
  };
  return `<span class="badge text-bg-${map[status] || "secondary"}">${escapeHtml(status || "-")}</span>`;
}

function toast(msg, type = "success") {
  let wrap = $("#toastWrap");
  if (!wrap) {
    wrap = document.createElement("div");
    wrap.id = "toastWrap";
    wrap.className = "toast-container position-fixed top-0 end-0 p-3";
    document.body.appendChild(wrap);
  }
  const el = document.createElement("div");
  el.className = `toast align-items-center text-bg-${type} border-0 show`;
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${escapeHtml(msg)}</div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

/* table helpers */
function loadingRow(tbody, colspan) {
  tbody.innerHTML = `<tr><td colspan="${colspan}" class="text-center text-muted py-4"><div class="spinner-border spinner-border-sm text-primary me-2"></div>Loading...</td></tr>`;
}
function messageRow(tbody, colspan, html) {
  tbody.innerHTML = `<tr><td colspan="${colspan}" class="text-center text-muted py-4">${html}</td></tr>`;
}

