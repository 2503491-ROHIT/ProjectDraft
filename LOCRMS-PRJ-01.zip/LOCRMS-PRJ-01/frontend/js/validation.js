/* validation.js — Bootstrap form validation helpers. */
function validateForm(form) {
  if (!form.checkValidity()) { form.classList.add("was-validated"); return false; }
  return true;
}
/* collect trimmed values for a set of element ids */
function collect(ids) {
  const out = {};
  ids.forEach((id) => { const el = document.getElementById(id); if (el) out[id] = el.value.trim(); });
  return out;
}

