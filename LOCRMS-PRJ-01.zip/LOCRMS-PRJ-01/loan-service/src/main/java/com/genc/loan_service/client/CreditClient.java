package com.genc.loan_service.client;

import com.genc.loan_service.dto.CreditScoreDTO;
import com.genc.loan_service.dto.CreditScoreRequestDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client to calculate credit scores via Credit Service.
 */
@FeignClient(name = "credit-service")
public interface CreditClient {

    @PostMapping("/credit/generate")
    CreditScoreDTO generateScore(@RequestBody CreditScoreRequestDTO request);
}

