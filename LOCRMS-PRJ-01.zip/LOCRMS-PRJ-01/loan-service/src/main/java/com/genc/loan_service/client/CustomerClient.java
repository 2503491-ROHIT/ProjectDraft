package com.genc.loan_service.client;

import com.genc.loan_service.dto.CustomerResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client to verify customers via Customer Service.
 */
@FeignClient(name = "customer-service")
public interface CustomerClient {

    @GetMapping("/customer/{id}")
    CustomerResponseDTO getCustomerById(@PathVariable("id") Long id);
}

