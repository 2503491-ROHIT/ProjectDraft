package com.genc.loan_service.config;

import com.genc.loan_service.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/public/**").permitAll()
                        // Workflow actions are restricted to the role that owns each stage.
                        .requestMatchers(HttpMethod.POST, "/loan/apply").hasAnyRole("CUSTOMER", "ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/loan/*/forward").hasAnyRole("LOAN_OFFICER", "ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/loan/*/evaluate").hasAnyRole("CREDIT_ANALYST", "ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/loan/*/approve", "/loan/*/reject").hasAnyRole("UNDERWRITER", "ADMIN")
                        // Status update is used by the Disbursement Service (invoked by the Loan Officer) to mark DISBURSED.
                        .requestMatchers(HttpMethod.PATCH, "/loan/*/status").hasAnyRole("LOAN_OFFICER", "ADMIN")
                        // Reads are visible to every workflow participant.
                        .requestMatchers(HttpMethod.GET, "/loan/**")
                            .hasAnyRole("CUSTOMER", "LOAN_OFFICER", "CREDIT_ANALYST", "UNDERWRITER", "ADMIN")
                        .requestMatchers("/loan/**").hasAnyRole("CUSTOMER", "LOAN_OFFICER", "CREDIT_ANALYST", "UNDERWRITER", "ADMIN")
                        .anyRequest().authenticated())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
