package com.genc.loan_service.controller;

import com.genc.loan_service.dto.LoanApplicationDTO;
import com.genc.loan_service.dto.LoanResponseDTO;
import com.genc.loan_service.dto.LoanStatusUpdateDTO;
import com.genc.loan_service.service.LoanService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/loan")
public class LoanController {

    private static final Logger log = LoggerFactory.getLogger(LoanController.class);

    private final LoanService loanService;

    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }

    @PostMapping("/apply")
    public ResponseEntity<LoanResponseDTO> apply(@Valid @RequestBody LoanApplicationDTO request) {
        log.info("POST /loan/apply for customer {}", request.getCustomerId());
        return ResponseEntity.status(HttpStatus.CREATED).body(loanService.submitApplication(request));
    }

    @GetMapping
    public ResponseEntity<List<LoanResponseDTO>> getAll() {
        return ResponseEntity.ok(loanService.getAllLoans());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LoanResponseDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(loanService.getLoanById(id));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<LoanResponseDTO>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(loanService.getLoansByCustomer(customerId));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<LoanResponseDTO>> getByStatus(@PathVariable com.genc.loan_service.model.LoanStatus status) {
        return ResponseEntity.ok(loanService.getLoansByStatus(status));
    }

    @PutMapping("/{id}")
    public ResponseEntity<LoanResponseDTO> update(@PathVariable Long id,
                                                  @Valid @RequestBody LoanApplicationDTO request) {
        return ResponseEntity.ok(loanService.updateLoan(id, request));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<LoanResponseDTO> changeStatus(@PathVariable Long id,
                                                        @Valid @RequestBody LoanStatusUpdateDTO request) {
        return ResponseEntity.ok(loanService.changeStatus(id, request.getStatus(), request.getRemarks()));
    }

    @PatchMapping("/{id}/forward")
    public ResponseEntity<LoanResponseDTO> forward(@PathVariable Long id,
                                                   @RequestBody(required = false) LoanStatusUpdateDTO request) {
        String remarks = request != null && request.getRemarks() != null ? request.getRemarks() : "Forwarded to credit analyst";
        return ResponseEntity.ok(loanService.forwardToCreditAnalyst(id, remarks));
    }

    @PatchMapping("/{id}/evaluate")
    public ResponseEntity<LoanResponseDTO> evaluate(@PathVariable Long id,
                                                    @RequestBody(required = false) LoanStatusUpdateDTO request) {
        String remarks = request != null && request.getRemarks() != null ? request.getRemarks() : "Credit evaluation completed; forwarded to underwriter";
        return ResponseEntity.ok(loanService.evaluateCredit(id, remarks));
    }

    @PatchMapping("/{id}/approve")
    public ResponseEntity<LoanResponseDTO> approve(@PathVariable Long id,
                                                   @RequestBody(required = false) com.genc.loan_service.dto.UnderwritingDecisionDTO request) {
        if (request == null) {
            return ResponseEntity.ok(loanService.approveLoan(id, null, null, null, "Approved"));
        }
        String remarks = request.getRemarks() != null ? request.getRemarks() : "Approved";
        return ResponseEntity.ok(loanService.approveLoan(id,
                request.getApprovedAmount(), request.getInterestRate(), request.getTenureMonths(), remarks));
    }

    @PatchMapping("/{id}/reject")
    public ResponseEntity<LoanResponseDTO> reject(@PathVariable Long id,
                                                  @RequestBody(required = false) LoanStatusUpdateDTO request) {
        String remarks = request != null ? request.getRemarks() : "Rejected";
        return ResponseEntity.ok(loanService.rejectLoan(id, remarks));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        loanService.deleteLoan(id);
        return ResponseEntity.noContent().build();
    }
}
