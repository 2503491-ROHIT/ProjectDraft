package com.genc.loan_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Credit score payload returned by Credit Service.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditScoreDTO {

    private Long id;
    private Long customerId;
    private Integer bureauScore;
    private Integer internalScore;
    private String riskGrade;
}

