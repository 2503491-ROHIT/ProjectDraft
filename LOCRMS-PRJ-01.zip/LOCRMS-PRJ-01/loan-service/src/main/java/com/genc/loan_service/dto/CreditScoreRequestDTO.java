package com.genc.loan_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Request sent to Credit Service to generate a credit score.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditScoreRequestDTO {

    private Long customerId;
    private BigDecimal monthlyIncome;
    private BigDecimal existingObligations;
    private BigDecimal requestedAmount;
}

