package com.genc.loan_service.dto;

import com.genc.loan_service.model.KycStatusView;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Subset of the customer payload returned by Customer Service.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerResponseDTO {

    private Long id;
    private String fullName;
    private String email;
    private KycStatusView kycStatus;
    private boolean active;
}

