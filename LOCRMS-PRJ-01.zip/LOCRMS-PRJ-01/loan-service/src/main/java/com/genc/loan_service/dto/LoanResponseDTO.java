package com.genc.loan_service.dto;

import com.genc.loan_service.model.LoanStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanResponseDTO {

    private Long id;
    private Long customerId;
    private String loanType;
    private BigDecimal requestedAmount;
    private Integer tenureMonths;
    private BigDecimal interestRate;
    private BigDecimal monthlyIncome;
    private String purpose;
    private LoanStatus status;
    private Integer creditScore;
    private String riskGrade;
    private String decisionRemarks;
    private LocalDateTime createdAt;
}
