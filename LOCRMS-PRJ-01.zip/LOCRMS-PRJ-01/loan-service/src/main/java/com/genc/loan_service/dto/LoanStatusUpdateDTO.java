package com.genc.loan_service.dto;

import com.genc.loan_service.model.LoanStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanStatusUpdateDTO {

    @NotNull(message = "Status is required")
    private LoanStatus status;

    @Size(max = 255)
    private String remarks;
}

