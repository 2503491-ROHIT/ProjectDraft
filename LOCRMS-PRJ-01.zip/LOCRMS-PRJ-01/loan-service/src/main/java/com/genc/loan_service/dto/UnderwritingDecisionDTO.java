package com.genc.loan_service.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Underwriter's final decision: sanctioned amount, interest rate and tenure.
 * All numeric fields are optional — when omitted the application's existing values are kept.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UnderwritingDecisionDTO {

    @Positive(message = "Approved amount must be positive")
    private BigDecimal approvedAmount;

    @Positive(message = "Interest rate must be positive")
    private BigDecimal interestRate;

    @Min(value = 3, message = "Tenure must be at least 3 months")
    @Max(value = 360, message = "Tenure cannot exceed 360 months")
    private Integer tenureMonths;

    @Size(max = 255)
    private String remarks;
}

