package com.genc.loan_service.mapper;

import com.genc.loan_service.dto.LoanResponseDTO;
import com.genc.loan_service.model.LoanApplication;
import org.springframework.stereotype.Component;

@Component
public class LoanMapper {

    public LoanResponseDTO toResponseDTO(LoanApplication loan) {
        return LoanResponseDTO.builder()
                .id(loan.getId())
                .customerId(loan.getCustomerId())
                .loanType(loan.getLoanType())
                .requestedAmount(loan.getRequestedAmount())
                .tenureMonths(loan.getTenureMonths())
                .interestRate(loan.getInterestRate())
                .monthlyIncome(loan.getMonthlyIncome())
                .purpose(loan.getPurpose())
                .status(loan.getStatus())
                .creditScore(loan.getCreditScore())
                .riskGrade(loan.getRiskGrade())
                .decisionRemarks(loan.getDecisionRemarks())
                .createdAt(loan.getCreatedAt())
                .build();
    }
}
