package com.genc.loan_service.model;

/**
 * Mirrors the KYC status enum exposed by Customer Service.
 */
public enum KycStatusView {
    PENDING,
    VERIFIED,
    REJECTED
}
