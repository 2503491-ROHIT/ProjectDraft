package com.genc.loan_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "loan_applications")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "applicationId")
    private Long id;

    @Column(nullable = false)
    private Long customerId;

    @Column(nullable = false, length = 50)
    private String loanType;

    @Column(name = "requestedAmount", nullable = false)
    private BigDecimal requestedAmount;

    @Column(nullable = false)
    private Integer tenureMonths;

    @Column(nullable = false)
    private BigDecimal interestRate;

    /** Captured at application time so the Credit Analyst can evaluate later. */
    private BigDecimal monthlyIncome;

    @Column(length = 100)
    private String purpose;

    @Enumerated(EnumType.STRING)
    @Column(name = "applicationStatus", nullable = false, length = 20)
    @Builder.Default
    private LoanStatus status = LoanStatus.SUBMITTED;

    private Integer creditScore;

    private String riskGrade;

    @Column(length = 255)
    private String decisionRemarks;

    @Column(nullable = false, updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
}
