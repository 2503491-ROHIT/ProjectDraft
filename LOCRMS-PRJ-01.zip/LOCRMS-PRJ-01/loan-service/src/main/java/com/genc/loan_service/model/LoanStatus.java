package com.genc.loan_service.model;

public enum LoanStatus {
    SUBMITTED,
    UNDER_REVIEW,
    CREDIT_EVALUATED,
    APPROVED,
    REJECTED,
    DISBURSED
}
