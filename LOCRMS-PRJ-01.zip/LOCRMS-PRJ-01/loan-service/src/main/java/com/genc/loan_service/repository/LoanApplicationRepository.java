package com.genc.loan_service.repository;

import com.genc.loan_service.model.LoanApplication;
import com.genc.loan_service.model.LoanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanApplicationRepository extends JpaRepository<LoanApplication, Long> {

    List<LoanApplication> findByCustomerId(Long customerId);

    List<LoanApplication> findByStatus(LoanStatus status);

    long countByStatus(LoanStatus status);
}
