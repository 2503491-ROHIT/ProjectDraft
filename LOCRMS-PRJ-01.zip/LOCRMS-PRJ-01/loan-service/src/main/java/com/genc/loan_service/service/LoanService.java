package com.genc.loan_service.service;

import com.genc.loan_service.dto.LoanApplicationDTO;
import com.genc.loan_service.dto.LoanResponseDTO;
import com.genc.loan_service.model.LoanStatus;

import java.util.List;

public interface LoanService {

    LoanResponseDTO submitApplication(LoanApplicationDTO request);

    List<LoanResponseDTO> getAllLoans();

    LoanResponseDTO getLoanById(Long id);

    List<LoanResponseDTO> getLoansByCustomer(Long customerId);

    List<LoanResponseDTO> getLoansByStatus(LoanStatus status);

    LoanResponseDTO updateLoan(Long id, LoanApplicationDTO request);

    LoanResponseDTO changeStatus(Long id, LoanStatus status, String remarks);

    /** Loan officer forwards an eligible application (SUBMITTED) to the credit analyst (UNDER_REVIEW). */
    LoanResponseDTO forwardToCreditAnalyst(Long id, String remarks);

    /** Credit analyst evaluates an UNDER_REVIEW application (fetches score, assigns grade) and forwards to the underwriter (CREDIT_EVALUATED). */
    LoanResponseDTO evaluateCredit(Long id, String remarks);

    /** Underwriter approves a CREDIT_EVALUATED application, setting sanctioned amount, rate and tenure. */
    LoanResponseDTO approveLoan(Long id, java.math.BigDecimal approvedAmount, java.math.BigDecimal interestRate, Integer tenureMonths, String remarks);

    LoanResponseDTO rejectLoan(Long id, String remarks);

    void deleteLoan(Long id);
}
