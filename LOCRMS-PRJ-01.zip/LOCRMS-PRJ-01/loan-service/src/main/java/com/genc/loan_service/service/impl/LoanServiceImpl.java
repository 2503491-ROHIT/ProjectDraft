package com.genc.loan_service.service.impl;

import com.genc.loan_service.client.CreditClient;
import com.genc.loan_service.client.CustomerClient;
import com.genc.loan_service.dto.CreditScoreDTO;
import com.genc.loan_service.dto.CreditScoreRequestDTO;
import com.genc.loan_service.dto.CustomerResponseDTO;
import com.genc.loan_service.dto.LoanApplicationDTO;
import com.genc.loan_service.dto.LoanResponseDTO;
import com.genc.loan_service.exception.InvalidRequestException;
import com.genc.loan_service.exception.ResourceNotFoundException;
import com.genc.loan_service.mapper.LoanMapper;
import com.genc.loan_service.model.KycStatusView;
import com.genc.loan_service.model.LoanApplication;
import com.genc.loan_service.model.LoanStatus;
import com.genc.loan_service.repository.LoanApplicationRepository;
import com.genc.loan_service.service.LoanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class LoanServiceImpl implements LoanService {

    private static final Logger log = LoggerFactory.getLogger(LoanServiceImpl.class);
    private static final BigDecimal BASE_RATE = new BigDecimal("9.5");

    private final LoanApplicationRepository loanRepository;
    private final LoanMapper loanMapper;
    private final CustomerClient customerClient;
    private final CreditClient creditClient;

    public LoanServiceImpl(LoanApplicationRepository loanRepository,
                           LoanMapper loanMapper,
                           CustomerClient customerClient,
                           CreditClient creditClient) {
        this.loanRepository = loanRepository;
        this.loanMapper = loanMapper;
        this.customerClient = customerClient;
        this.creditClient = creditClient;
    }

    @Override
    @Transactional
    public LoanResponseDTO submitApplication(LoanApplicationDTO request) {
        log.trace("Entering submitApplication with request={}", request);
        log.info("Submitting loan application for customer {}", request.getCustomerId());

        // Verify the customer exists, is active and KYC-verified (Feign -> Customer Service).
        log.debug("Verifying customer {} via Customer Service", request.getCustomerId());
        CustomerResponseDTO customer = verifyCustomer(request.getCustomerId());

        // Credit evaluation is performed later by the Credit Analyst; the application
        // simply enters the SUBMITTED queue for the Loan Officer to review.
        LoanApplication loan = LoanApplication.builder()
                .customerId(request.getCustomerId())
                .loanType(request.getLoanType())
                .requestedAmount(request.getRequestedAmount())
                .tenureMonths(request.getTenureMonths())
                .monthlyIncome(request.getMonthlyIncome())
                .purpose(request.getPurpose())
                .interestRate(BASE_RATE)
                .status(LoanStatus.SUBMITTED)
                .build();

        LoanApplication saved = loanRepository.save(loan);
        log.info("Loan application {} created (SUBMITTED) for customer {}", saved.getId(), customer.getId());
        LoanResponseDTO response = loanMapper.toResponseDTO(saved);
        log.trace("Exiting submitApplication, returning={}", response);
        return response;
    }

    @Override
    public List<LoanResponseDTO> getAllLoans() {
        log.debug("Fetching all loan applications");
        List<LoanResponseDTO> loans = loanRepository.findAll().stream()
                .map(loanMapper::toResponseDTO)
                .toList();
        log.debug("Retrieved {} loan application(s)", loans.size());
        return loans;
    }

    @Override
    public LoanResponseDTO getLoanById(Long id) {
        log.trace("Entering getLoanById with id={}", id);
        return loanMapper.toResponseDTO(findLoan(id));
    }

    @Override
    public List<LoanResponseDTO> getLoansByCustomer(Long customerId) {
        log.debug("Fetching loans for customer {}", customerId);
        return loanRepository.findByCustomerId(customerId).stream()
                .map(loanMapper::toResponseDTO)
                .toList();
    }

    @Override
    public List<LoanResponseDTO> getLoansByStatus(LoanStatus status) {
        log.debug("Fetching loans with status {}", status);
        return loanRepository.findByStatus(status).stream()
                .map(loanMapper::toResponseDTO)
                .toList();
    }

    @Override
    @Transactional
    public LoanResponseDTO updateLoan(Long id, LoanApplicationDTO request) {
        log.trace("Entering updateLoan with id={}, request={}", id, request);
        LoanApplication loan = findLoan(id);
        if (loan.getStatus() == LoanStatus.APPROVED) {
            throw new InvalidRequestException("Approved loans cannot be modified");
        }
        loan.setLoanType(request.getLoanType());
        loan.setRequestedAmount(request.getRequestedAmount());
        loan.setTenureMonths(request.getTenureMonths());
        loan.setPurpose(request.getPurpose());
        log.info("Loan {} updated", id);
        return loanMapper.toResponseDTO(loanRepository.save(loan));
    }

    @Override
    @Transactional
    public LoanResponseDTO changeStatus(Long id, LoanStatus status, String remarks) {
        log.trace("Entering changeStatus with id={}, status={}", id, status);
        LoanApplication loan = findLoan(id);
        loan.setStatus(status);
        loan.setDecisionRemarks(remarks);
        log.info("Loan {} status changed to {}", id, status);
        return loanMapper.toResponseDTO(loanRepository.save(loan));
    }

    @Override
    @Transactional
    public LoanResponseDTO forwardToCreditAnalyst(Long id, String remarks) {
        log.trace("Entering forwardToCreditAnalyst with id={}", id);
        LoanApplication loan = findLoan(id);
        if (loan.getStatus() != LoanStatus.SUBMITTED) {
            throw new InvalidRequestException("Only newly submitted applications can be forwarded to the credit analyst");
        }
        loan.setStatus(LoanStatus.UNDER_REVIEW);
        loan.setDecisionRemarks(remarks);
        log.info("Loan {} forwarded to credit analyst", id);
        return loanMapper.toResponseDTO(loanRepository.save(loan));
    }

    @Override
    @Transactional
    public LoanResponseDTO evaluateCredit(Long id, String remarks) {
        log.trace("Entering evaluateCredit with id={}", id);
        LoanApplication loan = findLoan(id);
        if (loan.getStatus() != LoanStatus.UNDER_REVIEW) {
            throw new InvalidRequestException("Only applications under review can be credit-evaluated");
        }
        // Fetch bureau + internal score and risk grade from Credit Service (Feign).
        CreditScoreDTO score = creditClient.generateScore(CreditScoreRequestDTO.builder()
                .customerId(loan.getCustomerId())
                .monthlyIncome(loan.getMonthlyIncome())
                .existingObligations(BigDecimal.ZERO)
                .requestedAmount(loan.getRequestedAmount())
                .build());
        log.info("Credit evaluation for loan {}: score {} grade {}", id, score.getInternalScore(), score.getRiskGrade());
        loan.setCreditScore(score.getInternalScore());
        loan.setRiskGrade(score.getRiskGrade());
        loan.setInterestRate(deriveInterestRate(score.getRiskGrade()));
        loan.setStatus(LoanStatus.CREDIT_EVALUATED);
        loan.setDecisionRemarks(remarks);
        return loanMapper.toResponseDTO(loanRepository.save(loan));
    }

    @Override
    @Transactional
    public LoanResponseDTO approveLoan(Long id, BigDecimal approvedAmount, BigDecimal interestRate,
                                       Integer tenureMonths, String remarks) {
        log.trace("Entering approveLoan with id={}", id);
        LoanApplication loan = findLoan(id);
        if (loan.getStatus() != LoanStatus.CREDIT_EVALUATED) {
            throw new InvalidRequestException("Only credit-evaluated applications can be approved by the underwriter");
        }
        if (approvedAmount != null) {
            loan.setRequestedAmount(approvedAmount);
        }
        if (interestRate != null) {
            loan.setInterestRate(interestRate);
        }
        if (tenureMonths != null) {
            loan.setTenureMonths(tenureMonths);
        }
        loan.setStatus(LoanStatus.APPROVED);
        loan.setDecisionRemarks(remarks);
        log.info("Loan {} approved by underwriter (amount {}, rate {}, tenure {})",
                id, loan.getRequestedAmount(), loan.getInterestRate(), loan.getTenureMonths());
        return loanMapper.toResponseDTO(loanRepository.save(loan));
    }

    @Override
    @Transactional
    public LoanResponseDTO rejectLoan(Long id, String remarks) {
        log.trace("Entering rejectLoan with id={}", id);
        LoanApplication loan = findLoan(id);
        if (loan.getStatus() == LoanStatus.DISBURSED) {
            throw new InvalidRequestException("Disbursed loans cannot be rejected");
        }
        loan.setStatus(LoanStatus.REJECTED);
        loan.setDecisionRemarks(remarks);
        log.info("Loan {} rejected", id);
        return loanMapper.toResponseDTO(loanRepository.save(loan));
    }

    @Override
    @Transactional
    public void deleteLoan(Long id) {
        log.trace("Entering deleteLoan with id={}", id);
        LoanApplication loan = findLoan(id);
        if (loan.getStatus() == LoanStatus.APPROVED) {
            throw new InvalidRequestException("Loan application cannot be deleted after approval");
        }
        loanRepository.delete(loan);
        log.info("Loan {} deleted", id);
    }

    private CustomerResponseDTO verifyCustomer(Long customerId) {
        CustomerResponseDTO customer;
        try {
            customer = customerClient.getCustomerById(customerId);
            log.debug("Customer {} fetched: active={}, kycStatus={}",
                    customerId, customer.isActive(), customer.getKycStatus());
        } catch (Exception ex) {
            log.error("Failed to verify customer {}: {}", customerId, ex.getMessage());
            throw new ResourceNotFoundException("Customer not found or unavailable: " + customerId);
        }
        if (!customer.isActive()) {
            throw new InvalidRequestException("Customer account is not active");
        }
        if (customer.getKycStatus() != KycStatusView.VERIFIED) {
            throw new InvalidRequestException("Customer KYC is not verified");
        }
        return customer;
    }

    private BigDecimal deriveInterestRate(String riskGrade) {
        BigDecimal rate = switch (riskGrade) {
            case "LOW" -> BASE_RATE;
            case "MEDIUM" -> BASE_RATE.add(new BigDecimal("3.0"));
            default -> BASE_RATE.add(new BigDecimal("6.0"));
        };
        log.debug("Derived interest rate {} for risk grade {}", rate, riskGrade);
        return rate;
    }

    private LoanApplication findLoan(Long id) {
        log.debug("Looking up loan by id={}", id);
        return loanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Loan not found with id: " + id));
    }
}
