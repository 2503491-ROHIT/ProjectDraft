# Loan Origination & Credit Risk Management System (LOCRMS)

A simple Spring Boot **microservices** project (Java 21) that automates the retail lending
lifecycle: customer onboarding & KYC, loan application, credit scoring, disbursement,
EMI repayment tracking and collections.

The frontend is plain **HTML + Bootstrap 5 + vanilla JavaScript** and talks only to the API Gateway.

---

## 1. Architecture

```
Frontend  ->  API Gateway (JWT validation, CORS, routing)  ->  Business services
                         |
                    Eureka Server  <-  Config Server
```

| Service               | Port | Database         |
|-----------------------|------|------------------|
| config-server         | 8888 | -                |
| eureka-server         | 8761 | -                |
| api-gateway           | 9090 | -                |
| auth-service          | 8081 | auth_db          |
| customer-service      | 8082 | customer_db      |
| loan-service          | 8083 | loan_db          |
| credit-service        | 8084 | credit_db        |
| disbursement-service  | 8085 | disbursement_db  |
| collections-service   | 8086 | collections_db   |

Databases are created automatically (`createDatabaseIfNotExist=true`).

### Security model
- **auth-service** is the only service that *generates* JWT tokens.
- **api-gateway** is the only component that *validates* JWT tokens. After validation it
  forwards the user details as headers (`X-Auth-User`, `X-Auth-Role`, `X-Auth-UserId`).
- Business services do **not** re-validate the token. They read those headers into the
  Spring Security context and enforce access with `@PreAuthorize` / `hasRole(...)`.

### Roles
`ADMIN`, `CUSTOMER`, `LOAN_OFFICER`, `CREDIT_ANALYST`, `UNDERWRITER`, `COLLECTIONS_AGENT`

---

## 2. Prerequisites
- JDK 21
- Maven 3.9+
- MySQL running on `localhost:3306` (username `root`, password `root` — change in
  `configuration-repo/application.properties` if needed)

---

## 3. How to run (start in this order)

Each service reads its configuration from the config-server, so start it first.

1. `config-server`
2. `eureka-server`
3. `api-gateway`
4. `auth-service`
5. `customer-service`
6. `loan-service`
7. `credit-service`
8. `disbursement-service`
9. `collections-service`

From an IDE just run each `*Application` main class. From a terminal (inside a module folder):

```
./mvnw spring-boot:run
```

> The config-server serves files from the `configuration-repo` folder using
> `file:../configuration-repo`, so run the services from their own module directory
> (the IDE does this automatically).

### Default admin
Created automatically on first startup of auth-service:

```
username: admin@locrms.com
password: Admin@123
```

The Admin creates all employee accounts (Loan Officer, Credit Analyst, Underwriter,
Collections Agent). Customers self-register from the frontend.

---

## 4. Frontend

Open the `loan-origination-frontend` folder with any static server so that the paths
resolve from the site root. Pick whichever you have installed:

**Using Node.js / npx (no install needed) — run on port 5500:**
```
cd loan-origination-frontend
npx http-server -p 5500 -c-1
```

**Using Python:**
```
cd loan-origination-frontend
python -m http.server 5500
```

Then browse to `http://localhost:5500/login.html`.
All API calls go to the gateway at `http://localhost:9090` (see `assets/js/config.js`).

> Important: always start the server from **inside** the `loan-origination-frontend`
> folder so that the root-absolute paths (e.g. `/assets/js/config.js`, `/login.html`)
> resolve correctly.

---

## 5. Business workflow

```
Customer registers -> uploads KYC (PDF/JPG/JPEG)
Loan Officer verifies KYC
Customer submits loan application
Loan Officer checks eligibility -> forwards to Credit Analyst
Credit Analyst fetches bureau score, computes internal score, assigns risk grade -> forwards to Underwriter
Underwriter approves / rejects
Loan Officer disburses approved loan -> EMI schedule generated
Customer pays EMIs
Admin flags overdue loans -> assigns a Collections Agent
Collections Agent records recovery actions -> marks Recovered / Written Off
```

---

## 6. Logs
Each service writes to a `logs/<service>.log` file (see the `logback.xml` in each module).

