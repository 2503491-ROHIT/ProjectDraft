package com.genc.auth_service.dto;

import com.genc.auth_service.enums.RoleType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Sent by the customer-service (through a client) to create the login
 * credentials of a newly registered customer.
 */
@Data
public class RegisterCustomerRequest {

    @NotBlank(message = "Full Name is required")
    private String fullName;

    @NotBlank(message = "Username is required")
    @Email(message = "Enter a valid email")
    private String username;

    @NotBlank(message = "Password is required")
    private String password;

    // Role is always CUSTOMER but kept for clarity
    private RoleType role = RoleType.CUSTOMER;
}

