package com.genc.auth_service.enums;

/**
 * All roles supported by the system. A user can have exactly one role.
 */
public enum RoleType {
    ADMIN,
    CUSTOMER,
    LOAN_OFFICER,
    CREDIT_ANALYST,
    UNDERWRITER,
    COLLECTIONS_AGENT
}

