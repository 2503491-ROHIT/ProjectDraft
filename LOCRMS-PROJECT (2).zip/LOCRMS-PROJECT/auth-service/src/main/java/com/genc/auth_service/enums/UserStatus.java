package com.genc.auth_service.enums;

/**
 * Whether a user account is allowed to log in or not.
 */
public enum UserStatus {
    ACTIVE,
    INACTIVE
}

