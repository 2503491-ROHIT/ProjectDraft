package com.genc.auth_service.repository;

import com.genc.auth_service.entity.User;
import com.genc.auth_service.enums.RoleType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    boolean existsByUsername(String username);

    List<User> findByRole(RoleType role);

    List<User> findByRoleNot(RoleType role);
}

