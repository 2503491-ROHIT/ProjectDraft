package com.genc.auth_service.service;

import com.genc.auth_service.dto.ChangePasswordRequest;
import com.genc.auth_service.dto.LoginRequest;
import com.genc.auth_service.dto.LoginResponse;

public interface AuthService {

    LoginResponse login(LoginRequest request);

    void changePassword(ChangePasswordRequest request);
}

