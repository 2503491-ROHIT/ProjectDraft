package com.genc.auth_service.service;

import com.genc.auth_service.dto.CreateEmployeeRequest;
import com.genc.auth_service.dto.RegisterCustomerRequest;
import com.genc.auth_service.dto.UpdateUserStatusRequest;
import com.genc.auth_service.dto.UserResponse;

import java.util.List;

public interface UserService {

    UserResponse createEmployee(CreateEmployeeRequest request);

    UserResponse registerCustomer(RegisterCustomerRequest request);

    List<UserResponse> getAllUsers();

    List<UserResponse> getEmployees();

    UserResponse getUserById(Long id);

    UserResponse updateStatus(Long id, UpdateUserStatusRequest request);
}

