package com.genc.auth_service.service.impl;

import com.genc.auth_service.dto.ChangePasswordRequest;
import com.genc.auth_service.dto.LoginRequest;
import com.genc.auth_service.dto.LoginResponse;
import com.genc.auth_service.entity.User;
import com.genc.auth_service.enums.UserStatus;
import com.genc.auth_service.exception.InvalidCredentialsException;
import com.genc.auth_service.exception.ResourceNotFoundException;
import com.genc.auth_service.repository.UserRepository;
import com.genc.auth_service.security.JwtUtil;
import com.genc.auth_service.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthServiceImpl.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    @Override
    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new InvalidCredentialsException("Invalid username or password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.warn("Failed login attempt for user {}", request.getUsername());
            throw new InvalidCredentialsException("Invalid username or password");
        }

        if (user.getStatus() == UserStatus.INACTIVE) {
            throw new InvalidCredentialsException("Account is inactive. Please contact the administrator.");
        }

        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), user.getRole().name());
        log.info("User {} logged in successfully with role {}", user.getUsername(), user.getRole());
        return new LoginResponse(token, user.getId(), user.getUsername(), user.getFullName(), user.getRole().name());
    }

    @Override
    public void changePassword(ChangePasswordRequest request) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
            throw new InvalidCredentialsException("Old password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        log.info("Password changed for user {}", user.getUsername());
    }
}

