package com.genc.auth_service.service.impl;

import com.genc.auth_service.dto.CreateEmployeeRequest;
import com.genc.auth_service.dto.RegisterCustomerRequest;
import com.genc.auth_service.dto.UpdateUserStatusRequest;
import com.genc.auth_service.dto.UserResponse;
import com.genc.auth_service.entity.User;
import com.genc.auth_service.enums.RoleType;
import com.genc.auth_service.enums.UserStatus;
import com.genc.auth_service.exception.DuplicateResourceException;
import com.genc.auth_service.exception.ResourceNotFoundException;
import com.genc.auth_service.repository.UserRepository;
import com.genc.auth_service.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserResponse createEmployee(CreateEmployeeRequest request) {
        if (request.getRole() == RoleType.ADMIN || request.getRole() == RoleType.CUSTOMER) {
            throw new DuplicateResourceException("Only employee roles can be created here");
        }
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username already exists");
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .status(UserStatus.ACTIVE)
                .build();

        User saved = userRepository.save(user);
        log.info("Employee account created: {} ({})", saved.getUsername(), saved.getRole());
        return toResponse(saved);
    }

    @Override
    public UserResponse registerCustomer(RegisterCustomerRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username already exists");
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(RoleType.CUSTOMER)
                .status(UserStatus.ACTIVE)
                .build();

        User saved = userRepository.save(user);
        log.info("Customer login created: {}", saved.getUsername());
        return toResponse(saved);
    }

    @Override
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public List<UserResponse> getEmployees() {
        // Everyone except plain customers
        return userRepository.findAll().stream()
                .filter(u -> u.getRole() != RoleType.CUSTOMER && u.getRole() != RoleType.ADMIN)
                .map(this::toResponse)
                .toList();
    }

    @Override
    public UserResponse getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        return toResponse(user);
    }

    @Override
    public UserResponse updateStatus(Long id, UpdateUserStatusRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        user.setStatus(request.getStatus());
        User saved = userRepository.save(user);
        log.info("User {} status changed to {}", saved.getUsername(), saved.getStatus());
        return toResponse(saved);
    }

    private UserResponse toResponse(User user) {
        return new UserResponse(user.getId(), user.getUsername(), user.getFullName(),
                user.getRole().name(), user.getStatus().name(), user.getCreatedAt());
    }
}

