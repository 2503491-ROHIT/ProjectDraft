package com.genc.collections_service.client;

import com.genc.collections_service.dto.ApiResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Reads how many days a loan is past due from the disbursement-service.
 */
@FeignClient(name = "disbursement-service")
public interface DisbursementClient {

    @GetMapping("/disbursements/{applicationId}/overdue-days")
    ApiResponse<Integer> getOverdueDays(@PathVariable("applicationId") Long applicationId);
}

