package com.genc.collections_service.controller;

import com.genc.collections_service.dto.*;
import com.genc.collections_service.service.CollectionsService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/collections")
public class CollectionsController {

    private final CollectionsService collectionsService;

    public CollectionsController(CollectionsService collectionsService) {
        this.collectionsService = collectionsService;
    }

    // Admin flags an overdue loan as delinquent
    @PostMapping("/flag")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<CaseResponse>> flag(@Valid @RequestBody FlagAccountRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Account flagged as delinquent",
                collectionsService.flagAccount(request)));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<CaseResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Cases fetched", collectionsService.getAllCases()));
    }

    @GetMapping("/{caseId}")
    public ResponseEntity<ApiResponse<CaseResponse>> getCase(@PathVariable Long caseId) {
        return ResponseEntity.ok(ApiResponse.success("Case fetched", collectionsService.getCase(caseId)));
    }

    // Admin assigns a collections agent
    @PatchMapping("/{caseId}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<CaseResponse>> assign(@PathVariable Long caseId,
                                                            @Valid @RequestBody AssignAgentRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Agent assigned",
                collectionsService.assignAgent(caseId, request)));
    }

    // Agent views the cases assigned to them
    @GetMapping("/agent/{agentId}")
    @PreAuthorize("hasRole('COLLECTIONS_AGENT')")
    public ResponseEntity<ApiResponse<List<CaseResponse>>> byAgent(@PathVariable Long agentId) {
        return ResponseEntity.ok(ApiResponse.success("Assigned cases fetched",
                collectionsService.getCasesByAgent(agentId)));
    }

    // Agent records a recovery action
    @PostMapping("/{caseId}/recovery-action")
    @PreAuthorize("hasRole('COLLECTIONS_AGENT')")
    public ResponseEntity<ApiResponse<RecoveryActionResponse>> recoveryAction(@PathVariable Long caseId,
                                                                              @Valid @RequestBody RecoveryActionRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Recovery action recorded",
                collectionsService.logRecoveryAction(caseId, request)));
    }

    @GetMapping("/{caseId}/history")
    @PreAuthorize("hasRole('COLLECTIONS_AGENT')")
    public ResponseEntity<ApiResponse<List<RecoveryActionResponse>>> history(@PathVariable Long caseId) {
        return ResponseEntity.ok(ApiResponse.success("Recovery history fetched",
                collectionsService.getRecoveryHistory(caseId)));
    }

    // Agent marks case as RECOVERED or WRITTEN_OFF
    @PatchMapping("/{caseId}/status")
    @PreAuthorize("hasRole('COLLECTIONS_AGENT')")
    public ResponseEntity<ApiResponse<CaseResponse>> updateStatus(@PathVariable Long caseId,
                                                                  @Valid @RequestBody UpdateRecoveryStatusRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Recovery status updated",
                collectionsService.updateRecoveryStatus(caseId, request)));
    }
}

