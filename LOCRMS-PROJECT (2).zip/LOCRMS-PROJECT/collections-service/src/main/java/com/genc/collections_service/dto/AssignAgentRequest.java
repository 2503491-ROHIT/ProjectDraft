package com.genc.collections_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Admin assigns a collections agent to a delinquent case.
 */
@Data
public class AssignAgentRequest {

    @NotNull(message = "Agent id is required")
    private Long agentId;

    @NotBlank(message = "Agent name is required")
    private String agentName;
}

