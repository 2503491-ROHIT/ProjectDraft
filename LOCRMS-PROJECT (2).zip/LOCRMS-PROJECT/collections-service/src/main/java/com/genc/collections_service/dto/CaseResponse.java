package com.genc.collections_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseResponse {
    private Long caseId;
    private Long applicationId;
    private Long customerId;
    private Integer daysPastDue;
    private Long assignedAgentId;
    private String assignedAgentName;
    private String recoveryStatus;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

