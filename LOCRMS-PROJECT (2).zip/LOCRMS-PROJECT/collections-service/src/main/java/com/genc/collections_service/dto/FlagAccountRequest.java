package com.genc.collections_service.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Admin flags an overdue loan as delinquent.
 */
@Data
public class FlagAccountRequest {

    @NotNull(message = "Application id is required")
    private Long applicationId;

    @NotNull(message = "Customer id is required")
    private Long customerId;
}

