package com.genc.collections_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Collections agent records a recovery action for a case.
 */
@Data
public class RecoveryActionRequest {

    @NotBlank(message = "Action taken is required")
    private String actionTaken;

    private String remarks;
}

