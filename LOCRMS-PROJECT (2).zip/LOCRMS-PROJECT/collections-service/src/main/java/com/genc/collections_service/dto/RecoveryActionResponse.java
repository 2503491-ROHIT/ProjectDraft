package com.genc.collections_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecoveryActionResponse {
    private Long id;
    private Long caseId;
    private String actionTaken;
    private String remarks;
    private LocalDateTime actionDate;
}

