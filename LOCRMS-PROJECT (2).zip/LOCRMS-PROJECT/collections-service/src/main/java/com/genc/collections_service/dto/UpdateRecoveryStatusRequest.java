package com.genc.collections_service.dto;

import com.genc.collections_service.enums.RecoveryStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Collections agent marks a case as RECOVERED or WRITTEN_OFF.
 */
@Data
public class UpdateRecoveryStatusRequest {

    @NotNull(message = "Recovery status is required")
    private RecoveryStatus status;
}

