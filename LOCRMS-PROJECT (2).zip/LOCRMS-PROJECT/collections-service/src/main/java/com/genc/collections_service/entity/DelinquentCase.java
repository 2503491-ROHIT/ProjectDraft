package com.genc.collections_service.entity;

import com.genc.collections_service.enums.RecoveryStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "delinquent_cases")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DelinquentCase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long caseId;

    private Long applicationId;
    private Long customerId;
    private Integer daysPastDue;

    // Collections agent assigned by the admin
    private Long assignedAgentId;
    private String assignedAgentName;

    @Enumerated(EnumType.STRING)
    private RecoveryStatus recoveryStatus;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.recoveryStatus == null) {
            this.recoveryStatus = RecoveryStatus.PENDING;
        }
    }

    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}

