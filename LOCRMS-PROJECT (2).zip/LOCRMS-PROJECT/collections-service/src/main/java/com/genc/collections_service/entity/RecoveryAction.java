package com.genc.collections_service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * A recovery action logged by the collections agent for a case.
 * Kept in a separate table to maintain a full recovery history.
 */
@Entity
@Table(name = "recovery_actions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecoveryAction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long caseId;

    private String actionTaken;
    private String remarks;

    private LocalDateTime actionDate;

    @PrePersist
    public void onCreate() {
        this.actionDate = LocalDateTime.now();
    }
}

