package com.genc.collections_service.enums;

public enum RecoveryStatus {
    PENDING,
    RECOVERED,
    WRITTEN_OFF
}

