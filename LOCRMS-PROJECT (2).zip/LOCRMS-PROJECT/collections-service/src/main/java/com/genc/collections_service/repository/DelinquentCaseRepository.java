package com.genc.collections_service.repository;

import com.genc.collections_service.entity.DelinquentCase;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DelinquentCaseRepository extends JpaRepository<DelinquentCase, Long> {

    List<DelinquentCase> findByAssignedAgentId(Long agentId);

    Optional<DelinquentCase> findByApplicationId(Long applicationId);
}

