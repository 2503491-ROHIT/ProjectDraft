package com.genc.collections_service.repository;

import com.genc.collections_service.entity.RecoveryAction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RecoveryActionRepository extends JpaRepository<RecoveryAction, Long> {

    List<RecoveryAction> findByCaseIdOrderByActionDateDesc(Long caseId);
}

