package com.genc.collections_service.service;

import com.genc.collections_service.dto.*;

import java.util.List;

public interface CollectionsService {

    CaseResponse flagAccount(FlagAccountRequest request);

    List<CaseResponse> getAllCases();

    CaseResponse getCase(Long caseId);

    CaseResponse assignAgent(Long caseId, AssignAgentRequest request);

    List<CaseResponse> getCasesByAgent(Long agentId);

    RecoveryActionResponse logRecoveryAction(Long caseId, RecoveryActionRequest request);

    List<RecoveryActionResponse> getRecoveryHistory(Long caseId);

    CaseResponse updateRecoveryStatus(Long caseId, UpdateRecoveryStatusRequest request);
}

