package com.genc.collections_service.service.impl;

import com.genc.collections_service.client.DisbursementClient;
import com.genc.collections_service.dto.*;
import com.genc.collections_service.entity.DelinquentCase;
import com.genc.collections_service.entity.RecoveryAction;
import com.genc.collections_service.enums.RecoveryStatus;
import com.genc.collections_service.exception.InvalidOperationException;
import com.genc.collections_service.exception.ResourceNotFoundException;
import com.genc.collections_service.repository.DelinquentCaseRepository;
import com.genc.collections_service.repository.RecoveryActionRepository;
import com.genc.collections_service.service.CollectionsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CollectionsServiceImpl implements CollectionsService {

    private static final Logger log = LoggerFactory.getLogger(CollectionsServiceImpl.class);

    private final DelinquentCaseRepository caseRepository;
    private final RecoveryActionRepository actionRepository;
    private final DisbursementClient disbursementClient;

    public CollectionsServiceImpl(DelinquentCaseRepository caseRepository,
                                  RecoveryActionRepository actionRepository,
                                  DisbursementClient disbursementClient) {
        this.caseRepository = caseRepository;
        this.actionRepository = actionRepository;
        this.disbursementClient = disbursementClient;
    }

    @Override
    public CaseResponse flagAccount(FlagAccountRequest request) {
        if (caseRepository.findByApplicationId(request.getApplicationId()).isPresent()) {
            throw new InvalidOperationException("This loan is already flagged as delinquent");
        }

        // Find out how overdue the loan is from the disbursement-service
        Integer daysPastDue = disbursementClient.getOverdueDays(request.getApplicationId()).getData();
        if (daysPastDue == null || daysPastDue <= 0) {
            throw new InvalidOperationException("Loan is not overdue, cannot flag as delinquent");
        }

        DelinquentCase delinquentCase = DelinquentCase.builder()
                .applicationId(request.getApplicationId())
                .customerId(request.getCustomerId())
                .daysPastDue(daysPastDue)
                .recoveryStatus(RecoveryStatus.PENDING)
                .build();
        DelinquentCase saved = caseRepository.save(delinquentCase);
        log.info("Loan {} flagged as delinquent ({} days past due)", request.getApplicationId(), daysPastDue);
        return toResponse(saved);
    }

    @Override
    public List<CaseResponse> getAllCases() {
        return caseRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public CaseResponse getCase(Long caseId) {
        return toResponse(findCase(caseId));
    }

    @Override
    public CaseResponse assignAgent(Long caseId, AssignAgentRequest request) {
        DelinquentCase delinquentCase = findCase(caseId);
        delinquentCase.setAssignedAgentId(request.getAgentId());
        delinquentCase.setAssignedAgentName(request.getAgentName());
        DelinquentCase saved = caseRepository.save(delinquentCase);
        log.info("Case {} assigned to agent {}", caseId, request.getAgentName());
        return toResponse(saved);
    }

    @Override
    public List<CaseResponse> getCasesByAgent(Long agentId) {
        return caseRepository.findByAssignedAgentId(agentId).stream().map(this::toResponse).toList();
    }

    @Override
    public RecoveryActionResponse logRecoveryAction(Long caseId, RecoveryActionRequest request) {
        DelinquentCase delinquentCase = findCase(caseId);
        if (delinquentCase.getAssignedAgentId() == null) {
            throw new InvalidOperationException("Case is not assigned to any agent yet");
        }

        RecoveryAction action = RecoveryAction.builder()
                .caseId(caseId)
                .actionTaken(request.getActionTaken())
                .remarks(request.getRemarks())
                .build();
        RecoveryAction saved = actionRepository.save(action);
        log.info("Recovery action logged for case {}: {}", caseId, request.getActionTaken());
        return toActionResponse(saved);
    }

    @Override
    public List<RecoveryActionResponse> getRecoveryHistory(Long caseId) {
        return actionRepository.findByCaseIdOrderByActionDateDesc(caseId).stream()
                .map(this::toActionResponse).toList();
    }

    @Override
    public CaseResponse updateRecoveryStatus(Long caseId, UpdateRecoveryStatusRequest request) {
        if (request.getStatus() == RecoveryStatus.PENDING) {
            throw new InvalidOperationException("Status can only be set to RECOVERED or WRITTEN_OFF");
        }
        DelinquentCase delinquentCase = findCase(caseId);
        delinquentCase.setRecoveryStatus(request.getStatus());
        DelinquentCase saved = caseRepository.save(delinquentCase);
        log.info("Case {} marked as {}", caseId, request.getStatus());
        return toResponse(saved);
    }

    private DelinquentCase findCase(Long caseId) {
        return caseRepository.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found with id " + caseId));
    }

    private CaseResponse toResponse(DelinquentCase c) {
        return new CaseResponse(c.getCaseId(), c.getApplicationId(), c.getCustomerId(), c.getDaysPastDue(),
                c.getAssignedAgentId(), c.getAssignedAgentName(), c.getRecoveryStatus().name(),
                c.getCreatedAt(), c.getUpdatedAt());
    }

    private RecoveryActionResponse toActionResponse(RecoveryAction a) {
        return new RecoveryActionResponse(a.getId(), a.getCaseId(), a.getActionTaken(), a.getRemarks(), a.getActionDate());
    }
}

