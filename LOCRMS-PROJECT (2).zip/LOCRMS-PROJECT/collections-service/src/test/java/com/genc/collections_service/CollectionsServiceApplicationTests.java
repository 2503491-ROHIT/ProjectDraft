package com.genc.collections_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollectionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
