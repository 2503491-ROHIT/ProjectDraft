package com.genc.credit_service.client;

import com.genc.credit_service.dto.ApiResponse;
import com.genc.credit_service.dto.LoanCreditUpdateRequest;
import com.genc.credit_service.dto.LoanDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Reads the loan details and pushes the credit evaluation result back to the loan-service.
 */
@FeignClient(name = "loan-service")
public interface LoanClient {

    @GetMapping("/loans/{id}")
    ApiResponse<LoanDto> getLoan(@PathVariable("id") Long id);

    @PatchMapping("/loans/{id}/credit-evaluation")
    ApiResponse<Void> updateCredit(@PathVariable("id") Long id, @RequestBody LoanCreditUpdateRequest request);
}

