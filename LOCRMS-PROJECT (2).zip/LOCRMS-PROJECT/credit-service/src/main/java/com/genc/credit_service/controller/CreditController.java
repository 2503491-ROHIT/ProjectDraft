package com.genc.credit_service.controller;

import com.genc.credit_service.dto.ApiResponse;
import com.genc.credit_service.dto.BureauScoreResponse;
import com.genc.credit_service.dto.CreditEvaluationRequest;
import com.genc.credit_service.dto.CreditEvaluationResponse;
import com.genc.credit_service.service.CreditService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/credit")
public class CreditController {

    private final CreditService creditService;

    public CreditController(CreditService creditService) {
        this.creditService = creditService;
    }

    @GetMapping("/bureau-score/{customerId}")
    @PreAuthorize("hasRole('CREDIT_ANALYST')")
    public ResponseEntity<ApiResponse<BureauScoreResponse>> bureauScore(@PathVariable Long customerId) {
        return ResponseEntity.ok(ApiResponse.success("Bureau score fetched", creditService.fetchBureauScore(customerId)));
    }

    @PostMapping("/evaluate/{applicationId}")
    @PreAuthorize("hasRole('CREDIT_ANALYST')")
    public ResponseEntity<ApiResponse<CreditEvaluationResponse>> evaluate(@PathVariable Long applicationId,
                                                                          @RequestBody(required = false) CreditEvaluationRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Credit evaluation completed",
                creditService.evaluate(applicationId, request)));
    }

    @GetMapping("/{applicationId}")
    public ResponseEntity<ApiResponse<CreditEvaluationResponse>> getByApplication(@PathVariable Long applicationId) {
        return ResponseEntity.ok(ApiResponse.success("Evaluation fetched", creditService.getByApplication(applicationId)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<CreditEvaluationResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Evaluations fetched", creditService.getAll()));
    }
}

