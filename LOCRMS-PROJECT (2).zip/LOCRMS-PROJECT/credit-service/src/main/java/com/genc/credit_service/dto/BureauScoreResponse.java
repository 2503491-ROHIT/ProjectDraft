package com.genc.credit_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response of the mock credit bureau API.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BureauScoreResponse {
    private Long customerId;
    private Integer bureauScore;
}

