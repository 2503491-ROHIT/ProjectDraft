package com.genc.credit_service.dto;

import lombok.Data;

/**
 * Optional remarks the credit analyst adds while evaluating an application.
 */
@Data
public class CreditEvaluationRequest {
    private String remarks;
}

