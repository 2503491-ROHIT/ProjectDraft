package com.genc.credit_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreditEvaluationResponse {
    private Long scoreId;
    private Long applicationId;
    private Long customerId;
    private Integer bureauScore;
    private Integer internalScore;
    private String riskGrade;
    private String remarks;
    private LocalDate evaluationDate;
}

