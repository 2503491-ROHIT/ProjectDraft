package com.genc.credit_service.dto;

import com.genc.credit_service.enums.RiskGrade;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Body sent to the loan-service after the credit evaluation is complete.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanCreditUpdateRequest {
    private Integer creditScore;
    private RiskGrade riskGrade;
    private String creditRemarks;
}

