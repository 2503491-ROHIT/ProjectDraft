package com.genc.credit_service.dto;

import lombok.Data;

/**
 * Loan details fetched from the loan-service to run the credit evaluation.
 */
@Data
public class LoanDto {
    private Long applicationId;
    private Long customerId;
    private Double requestedAmount;
    private Integer tenureMonths;
    private Double monthlyIncome;
    private String applicationStatus;
}

