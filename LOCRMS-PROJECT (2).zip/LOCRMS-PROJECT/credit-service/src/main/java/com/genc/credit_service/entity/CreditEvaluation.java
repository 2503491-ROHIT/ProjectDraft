package com.genc.credit_service.entity;

import com.genc.credit_service.enums.RiskGrade;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "credit_evaluations")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditEvaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scoreId;

    private Long applicationId;
    private Long customerId;

    private Integer bureauScore;
    private Integer internalScore;

    @Enumerated(EnumType.STRING)
    private RiskGrade riskGrade;

    private String remarks;

    private LocalDate evaluationDate;

    @PrePersist
    public void onCreate() {
        this.evaluationDate = LocalDate.now();
    }
}

