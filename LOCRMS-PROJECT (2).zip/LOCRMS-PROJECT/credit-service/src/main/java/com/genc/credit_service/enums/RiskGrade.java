package com.genc.credit_service.enums;

public enum RiskGrade {
    LOW,
    MEDIUM,
    HIGH
}

