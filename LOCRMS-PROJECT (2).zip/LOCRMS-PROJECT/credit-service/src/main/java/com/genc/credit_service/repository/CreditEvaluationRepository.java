package com.genc.credit_service.repository;

import com.genc.credit_service.entity.CreditEvaluation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CreditEvaluationRepository extends JpaRepository<CreditEvaluation, Long> {

    Optional<CreditEvaluation> findByApplicationId(Long applicationId);
}

