package com.genc.credit_service.service;

import com.genc.credit_service.dto.BureauScoreResponse;
import com.genc.credit_service.dto.CreditEvaluationRequest;
import com.genc.credit_service.dto.CreditEvaluationResponse;

import java.util.List;

public interface CreditService {

    BureauScoreResponse fetchBureauScore(Long customerId);

    CreditEvaluationResponse evaluate(Long applicationId, CreditEvaluationRequest request);

    CreditEvaluationResponse getByApplication(Long applicationId);

    List<CreditEvaluationResponse> getAll();
}

