package com.genc.credit_service.service.impl;

import com.genc.credit_service.client.LoanClient;
import com.genc.credit_service.dto.*;
import com.genc.credit_service.entity.CreditEvaluation;
import com.genc.credit_service.enums.RiskGrade;
import com.genc.credit_service.exception.ResourceNotFoundException;
import com.genc.credit_service.repository.CreditEvaluationRepository;
import com.genc.credit_service.service.CreditService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class CreditServiceImpl implements CreditService {

    private static final Logger log = LoggerFactory.getLogger(CreditServiceImpl.class);

    private final CreditEvaluationRepository creditRepository;
    private final LoanClient loanClient;

    public CreditServiceImpl(CreditEvaluationRepository creditRepository, LoanClient loanClient) {
        this.creditRepository = creditRepository;
        this.loanClient = loanClient;
    }

    /**
     * Mock credit bureau API. Returns a score between 550 and 800.
     */
    @Override
    public BureauScoreResponse fetchBureauScore(Long customerId) {
        int score = ThreadLocalRandom.current().nextInt(550, 801);
        log.info("Fetched mock bureau score {} for customer {}", score, customerId);
        return new BureauScoreResponse(customerId, score);
    }

    @Override
    public CreditEvaluationResponse evaluate(Long applicationId, CreditEvaluationRequest request) {
        LoanDto loan = loanClient.getLoan(applicationId).getData();
        if (loan == null) {
            throw new ResourceNotFoundException("Loan application not found");
        }

        int bureauScore = fetchBureauScore(loan.getCustomerId()).getBureauScore();
        int internalScore = calculateInternalScore(bureauScore, loan);
        RiskGrade riskGrade = assignRiskGrade(internalScore);

        CreditEvaluation evaluation = creditRepository.findByApplicationId(applicationId)
                .orElse(CreditEvaluation.builder().applicationId(applicationId).build());
        evaluation.setCustomerId(loan.getCustomerId());
        evaluation.setBureauScore(bureauScore);
        evaluation.setInternalScore(internalScore);
        evaluation.setRiskGrade(riskGrade);
        evaluation.setRemarks(request != null ? request.getRemarks() : null);

        CreditEvaluation saved = creditRepository.save(evaluation);

        // Push the result back to the loan-service and forward to the underwriter
        LoanCreditUpdateRequest update = new LoanCreditUpdateRequest(internalScore, riskGrade, evaluation.getRemarks());
        loanClient.updateCredit(applicationId, update);

        log.info("Credit evaluation done for loan {}: score={} grade={}", applicationId, internalScore, riskGrade);
        return toResponse(saved);
    }

    @Override
    public CreditEvaluationResponse getByApplication(Long applicationId) {
        CreditEvaluation evaluation = creditRepository.findByApplicationId(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("No evaluation found for application " + applicationId));
        return toResponse(evaluation);
    }

    @Override
    public List<CreditEvaluationResponse> getAll() {
        return creditRepository.findAll().stream().map(this::toResponse).toList();
    }

    // Internal score blends bureau score with the loan-to-income ratio
    private int calculateInternalScore(int bureauScore, LoanDto loan) {
        int score = bureauScore;
        double income = loan.getMonthlyIncome() == null ? 0 : loan.getMonthlyIncome();
        double emi = (loan.getRequestedAmount() != null && loan.getTenureMonths() != null && loan.getTenureMonths() > 0)
                ? loan.getRequestedAmount() / loan.getTenureMonths() : 0;

        if (income > 0) {
            double ratio = emi / income;
            if (ratio < 0.3) {
                score += 30;
            } else if (ratio > 0.5) {
                score -= 40;
            }
        }
        // Keep the score inside a sensible range
        return Math.max(300, Math.min(900, score));
    }

    private RiskGrade assignRiskGrade(int internalScore) {
        if (internalScore >= 750) {
            return RiskGrade.LOW;
        } else if (internalScore >= 650) {
            return RiskGrade.MEDIUM;
        }
        return RiskGrade.HIGH;
    }

    private CreditEvaluationResponse toResponse(CreditEvaluation e) {
        return new CreditEvaluationResponse(e.getScoreId(), e.getApplicationId(), e.getCustomerId(),
                e.getBureauScore(), e.getInternalScore(),
                e.getRiskGrade() != null ? e.getRiskGrade().name() : null,
                e.getRemarks(), e.getEvaluationDate());
    }
}

