package com.genc.customer_service.client;

import com.genc.customer_service.dto.ApiResponse;
import com.genc.customer_service.dto.AuthRegisterRequest;
import com.genc.customer_service.dto.AuthUserResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Calls the auth-service to create the login credentials of a new customer.
 */
@FeignClient(name = "auth-service")
public interface AuthClient {

    @PostMapping("/auth/register-customer")
    ApiResponse<AuthUserResponse> registerCustomer(@RequestBody AuthRegisterRequest request);
}

