package com.genc.customer_service.controller;

import com.genc.customer_service.dto.*;
import com.genc.customer_service.entity.KycDocument;
import com.genc.customer_service.enums.DocumentType;
import com.genc.customer_service.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    // Public - a new customer registers here
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<CustomerResponse>> register(@Valid @RequestBody CustomerRegisterRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Registration successful", customerService.register(request)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<CustomerResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Customer fetched", customerService.getById(id)));
    }

    @GetMapping("/user/{authUserId}")
    public ResponseEntity<ApiResponse<CustomerResponse>> getByUser(@PathVariable Long authUserId) {
        return ResponseEntity.ok(ApiResponse.success("Customer fetched", customerService.getByAuthUserId(authUserId)));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','LOAN_OFFICER','CREDIT_ANALYST','UNDERWRITER')")
    public ResponseEntity<ApiResponse<List<CustomerResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Customers fetched", customerService.getAll()));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<ApiResponse<CustomerResponse>> update(@PathVariable Long id,
                                                                @Valid @RequestBody CustomerUpdateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Profile updated", customerService.updateProfile(id, request)));
    }

    // ---------- KYC ----------

    @PostMapping("/{id}/kyc")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<ApiResponse<KycDocumentResponse>> uploadKyc(@PathVariable Long id,
                                                                      @RequestParam("documentType") DocumentType documentType,
                                                                      @RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(ApiResponse.success("Document uploaded",
                customerService.uploadKyc(id, documentType, file)));
    }

    @GetMapping("/{id}/kyc")
    public ResponseEntity<ApiResponse<List<KycDocumentResponse>>> getKyc(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Documents fetched", customerService.getKycDocuments(id)));
    }

    @GetMapping("/kyc/{docId}/download")
    public ResponseEntity<ByteArrayResource> download(@PathVariable Long docId) {
        KycDocument doc = customerService.downloadKyc(docId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + doc.getFileName() + "\"")
                .contentType(MediaType.parseMediaType(doc.getFileType()))
                .body(new ByteArrayResource(doc.getData()));
    }

    @GetMapping("/{id}/kyc/status")
    public ResponseEntity<ApiResponse<String>> kycStatus(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("KYC status", customerService.getKycStatus(id)));
    }

    @GetMapping("/kyc/pending")
    @PreAuthorize("hasRole('LOAN_OFFICER')")
    public ResponseEntity<ApiResponse<List<CustomerResponse>>> pendingKyc() {
        return ResponseEntity.ok(ApiResponse.success("Pending KYC", customerService.getPendingKyc()));
    }

    @PatchMapping("/{id}/kyc/verify")
    @PreAuthorize("hasRole('LOAN_OFFICER')")
    public ResponseEntity<ApiResponse<CustomerResponse>> verifyKyc(@PathVariable Long id,
                                                                   @Valid @RequestBody KycStatusUpdateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("KYC status updated",
                customerService.updateKycStatus(id, request)));
    }
}

