package com.genc.customer_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Body sent to auth-service to create the customer's login account.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthRegisterRequest {
    private String fullName;
    private String username;
    private String password;
}

