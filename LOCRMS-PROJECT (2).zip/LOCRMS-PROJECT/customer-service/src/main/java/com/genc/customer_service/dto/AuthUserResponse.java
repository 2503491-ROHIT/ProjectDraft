package com.genc.customer_service.dto;

import lombok.Data;

/**
 * The "data" part of the auth-service response when a login account is created.
 */
@Data
public class AuthUserResponse {
    private Long id;
    private String username;
    private String fullName;
    private String role;
    private String status;
}

