package com.genc.customer_service.dto;

import com.genc.customer_service.enums.EmploymentType;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CustomerRegisterRequest {

    @NotBlank(message = "Full Name is required")
    private String fullName;

    @NotBlank(message = "Email is required")
    @Email(message = "Enter a valid email")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Enter a valid 10 digit phone number")
    private String phone;

    @NotBlank(message = "PAN Number is required")
    @Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]$", message = "Invalid PAN Number")
    private String panNumber;

    @NotBlank(message = "Aadhaar Number is required")
    @Pattern(regexp = "^\\d{12}$", message = "Aadhaar must be 12 digits")
    private String aadhaarNumber;

    private String address;

    @NotNull(message = "Monthly income is required")
    @Positive(message = "Monthly income must be positive")
    private Double monthlyIncome;

    @NotNull(message = "Employment type is required")
    private EmploymentType employmentType;
}

