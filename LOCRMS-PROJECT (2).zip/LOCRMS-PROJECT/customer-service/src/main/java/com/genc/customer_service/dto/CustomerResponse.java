package com.genc.customer_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerResponse {
    private Long customerId;
    private Long authUserId;
    private String fullName;
    private String email;
    private String phone;
    private String panNumber;
    private String aadhaarNumber;
    private String address;
    private Double monthlyIncome;
    private String employmentType;
    private String kycStatus;
    private String kycRemarks;
    private LocalDate registrationDate;
}

