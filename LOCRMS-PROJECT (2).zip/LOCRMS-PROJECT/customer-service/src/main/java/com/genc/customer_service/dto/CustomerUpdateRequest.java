package com.genc.customer_service.dto;

import com.genc.customer_service.enums.EmploymentType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class CustomerUpdateRequest {

    @NotBlank(message = "Full Name is required")
    private String fullName;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Enter a valid 10 digit phone number")
    private String phone;

    private String address;

    private Double monthlyIncome;

    private EmploymentType employmentType;
}

