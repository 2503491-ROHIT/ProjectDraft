package com.genc.customer_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KycDocumentResponse {
    private Long id;
    private Long customerId;
    private String documentType;
    private String fileName;
    private String fileType;
    private LocalDateTime uploadedAt;
}

