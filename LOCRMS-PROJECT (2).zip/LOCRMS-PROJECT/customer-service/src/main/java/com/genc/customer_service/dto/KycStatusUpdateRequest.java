package com.genc.customer_service.dto;

import com.genc.customer_service.enums.KycStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class KycStatusUpdateRequest {

    @NotNull(message = "KYC status is required")
    private KycStatus status;

    private String remarks;
}

