package com.genc.customer_service.entity;

import com.genc.customer_service.enums.EmploymentType;
import com.genc.customer_service.enums.KycStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "customers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;

    // Links to the login account created in auth-service
    private Long authUserId;

    private String fullName;

    @Column(unique = true)
    private String email;

    private String phone;

    @Column(unique = true)
    private String panNumber;

    @Column(unique = true)
    private String aadhaarNumber;

    private String address;

    private Double monthlyIncome;

    @Enumerated(EnumType.STRING)
    private EmploymentType employmentType;

    @Enumerated(EnumType.STRING)
    private KycStatus kycStatus;

    private String kycRemarks;

    private LocalDate registrationDate;

    @PrePersist
    public void onCreate() {
        this.registrationDate = LocalDate.now();
        if (this.kycStatus == null) {
            this.kycStatus = KycStatus.PENDING;
        }
    }
}

