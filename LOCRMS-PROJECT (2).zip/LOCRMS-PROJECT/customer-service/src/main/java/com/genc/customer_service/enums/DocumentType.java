package com.genc.customer_service.enums;

public enum DocumentType {
    PAN,
    AADHAAR
}

