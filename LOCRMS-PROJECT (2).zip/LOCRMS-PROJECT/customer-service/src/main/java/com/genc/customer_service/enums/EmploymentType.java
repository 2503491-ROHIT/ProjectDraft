package com.genc.customer_service.enums;

public enum EmploymentType {
    SALARIED,
    SELF_EMPLOYED,
    BUSINESS,
    UNEMPLOYED
}

