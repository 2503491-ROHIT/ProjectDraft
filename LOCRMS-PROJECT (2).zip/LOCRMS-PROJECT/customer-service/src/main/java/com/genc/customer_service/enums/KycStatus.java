package com.genc.customer_service.enums;

public enum KycStatus {
    PENDING,
    VERIFIED,
    REJECTED
}

