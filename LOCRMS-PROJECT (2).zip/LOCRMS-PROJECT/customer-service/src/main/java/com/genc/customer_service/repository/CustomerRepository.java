package com.genc.customer_service.repository;

import com.genc.customer_service.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    Optional<Customer> findByAuthUserId(Long authUserId);

    Optional<Customer> findByEmail(String email);

    boolean existsByPanNumber(String panNumber);

    boolean existsByAadhaarNumber(String aadhaarNumber);

    boolean existsByEmail(String email);
}

