package com.genc.customer_service.service;

import com.genc.customer_service.dto.*;
import com.genc.customer_service.entity.KycDocument;
import com.genc.customer_service.enums.DocumentType;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface CustomerService {

    CustomerResponse register(CustomerRegisterRequest request);

    CustomerResponse getById(Long customerId);

    CustomerResponse getByAuthUserId(Long authUserId);

    List<CustomerResponse> getAll();

    CustomerResponse updateProfile(Long customerId, CustomerUpdateRequest request);

    KycDocumentResponse uploadKyc(Long customerId, DocumentType documentType, MultipartFile file);

    List<KycDocumentResponse> getKycDocuments(Long customerId);

    KycDocument downloadKyc(Long documentId);

    String getKycStatus(Long customerId);

    List<CustomerResponse> getPendingKyc();

    CustomerResponse updateKycStatus(Long customerId, KycStatusUpdateRequest request);
}


