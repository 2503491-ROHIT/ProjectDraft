package com.genc.customer_service.service.impl;

import com.genc.customer_service.client.AuthClient;
import com.genc.customer_service.dto.*;
import com.genc.customer_service.entity.Customer;
import com.genc.customer_service.entity.KycDocument;
import com.genc.customer_service.enums.DocumentType;
import com.genc.customer_service.enums.KycStatus;
import com.genc.customer_service.exception.DuplicateResourceException;
import com.genc.customer_service.exception.InvalidOperationException;
import com.genc.customer_service.exception.ResourceNotFoundException;
import com.genc.customer_service.repository.CustomerRepository;
import com.genc.customer_service.repository.KycDocumentRepository;
import com.genc.customer_service.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    private static final Logger log = LoggerFactory.getLogger(CustomerServiceImpl.class);

    // Only these file types are accepted for KYC documents
    private static final List<String> ALLOWED_TYPES =
            List.of("application/pdf", "image/jpeg", "image/jpg");

    private final CustomerRepository customerRepository;
    private final KycDocumentRepository kycDocumentRepository;
    private final AuthClient authClient;

    public CustomerServiceImpl(CustomerRepository customerRepository,
                               KycDocumentRepository kycDocumentRepository,
                               AuthClient authClient) {
        this.customerRepository = customerRepository;
        this.kycDocumentRepository = kycDocumentRepository;
        this.authClient = authClient;
    }

    @Override
    public CustomerResponse register(CustomerRegisterRequest request) {
        if (customerRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email is already registered");
        }
        if (customerRepository.existsByPanNumber(request.getPanNumber())) {
            throw new DuplicateResourceException("PAN Number is already registered");
        }
        if (customerRepository.existsByAadhaarNumber(request.getAadhaarNumber())) {
            throw new DuplicateResourceException("Aadhaar Number is already registered");
        }

        // 1. Create login credentials in auth-service
        AuthRegisterRequest authRequest = new AuthRegisterRequest(
                request.getFullName(), request.getEmail(), request.getPassword());
        ApiResponse<AuthUserResponse> authResponse = authClient.registerCustomer(authRequest);
        Long authUserId = authResponse.getData() != null ? authResponse.getData().getId() : null;

        // 2. Save the customer profile
        Customer customer = Customer.builder()
                .authUserId(authUserId)
                .fullName(request.getFullName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .panNumber(request.getPanNumber())
                .aadhaarNumber(request.getAadhaarNumber())
                .address(request.getAddress())
                .monthlyIncome(request.getMonthlyIncome())
                .employmentType(request.getEmploymentType())
                .kycStatus(KycStatus.PENDING)
                .build();

        Customer saved = customerRepository.save(customer);
        log.info("New customer registered: {} (id={})", saved.getEmail(), saved.getCustomerId());
        return toResponse(saved);
    }

    @Override
    public CustomerResponse getById(Long customerId) {
        return toResponse(findCustomer(customerId));
    }

    @Override
    public CustomerResponse getByAuthUserId(Long authUserId) {
        Customer customer = customerRepository.findByAuthUserId(authUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found for user " + authUserId));
        return toResponse(customer);
    }

    @Override
    public List<CustomerResponse> getAll() {
        return customerRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public CustomerResponse updateProfile(Long customerId, CustomerUpdateRequest request) {
        Customer customer = findCustomer(customerId);
        customer.setFullName(request.getFullName());
        customer.setPhone(request.getPhone());
        customer.setAddress(request.getAddress());
        customer.setMonthlyIncome(request.getMonthlyIncome());
        customer.setEmploymentType(request.getEmploymentType());
        Customer saved = customerRepository.save(customer);
        log.info("Customer profile updated: id={}", customerId);
        return toResponse(saved);
    }

    @Override
    public KycDocumentResponse uploadKyc(Long customerId, DocumentType documentType, MultipartFile file) {
        Customer customer = findCustomer(customerId);

        if (file == null || file.isEmpty()) {
            throw new InvalidOperationException("Please select a file to upload");
        }
        if (!ALLOWED_TYPES.contains(file.getContentType())) {
            throw new InvalidOperationException("Only PDF, JPG or JPEG files are allowed");
        }

        try {
            KycDocument document = KycDocument.builder()
                    .customerId(customerId)
                    .documentType(documentType)
                    .fileName(file.getOriginalFilename())
                    .fileType(file.getContentType())
                    .data(file.getBytes())
                    .build();
            KycDocument saved = kycDocumentRepository.save(document);

            // Uploading a document moves KYC back to PENDING for verification
            customer.setKycStatus(KycStatus.PENDING);
            customerRepository.save(customer);

            log.info("KYC document {} uploaded for customer {}", documentType, customerId);
            return toDocumentResponse(saved);
        } catch (IOException e) {
            throw new InvalidOperationException("Could not read the uploaded file");
        }
    }

    @Override
    public List<KycDocumentResponse> getKycDocuments(Long customerId) {
        return kycDocumentRepository.findByCustomerId(customerId).stream()
                .map(this::toDocumentResponse).toList();
    }

    @Override
    public KycDocument downloadKyc(Long documentId) {
        return kycDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found with id " + documentId));
    }

    @Override
    public String getKycStatus(Long customerId) {
        return findCustomer(customerId).getKycStatus().name();
    }

    @Override
    public List<CustomerResponse> getPendingKyc() {
        return customerRepository.findAll().stream()
                .filter(c -> c.getKycStatus() == KycStatus.PENDING)
                .map(this::toResponse)
                .toList();
    }

    @Override
    public CustomerResponse updateKycStatus(Long customerId, KycStatusUpdateRequest request) {
        Customer customer = findCustomer(customerId);
        customer.setKycStatus(request.getStatus());
        customer.setKycRemarks(request.getRemarks());
        Customer saved = customerRepository.save(customer);
        log.info("KYC status for customer {} set to {}", customerId, request.getStatus());
        return toResponse(saved);
    }

    private Customer findCustomer(Long customerId) {
        return customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id " + customerId));
    }

    private CustomerResponse toResponse(Customer c) {
        return new CustomerResponse(c.getCustomerId(), c.getAuthUserId(), c.getFullName(), c.getEmail(),
                c.getPhone(), c.getPanNumber(), c.getAadhaarNumber(), c.getAddress(), c.getMonthlyIncome(),
                c.getEmploymentType() != null ? c.getEmploymentType().name() : null,
                c.getKycStatus().name(), c.getKycRemarks(), c.getRegistrationDate());
    }

    private KycDocumentResponse toDocumentResponse(KycDocument d) {
        return new KycDocumentResponse(d.getId(), d.getCustomerId(), d.getDocumentType().name(),
                d.getFileName(), d.getFileType(), d.getUploadedAt());
    }
}

