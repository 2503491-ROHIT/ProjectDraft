package com.genc.disbursement_service.controller;

import com.genc.disbursement_service.dto.ApiResponse;
import com.genc.disbursement_service.dto.DisburseRequest;
import com.genc.disbursement_service.dto.DisbursementResponse;
import com.genc.disbursement_service.dto.RepaymentResponse;
import com.genc.disbursement_service.service.DisbursementService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/disbursements")
public class DisbursementController {

    private final DisbursementService disbursementService;

    public DisbursementController(DisbursementService disbursementService) {
        this.disbursementService = disbursementService;
    }

    // Called by the loan-service (inter-service) to disburse an approved loan
    @PostMapping
    public ResponseEntity<ApiResponse<DisbursementResponse>> disburse(@Valid @RequestBody DisburseRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Loan disbursed", disbursementService.disburse(request)));
    }

    @GetMapping("/{applicationId}")
    public ResponseEntity<ApiResponse<DisbursementResponse>> getByApplication(@PathVariable Long applicationId) {
        return ResponseEntity.ok(ApiResponse.success("Disbursement fetched",
                disbursementService.getByApplication(applicationId)));
    }

    @GetMapping("/{applicationId}/schedule")
    public ResponseEntity<ApiResponse<List<RepaymentResponse>>> schedule(@PathVariable Long applicationId) {
        return ResponseEntity.ok(ApiResponse.success("EMI schedule fetched",
                disbursementService.getSchedule(applicationId)));
    }

    @PostMapping("/repayments/{repaymentId}/pay")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<ApiResponse<RepaymentResponse>> pay(@PathVariable Long repaymentId) {
        return ResponseEntity.ok(ApiResponse.success("Payment recorded",
                disbursementService.recordRepayment(repaymentId)));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<ApiResponse<List<DisbursementResponse>>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(ApiResponse.success("Disbursements fetched",
                disbursementService.getByCustomer(customerId)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<DisbursementResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Disbursements fetched", disbursementService.getAll()));
    }

    // Used by the collections-service to work out how overdue a loan is
    @GetMapping("/{applicationId}/overdue-days")
    public ResponseEntity<ApiResponse<Integer>> overdueDays(@PathVariable Long applicationId) {
        return ResponseEntity.ok(ApiResponse.success("Overdue days",
                disbursementService.getOverdueDays(applicationId)));
    }
}

