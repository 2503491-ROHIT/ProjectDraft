package com.genc.disbursement_service.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * Sent by the loan-service to disburse an approved loan.
 */
@Data
public class DisburseRequest {

    @NotNull(message = "Application id is required")
    private Long applicationId;

    @NotNull(message = "Customer id is required")
    private Long customerId;

    @NotNull(message = "Loan amount is required")
    @Positive(message = "Loan amount must be positive")
    private Double loanAmount;

    @NotNull(message = "Tenure is required")
    @Positive(message = "Tenure must be positive")
    private Integer tenureMonths;

    @NotNull(message = "Interest rate is required")
    @Positive(message = "Interest rate must be positive")
    private Double interestRate;
}

