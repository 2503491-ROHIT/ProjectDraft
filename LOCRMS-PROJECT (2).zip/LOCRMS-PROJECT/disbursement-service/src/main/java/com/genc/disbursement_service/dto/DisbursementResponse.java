package com.genc.disbursement_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DisbursementResponse {
    private Long id;
    private Long applicationId;
    private Long customerId;
    private Double loanAmount;
    private Integer tenureMonths;
    private Double interestRate;
    private Double emiAmount;
    private LocalDate disbursementDate;
    private String status;
}

