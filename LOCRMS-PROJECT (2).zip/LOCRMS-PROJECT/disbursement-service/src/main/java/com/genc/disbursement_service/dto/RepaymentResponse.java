package com.genc.disbursement_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RepaymentResponse {
    private Long repaymentId;
    private Long disbursementId;
    private Long applicationId;
    private Integer installmentNo;
    private LocalDate dueDate;
    private Double emiAmount;
    private Double paidAmount;
    private String repaymentStatus;
    private LocalDate paidDate;
}

