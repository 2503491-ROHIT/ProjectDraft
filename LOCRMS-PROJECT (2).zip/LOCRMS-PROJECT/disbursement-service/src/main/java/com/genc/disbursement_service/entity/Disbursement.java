package com.genc.disbursement_service.entity;

import com.genc.disbursement_service.enums.DisbursementStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "disbursements")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Disbursement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long applicationId;
    private Long customerId;

    private Double loanAmount;
    private Integer tenureMonths;
    private Double interestRate;
    private Double emiAmount;

    private LocalDate disbursementDate;

    @Enumerated(EnumType.STRING)
    private DisbursementStatus status;

    @PrePersist
    public void onCreate() {
        this.disbursementDate = LocalDate.now();
        if (this.status == null) {
            this.status = DisbursementStatus.ACTIVE;
        }
    }
}

