package com.genc.disbursement_service.entity;

import com.genc.disbursement_service.enums.RepaymentStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * One EMI installment. Kept in a separate table from the disbursement.
 */
@Entity
@Table(name = "repayments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Repayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long repaymentId;

    private Long disbursementId;
    private Long applicationId;

    private Integer installmentNo;
    private LocalDate dueDate;
    private Double emiAmount;
    private Double paidAmount;

    @Enumerated(EnumType.STRING)
    private RepaymentStatus repaymentStatus;

    private LocalDate paidDate;
}

