package com.genc.disbursement_service.enums;

public enum DisbursementStatus {
    ACTIVE,
    CLOSED
}

