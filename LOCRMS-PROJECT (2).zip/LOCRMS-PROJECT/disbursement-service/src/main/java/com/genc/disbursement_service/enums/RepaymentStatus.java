package com.genc.disbursement_service.enums;

public enum RepaymentStatus {
    PENDING,
    PAID,
    OVERDUE
}

