package com.genc.disbursement_service.repository;

import com.genc.disbursement_service.entity.Disbursement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {

    Optional<Disbursement> findByApplicationId(Long applicationId);

    List<Disbursement> findByCustomerId(Long customerId);
}

