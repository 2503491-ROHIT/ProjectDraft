package com.genc.disbursement_service.repository;

import com.genc.disbursement_service.entity.Repayment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RepaymentRepository extends JpaRepository<Repayment, Long> {

    List<Repayment> findByApplicationIdOrderByInstallmentNo(Long applicationId);

    List<Repayment> findByDisbursementIdOrderByInstallmentNo(Long disbursementId);
}

