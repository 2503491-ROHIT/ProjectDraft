package com.genc.disbursement_service.service;

import com.genc.disbursement_service.dto.DisburseRequest;
import com.genc.disbursement_service.dto.DisbursementResponse;
import com.genc.disbursement_service.dto.RepaymentResponse;

import java.util.List;

public interface DisbursementService {

    DisbursementResponse disburse(DisburseRequest request);

    DisbursementResponse getByApplication(Long applicationId);

    List<RepaymentResponse> getSchedule(Long applicationId);

    RepaymentResponse recordRepayment(Long repaymentId);

    List<DisbursementResponse> getByCustomer(Long customerId);

    List<DisbursementResponse> getAll();

    int getOverdueDays(Long applicationId);
}

