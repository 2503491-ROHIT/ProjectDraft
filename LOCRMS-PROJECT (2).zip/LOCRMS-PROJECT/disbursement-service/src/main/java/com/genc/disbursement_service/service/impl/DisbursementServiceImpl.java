package com.genc.disbursement_service.service.impl;

import com.genc.disbursement_service.dto.DisburseRequest;
import com.genc.disbursement_service.dto.DisbursementResponse;
import com.genc.disbursement_service.dto.RepaymentResponse;
import com.genc.disbursement_service.entity.Disbursement;
import com.genc.disbursement_service.entity.Repayment;
import com.genc.disbursement_service.enums.DisbursementStatus;
import com.genc.disbursement_service.enums.RepaymentStatus;
import com.genc.disbursement_service.exception.InvalidOperationException;
import com.genc.disbursement_service.exception.ResourceNotFoundException;
import com.genc.disbursement_service.repository.DisbursementRepository;
import com.genc.disbursement_service.repository.RepaymentRepository;
import com.genc.disbursement_service.service.DisbursementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Service
public class DisbursementServiceImpl implements DisbursementService {

    private static final Logger log = LoggerFactory.getLogger(DisbursementServiceImpl.class);

    private final DisbursementRepository disbursementRepository;
    private final RepaymentRepository repaymentRepository;

    public DisbursementServiceImpl(DisbursementRepository disbursementRepository,
                                   RepaymentRepository repaymentRepository) {
        this.disbursementRepository = disbursementRepository;
        this.repaymentRepository = repaymentRepository;
    }

    @Override
    public DisbursementResponse disburse(DisburseRequest request) {
        if (disbursementRepository.findByApplicationId(request.getApplicationId()).isPresent()) {
            throw new InvalidOperationException("Loan is already disbursed");
        }

        double emi = calculateEmi(request.getLoanAmount(), request.getInterestRate(), request.getTenureMonths());

        Disbursement disbursement = Disbursement.builder()
                .applicationId(request.getApplicationId())
                .customerId(request.getCustomerId())
                .loanAmount(request.getLoanAmount())
                .tenureMonths(request.getTenureMonths())
                .interestRate(request.getInterestRate())
                .emiAmount(emi)
                .status(DisbursementStatus.ACTIVE)
                .build();
        Disbursement saved = disbursementRepository.save(disbursement);

        generateSchedule(saved, emi);
        log.info("Loan {} disbursed. EMI = {}", request.getApplicationId(), emi);
        return toResponse(saved);
    }

    @Override
    public DisbursementResponse getByApplication(Long applicationId) {
        return toResponse(findByApplication(applicationId));
    }

    @Override
    public List<RepaymentResponse> getSchedule(Long applicationId) {
        return repaymentRepository.findByApplicationIdOrderByInstallmentNo(applicationId).stream()
                .map(this::toRepaymentResponse).toList();
    }

    @Override
    public RepaymentResponse recordRepayment(Long repaymentId) {
        Repayment repayment = repaymentRepository.findById(repaymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Repayment not found with id " + repaymentId));
        if (repayment.getRepaymentStatus() == RepaymentStatus.PAID) {
            throw new InvalidOperationException("This installment is already paid");
        }
        repayment.setPaidAmount(repayment.getEmiAmount());
        repayment.setPaidDate(LocalDate.now());
        repayment.setRepaymentStatus(RepaymentStatus.PAID);
        Repayment saved = repaymentRepository.save(repayment);
        log.info("EMI payment recorded for installment {} of loan {}",
                repayment.getInstallmentNo(), repayment.getApplicationId());
        return toRepaymentResponse(saved);
    }

    @Override
    public List<DisbursementResponse> getByCustomer(Long customerId) {
        return disbursementRepository.findByCustomerId(customerId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<DisbursementResponse> getAll() {
        return disbursementRepository.findAll().stream().map(this::toResponse).toList();
    }

    /**
     * Returns how many days the oldest unpaid & due installment is past due.
     * Also marks such installments as OVERDUE.
     */
    @Override
    public int getOverdueDays(Long applicationId) {
        LocalDate today = LocalDate.now();
        List<Repayment> repayments = repaymentRepository.findByApplicationIdOrderByInstallmentNo(applicationId);
        int maxDays = 0;
        for (Repayment r : repayments) {
            if (r.getRepaymentStatus() != RepaymentStatus.PAID && r.getDueDate().isBefore(today)) {
                r.setRepaymentStatus(RepaymentStatus.OVERDUE);
                repaymentRepository.save(r);
                int days = (int) ChronoUnit.DAYS.between(r.getDueDate(), today);
                maxDays = Math.max(maxDays, days);
            }
        }
        return maxDays;
    }

    // ----- helpers -----

    private void generateSchedule(Disbursement disbursement, double emi) {
        List<Repayment> repayments = new ArrayList<>();
        LocalDate firstDueDate = disbursement.getDisbursementDate().plusMonths(1);
        for (int i = 1; i <= disbursement.getTenureMonths(); i++) {
            Repayment repayment = Repayment.builder()
                    .disbursementId(disbursement.getId())
                    .applicationId(disbursement.getApplicationId())
                    .installmentNo(i)
                    .dueDate(firstDueDate.plusMonths(i - 1))
                    .emiAmount(emi)
                    .paidAmount(0.0)
                    .repaymentStatus(RepaymentStatus.PENDING)
                    .build();
            repayments.add(repayment);
        }
        repaymentRepository.saveAll(repayments);
    }

    // Standard reducing balance EMI formula
    private double calculateEmi(double principal, double annualRate, int months) {
        double monthlyRate = annualRate / 12 / 100;
        double factor = Math.pow(1 + monthlyRate, months);
        double emi = principal * monthlyRate * factor / (factor - 1);
        return Math.round(emi * 100.0) / 100.0;
    }

    private Disbursement findByApplication(Long applicationId) {
        return disbursementRepository.findByApplicationId(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("No disbursement found for application " + applicationId));
    }

    private DisbursementResponse toResponse(Disbursement d) {
        return new DisbursementResponse(d.getId(), d.getApplicationId(), d.getCustomerId(), d.getLoanAmount(),
                d.getTenureMonths(), d.getInterestRate(), d.getEmiAmount(), d.getDisbursementDate(), d.getStatus().name());
    }

    private RepaymentResponse toRepaymentResponse(Repayment r) {
        return new RepaymentResponse(r.getRepaymentId(), r.getDisbursementId(), r.getApplicationId(),
                r.getInstallmentNo(), r.getDueDate(), r.getEmiAmount(), r.getPaidAmount(),
                r.getRepaymentStatus().name(), r.getPaidDate());
    }
}

