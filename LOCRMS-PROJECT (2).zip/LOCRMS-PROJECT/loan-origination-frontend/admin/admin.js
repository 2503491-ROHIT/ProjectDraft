// ===== Admin role shared helpers =====

async function loadAllUsers() {
    return (await api.get(ENDPOINTS.users)).data;
}

async function loadCollectionAgents() {
    const users = await loadAllUsers();
    return users.filter(u => u.role === "COLLECTIONS_AGENT" && u.status === "ACTIVE");
}

