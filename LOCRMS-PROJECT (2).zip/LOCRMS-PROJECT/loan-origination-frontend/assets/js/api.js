// ===== Thin fetch wrapper that adds the JWT and handles common errors =====

function getToken() {
    return localStorage.getItem("token");
}

async function apiRequest(url, method = "GET", body = null, isForm = false) {
    const headers = {};
    const token = getToken();
    if (token) {
        headers["Authorization"] = "Bearer " + token;
    }

    const options = { method, headers };

    if (body) {
        if (isForm) {
            options.body = body; // FormData - let the browser set the content type
        } else {
            headers["Content-Type"] = "application/json";
            options.body = JSON.stringify(body);
        }
    }

    showLoader();
    try {
        const response = await fetch(url, options);

        // Token missing / invalid -> back to login
        if (response.status === 401) {
            clearSession();
            window.location.href = "/login.html";
            return null;
        }
        if (response.status === 403) {
            window.location.href = "/unauthorized.html";
            return null;
        }

        const contentType = response.headers.get("content-type") || "";
        const data = contentType.includes("application/json") ? await response.json() : await response.text();

        if (!response.ok) {
            const message = (data && data.message) ? data.message : "Request failed";
            throw new Error(message);
        }
        return data;
    } finally {
        hideLoader();
    }
}

// Convenience helpers
const api = {
    get: (url) => apiRequest(url, "GET"),
    post: (url, body) => apiRequest(url, "POST", body),
    put: (url, body) => apiRequest(url, "PUT", body),
    patch: (url, body) => apiRequest(url, "PATCH", body),
    del: (url) => apiRequest(url, "DELETE"),
    postForm: (url, formData) => apiRequest(url, "POST", formData, true)
};

