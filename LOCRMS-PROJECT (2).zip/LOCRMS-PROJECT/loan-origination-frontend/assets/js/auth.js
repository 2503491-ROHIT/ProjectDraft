// ===== Session + auth helpers =====

function saveSession(loginData) {
    localStorage.setItem("token", loginData.token);
    localStorage.setItem("userId", loginData.userId);
    localStorage.setItem("username", loginData.username);
    localStorage.setItem("fullName", loginData.fullName || "");
    localStorage.setItem("role", loginData.role);
}

function clearSession() {
    localStorage.clear();
}

function getRole() {
    return localStorage.getItem("role");
}

function getUserId() {
    return localStorage.getItem("userId");
}

function getFullName() {
    return localStorage.getItem("fullName") || localStorage.getItem("username");
}

function isLoggedIn() {
    return !!localStorage.getItem("token");
}

// Landing page for each role after login
function dashboardForRole(role) {
    switch (role) {
        case "ADMIN": return "/admin/dashboard.html";
        case "CUSTOMER": return "/customer/dashboard.html";
        case "LOAN_OFFICER": return "/loan-officer/dashboard.html";
        case "CREDIT_ANALYST": return "/credit-analyst/dashboard.html";
        case "UNDERWRITER": return "/underwriter/dashboard.html";
        case "COLLECTIONS_AGENT": return "/collections-agent/dashboard.html";
        default: return "/login.html";
    }
}

// Guard a page: must be logged in and (optionally) have one of the allowed roles
function requireAuth(allowedRoles) {
    if (!isLoggedIn()) {
        window.location.href = "/login.html";
        return false;
    }
    if (allowedRoles && allowedRoles.length && !allowedRoles.includes(getRole())) {
        window.location.href = "/unauthorized.html";
        return false;
    }
    return true;
}

async function doLogin(username, password) {
    const res = await api.post(ENDPOINTS.login, { username, password });
    saveSession(res.data);
    return res.data;
}

function logout() {
    clearSession();
    window.location.href = "/login.html";
}

