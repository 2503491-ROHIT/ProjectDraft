// ===== Shared UI: navbar, sidebar, footer, toast, loader, helpers =====

// ----- Bootstrap Icons (injected once so every page gets them) -----
function ensureIcons() {
    if (!document.getElementById("bootstrapIcons")) {
        const link = document.createElement("link");
        link.id = "bootstrapIcons";
        link.rel = "stylesheet";
        link.href = "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css";
        document.head.appendChild(link);
    }
}

// ----- Loader -----
function ensureLoader() {
    if (!document.getElementById("loaderOverlay")) {
        const div = document.createElement("div");
        div.id = "loaderOverlay";
        div.innerHTML = `<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>`;
        document.body.appendChild(div);
    }
}
function showLoader() { ensureLoader(); document.getElementById("loaderOverlay").style.display = "flex"; }
function hideLoader() { const l = document.getElementById("loaderOverlay"); if (l) l.style.display = "none"; }

// ----- Toast -----
function showToast(message, type = "success") {
    let container = document.getElementById("toastContainer");
    if (!container) {
        container = document.createElement("div");
        container.id = "toastContainer";
        container.className = "toast-container position-fixed top-0 start-50 translate-middle-x p-3";
        container.style.zIndex = "3000";
        document.body.appendChild(container);
    }
    const id = "toast" + Date.now();
    container.insertAdjacentHTML("beforeend", `
        <div id="${id}" class="toast align-items-center text-bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>`);
    const el = document.getElementById(id);
    const toast = new bootstrap.Toast(el, { delay: 3500 });
    toast.show();
    el.addEventListener("hidden.bs.toast", () => el.remove());
}

// ----- Menus per role -----
const MENUS = {
    ADMIN: [
        { key: "dashboard", label: "Dashboard", href: "/admin/dashboard.html" },
        { key: "employees", label: "Employees", href: "/admin/employees.html" },
        { key: "create-employee", label: "Create Employee", href: "/admin/create-employee.html" },
        { key: "delinquent", label: "Delinquent Accounts", href: "/admin/delinquent-accounts.html" },
        { key: "assign-agent", label: "Assign Agent", href: "/admin/assign-agent.html" },
        { key: "reports", label: "Reports", href: "/admin/reports.html" }
    ],
    CUSTOMER: [
        { key: "dashboard", label: "Dashboard", href: "/customer/dashboard.html" },
        { key: "profile", label: "My Profile", href: "/customer/profile.html" },
        { key: "upload-kyc", label: "Upload KYC", href: "/customer/upload-kyc.html" },
        { key: "loan-application", label: "Apply for Loan", href: "/customer/loan-application.html" },
        { key: "loan-status", label: "Loan Status", href: "/customer/loan-status.html" },
        { key: "emi-schedule", label: "EMI Schedule", href: "/customer/emi-schedule.html" },
        { key: "repayment-history", label: "Repayment History", href: "/customer/repayment-history.html" }
    ],
    LOAN_OFFICER: [
        { key: "dashboard", label: "Dashboard", href: "/loan-officer/dashboard.html" },
        { key: "kyc-requests", label: "KYC Requests", href: "/loan-officer/kyc-requests.html" },
        { key: "application-review", label: "Applications", href: "/loan-officer/application-review.html" },
        { key: "eligibility-check", label: "Eligibility Check", href: "/loan-officer/eligibility-check.html" },
        { key: "disbursement", label: "Disbursement", href: "/loan-officer/disbursement.html" }
    ],
    CREDIT_ANALYST: [
        { key: "dashboard", label: "Dashboard", href: "/credit-analyst/dashboard.html" },
        { key: "assigned-applications", label: "Assigned Applications", href: "/credit-analyst/assigned-applications.html" },
        { key: "credit-evaluation", label: "Credit Evaluation", href: "/credit-analyst/credit-evaluation.html" },
        { key: "risk-grading", label: "Risk Grading", href: "/credit-analyst/risk-grading.html" }
    ],
    UNDERWRITER: [
        { key: "dashboard", label: "Dashboard", href: "/underwriter/dashboard.html" },
        { key: "pending-approvals", label: "Pending Approvals", href: "/underwriter/pending-approvals.html" },
        { key: "application-details", label: "Application Details", href: "/underwriter/application-details.html" },
        { key: "approve-reject", label: "Approve / Reject", href: "/underwriter/approve-reject.html" }
    ],
    COLLECTIONS_AGENT: [
        { key: "dashboard", label: "Dashboard", href: "/collections-agent/dashboard.html" },
        { key: "assigned-cases", label: "Assigned Cases", href: "/collections-agent/assigned-cases.html" },
        { key: "recovery-action", label: "Recovery Action", href: "/collections-agent/recovery-action.html" },
        { key: "recovery-history", label: "Recovery History", href: "/collections-agent/recovery-history.html" }
    ]
};

const ROLE_LABELS = {
    ADMIN: "Administrator",
    CUSTOMER: "Customer",
    LOAN_OFFICER: "Loan Officer",
    CREDIT_ANALYST: "Credit Analyst",
    UNDERWRITER: "Underwriter",
    COLLECTIONS_AGENT: "Collections Agent"
};

// Bootstrap icon per sidebar menu key
const MENU_ICONS = {
    dashboard: "bi-speedometer2",
    employees: "bi-people",
    "create-employee": "bi-person-plus",
    delinquent: "bi-exclamation-triangle",
    "assign-agent": "bi-person-check",
    reports: "bi-bar-chart",
    profile: "bi-person-circle",
    "upload-kyc": "bi-cloud-upload",
    "loan-application": "bi-file-earmark-plus",
    "loan-status": "bi-list-check",
    "emi-schedule": "bi-calendar-check",
    "repayment-history": "bi-clock-history",
    "kyc-requests": "bi-shield-check",
    "application-review": "bi-files",
    "eligibility-check": "bi-check2-square",
    disbursement: "bi-cash-stack",
    "assigned-applications": "bi-inbox",
    "credit-evaluation": "bi-graph-up-arrow",
    "risk-grading": "bi-shield-exclamation",
    "pending-approvals": "bi-hourglass-split",
    "application-details": "bi-file-text",
    "approve-reject": "bi-check2-circle",
    "assigned-cases": "bi-briefcase",
    "recovery-action": "bi-pencil-square"
};

// ----- Layout -----
function renderNavbar() {
    const nav = document.getElementById("navbar-placeholder");
    if (!nav) return;
    const initial = (getFullName() || "?").trim().charAt(0).toUpperCase();
    nav.innerHTML = `
    <nav class="navbar app-navbar navbar-dark px-3 py-2">
        <span class="navbar-brand brand-logo mb-0 h1 d-flex align-items-center gap-2">
            <i class="bi bi-bank2"></i> LOCRMS
        </span>
        <div class="d-flex align-items-center">
            <span class="user-chip me-3">
                <span class="user-avatar">${initial}</span>
                <span>
                    <span class="fw-semibold">${escapeHtml(getFullName())}</span>
                </span>
            </span>
            <button id="logoutBtn" class="btn btn-light btn-sm"><i class="bi bi-box-arrow-right"></i> Logout</button>
        </div>
    </nav>`;
}

function renderSidebar(activeKey) {
    const side = document.getElementById("sidebar-placeholder");
    if (!side) return;
    const menu = MENUS[getRole()] || [];
    side.innerHTML = `<div class="sidebar-heading">${ROLE_LABELS[getRole()] || "Menu"}</div>` +
        menu.map(m => {
            const icon = MENU_ICONS[m.key] || "bi-dot";
            return `<a href="${m.href}" class="${m.key === activeKey ? "active" : ""}">
                        <i class="bi ${icon}"></i><span>${m.label}</span>
                    </a>`;
        }).join("");
}

function renderFooter() {
    const footer = document.getElementById("footer-placeholder");
    if (!footer) return;
    footer.innerHTML = `
    <footer class="text-center py-3 border-top mt-4">
        <small>&copy; ${new Date().getFullYear()} Loan Origination &amp; Credit Risk Management System</small>
    </footer>`;
}

// Call this at the top of every protected page
function initLayout(activeKey, allowedRoles) {
    if (!requireAuth(allowedRoles)) return false;
    ensureIcons();
    renderNavbar();
    renderSidebar(activeKey);
    renderFooter();
    attachLogoutHandler();
    return true;
}

// ----- Small formatting helpers -----
function badge(status) {
    const map = {
        PENDING: "warning", VERIFIED: "success", REJECTED: "danger",
        SUBMITTED: "secondary", ELIGIBILITY_APPROVED: "info", ELIGIBILITY_REJECTED: "danger",
        FORWARDED_TO_CREDIT: "info", FORWARDED_TO_UNDERWRITER: "primary",
        APPROVED: "success", DISBURSED: "success",
        PAID: "success", OVERDUE: "danger",
        LOW: "success", MEDIUM: "warning", HIGH: "danger",
        RECOVERED: "success", WRITTEN_OFF: "dark", ACTIVE: "primary",
        INACTIVE: "secondary"
    };
    const color = map[status] || "secondary";
    return `<span class="badge bg-${color}">${status}</span>`;
}

function money(v) {
    if (v === null || v === undefined) return "-";
    return "₹" + Number(v).toLocaleString("en-IN");
}

function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str).replace(/[&<>"']/g, s => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[s]));
}

// ----- Display ID helpers -----
// Turns a numeric id into a padded, prefixed code (e.g. 1 -> CUST-0000001)
function fmtId(prefix, id) {
    if (id === null || id === undefined || id === "") return "-";
    return prefix + "-" + String(id).padStart(7, "0");
}
const fmtCustomerId    = (id) => fmtId("CUST", id);
const fmtLoanId        = (id) => fmtId("LOAN", id);
const fmtEmployeeId    = (id) => fmtId("EMP",  id);
const fmtUserId        = (id) => fmtId("USR",  id);
const fmtKycDocId      = (id) => fmtId("DOC",  id);
const fmtCreditId      = (id) => fmtId("CRED", id);
const fmtDisbursementId= (id) => fmtId("DISB", id);
const fmtRepaymentId   = (id) => fmtId("EMI",  id);
const fmtCaseId        = (id) => fmtId("CASE", id);
const fmtActionId      = (id) => fmtId("ACT",  id);

