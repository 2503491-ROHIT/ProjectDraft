// ===== Central configuration for the frontend =====
// All requests go through the API Gateway.
const API_BASE = "http://localhost:9090";

// Endpoint helpers keep the URLs in one place.
const ENDPOINTS = {
    // auth
    login: `${API_BASE}/auth/login`,
    changePassword: `${API_BASE}/auth/change-password`,

    // admin (user management)
    employees: `${API_BASE}/admin/employees`,
    users: `${API_BASE}/admin/users`,
    userStatus: (id) => `${API_BASE}/admin/users/${id}/status`,

    // customers
    register: `${API_BASE}/customers/register`,
    customers: `${API_BASE}/customers`,
    customerById: (id) => `${API_BASE}/customers/${id}`,
    customerByUser: (userId) => `${API_BASE}/customers/user/${userId}`,
    updateCustomer: (id) => `${API_BASE}/customers/${id}`,
    kyc: (id) => `${API_BASE}/customers/${id}/kyc`,
    kycDownload: (docId) => `${API_BASE}/customers/kyc/${docId}/download`,
    kycStatus: (id) => `${API_BASE}/customers/${id}/kyc/status`,
    kycPending: `${API_BASE}/customers/kyc/pending`,
    kycVerify: (id) => `${API_BASE}/customers/${id}/kyc/verify`,

    // loans
    loans: `${API_BASE}/loans`,
    loanById: (id) => `${API_BASE}/loans/${id}`,
    loansByCustomer: (id) => `${API_BASE}/loans/customer/${id}`,
    loansByStatus: (status) => `${API_BASE}/loans/status/${status}`,
    loanEligibility: (id) => `${API_BASE}/loans/${id}/eligibility`,
    loanForwardCredit: (id) => `${API_BASE}/loans/${id}/forward-credit`,
    loanDecision: (id) => `${API_BASE}/loans/${id}/decision`,
    loanDisburse: (id) => `${API_BASE}/loans/${id}/disburse`,

    // credit
    creditEvaluate: (appId) => `${API_BASE}/credit/evaluate/${appId}`,
    bureauScore: (custId) => `${API_BASE}/credit/bureau-score/${custId}`,
    creditByApp: (appId) => `${API_BASE}/credit/${appId}`,

    // disbursements
    disbursementByApp: (appId) => `${API_BASE}/disbursements/${appId}`,
    schedule: (appId) => `${API_BASE}/disbursements/${appId}/schedule`,
    payEmi: (repaymentId) => `${API_BASE}/disbursements/repayments/${repaymentId}/pay`,
    disbursementsByCustomer: (id) => `${API_BASE}/disbursements/customer/${id}`,

    // collections
    collections: `${API_BASE}/collections`,
    collectionsFlag: `${API_BASE}/collections/flag`,
    collectionsAssign: (id) => `${API_BASE}/collections/${id}/assign`,
    collectionsByAgent: (id) => `${API_BASE}/collections/agent/${id}`,
    recoveryAction: (id) => `${API_BASE}/collections/${id}/recovery-action`,
    recoveryHistory: (id) => `${API_BASE}/collections/${id}/history`,
    collectionsStatus: (id) => `${API_BASE}/collections/${id}/status`
};

