// ===== logout helper (kept in its own file as per the project structure) =====
function attachLogoutHandler() {
    const btn = document.getElementById("logoutBtn");
    if (btn) {
        btn.addEventListener("click", function (e) {
            e.preventDefault();
            logout();
        });
    }
}

