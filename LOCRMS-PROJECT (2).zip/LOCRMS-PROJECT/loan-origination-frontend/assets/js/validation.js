// ===== Simple, reusable client side validators =====

const Validators = {
    required: (value) => value !== null && value !== undefined && String(value).trim() !== "",
    email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
    pan: (value) => /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(value),
    aadhaar: (value) => /^\d{12}$/.test(value),
    phone: (value) => /^[6-9]\d{9}$/.test(value),
    minLength: (value, len) => String(value).length >= len,
    positive: (value) => Number(value) > 0
};

// Validate a form using a rules object: { fieldId: [ {rule, message} ] }
function validateForm(rules) {
    let firstError = null;
    for (const fieldId in rules) {
        const el = document.getElementById(fieldId);
        const value = el ? el.value : "";
        for (const check of rules[fieldId]) {
            if (!check.test(value)) {
                if (!firstError) firstError = check.message;
                break;
            }
        }
    }
    if (firstError) {
        showToast(firstError, "danger");
        return false;
    }
    return true;
}

