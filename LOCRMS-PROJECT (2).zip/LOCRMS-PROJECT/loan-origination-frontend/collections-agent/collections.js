// ===== Collections Agent shared helpers =====

async function myCases() {
    return (await api.get(ENDPOINTS.collectionsByAgent(getUserId()))).data;
}

