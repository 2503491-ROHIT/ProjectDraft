// ===== Credit Analyst shared helpers =====

async function forwardedToCredit() {
    return (await api.get(ENDPOINTS.loansByStatus("FORWARDED_TO_CREDIT"))).data;
}

