// ===== Customer role shared helpers =====

let CURRENT_CUSTOMER = null;

// Loads the logged-in customer's profile and caches the customerId.
async function ensureCustomer() {
    if (CURRENT_CUSTOMER) return CURRENT_CUSTOMER;
    const res = await api.get(ENDPOINTS.customerByUser(getUserId()));
    CURRENT_CUSTOMER = res.data;
    localStorage.setItem("customerId", CURRENT_CUSTOMER.customerId);
    return CURRENT_CUSTOMER;
}

function customerId() {
    return localStorage.getItem("customerId");
}

