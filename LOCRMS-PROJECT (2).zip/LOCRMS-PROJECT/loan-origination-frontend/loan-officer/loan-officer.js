// ===== Loan Officer shared helpers =====

async function loansByStatus(status) {
    return (await api.get(ENDPOINTS.loansByStatus(status))).data;
}

