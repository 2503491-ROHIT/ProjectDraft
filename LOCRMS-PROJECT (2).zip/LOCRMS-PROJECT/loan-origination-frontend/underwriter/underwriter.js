// ===== Underwriter shared helpers =====

async function pendingUnderwriting() {
    return (await api.get(ENDPOINTS.loansByStatus("FORWARDED_TO_UNDERWRITER"))).data;
}

