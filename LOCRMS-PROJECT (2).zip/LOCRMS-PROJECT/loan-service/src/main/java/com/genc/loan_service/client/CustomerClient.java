package com.genc.loan_service.client;

import com.genc.loan_service.dto.ApiResponse;
import com.genc.loan_service.dto.CustomerDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Reads customer details (KYC status, income) from the customer-service.
 */
@FeignClient(name = "customer-service")
public interface CustomerClient {

    @GetMapping("/customers/{id}")
    ApiResponse<CustomerDto> getCustomer(@PathVariable("id") Long id);
}

