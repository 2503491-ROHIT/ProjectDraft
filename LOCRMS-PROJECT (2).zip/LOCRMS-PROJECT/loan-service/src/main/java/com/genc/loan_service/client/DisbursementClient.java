package com.genc.loan_service.client;

import com.genc.loan_service.dto.ApiResponse;
import com.genc.loan_service.dto.DisburseRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Asks the disbursement-service to disburse an approved loan and build the EMI schedule.
 */
@FeignClient(name = "disbursement-service")
public interface DisbursementClient {

    @PostMapping("/disbursements")
    ApiResponse<Void> disburse(@RequestBody DisburseRequest request);
}

