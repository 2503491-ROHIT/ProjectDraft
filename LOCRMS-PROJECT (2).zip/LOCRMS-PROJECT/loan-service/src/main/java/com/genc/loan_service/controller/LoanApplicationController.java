package com.genc.loan_service.controller;

import com.genc.loan_service.dto.*;
import com.genc.loan_service.service.LoanService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/loans")
public class LoanApplicationController {

    private final LoanService loanService;

    public LoanApplicationController(LoanService loanService) {
        this.loanService = loanService;
    }

    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<ApiResponse<LoanResponse>> submit(@Valid @RequestBody LoanApplicationRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Loan application submitted", loanService.submit(request)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<LoanResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Loan fetched", loanService.getById(id)));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<ApiResponse<List<LoanResponse>>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(ApiResponse.success("Loans fetched", loanService.getByCustomer(customerId)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<LoanResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Loans fetched", loanService.getAll()));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<LoanResponse>>> getByStatus(@PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.success("Loans fetched", loanService.getByStatus(status)));
    }

    // Loan Officer: eligibility check
    @PatchMapping("/{id}/eligibility")
    @PreAuthorize("hasRole('LOAN_OFFICER')")
    public ResponseEntity<ApiResponse<LoanResponse>> checkEligibility(@PathVariable Long id,
                                                                      @Valid @RequestBody EligibilityDecisionRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Eligibility processed", loanService.checkEligibility(id, request)));
    }

    // Loan Officer: forward to credit analyst
    @PatchMapping("/{id}/forward-credit")
    @PreAuthorize("hasRole('LOAN_OFFICER')")
    public ResponseEntity<ApiResponse<LoanResponse>> forwardToCredit(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Forwarded to credit analyst", loanService.forwardToCredit(id)));
    }

    // Called by the credit-service after the evaluation is done
    @PatchMapping("/{id}/credit-evaluation")
    public ResponseEntity<ApiResponse<LoanResponse>> applyCreditEvaluation(@PathVariable Long id,
                                                                           @Valid @RequestBody CreditUpdateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Credit evaluation applied",
                loanService.applyCreditEvaluation(id, request)));
    }

    // Underwriter: approve or reject
    @PatchMapping("/{id}/decision")
    @PreAuthorize("hasRole('UNDERWRITER')")
    public ResponseEntity<ApiResponse<LoanResponse>> decision(@PathVariable Long id,
                                                              @Valid @RequestBody UnderwriterDecisionRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Decision recorded", loanService.underwriterDecision(id, request)));
    }

    // Loan Officer: disburse an approved loan
    @PatchMapping("/{id}/disburse")
    @PreAuthorize("hasRole('LOAN_OFFICER')")
    public ResponseEntity<ApiResponse<LoanResponse>> disburse(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Loan disbursed", loanService.disburse(id)));
    }
}

