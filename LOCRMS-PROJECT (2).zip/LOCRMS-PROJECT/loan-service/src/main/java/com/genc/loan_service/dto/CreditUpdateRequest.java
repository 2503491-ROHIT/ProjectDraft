package com.genc.loan_service.dto;

import com.genc.loan_service.enums.RiskGrade;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Sent by the credit-service (through a client) after credit evaluation.
 */
@Data
public class CreditUpdateRequest {

    @NotNull(message = "Credit score is required")
    private Integer creditScore;

    @NotNull(message = "Risk grade is required")
    private RiskGrade riskGrade;

    private String creditRemarks;
}

