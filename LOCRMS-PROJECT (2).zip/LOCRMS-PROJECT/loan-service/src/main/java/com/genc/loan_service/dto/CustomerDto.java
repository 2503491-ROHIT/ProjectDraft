package com.genc.loan_service.dto;

import lombok.Data;

/**
 * Small view of a customer fetched from the customer-service.
 */
@Data
public class CustomerDto {
    private Long customerId;
    private String fullName;
    private String kycStatus;
    private Double monthlyIncome;
}

