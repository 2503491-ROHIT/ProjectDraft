package com.genc.loan_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Body sent to the disbursement-service to disburse an approved loan.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DisburseRequest {
    private Long applicationId;
    private Long customerId;
    private Double loanAmount;
    private Integer tenureMonths;
    private Double interestRate;
}

