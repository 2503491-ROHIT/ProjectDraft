package com.genc.loan_service.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Loan Officer approves or rejects the eligibility check.
 */
@Data
public class EligibilityDecisionRequest {

    @NotNull(message = "Approved flag is required")
    private Boolean approved;

    private String remarks;
}

