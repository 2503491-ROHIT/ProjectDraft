package com.genc.loan_service.dto;

import com.genc.loan_service.enums.LoanType;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class LoanApplicationRequest {

    @NotNull(message = "Customer id is required")
    private Long customerId;

    @NotNull(message = "Loan type is required")
    private LoanType loanType;

    @NotNull(message = "Requested amount is required")
    @Positive(message = "Requested amount must be positive")
    private Double requestedAmount;

    @NotNull(message = "Tenure is required")
    @Min(value = 6, message = "Minimum tenure is 6 months")
    @Max(value = 360, message = "Maximum tenure is 360 months")
    private Integer tenureMonths;

    @NotNull(message = "Monthly income is required")
    @Positive(message = "Monthly income must be positive")
    private Double monthlyIncome;

    @NotNull(message = "Existing EMI is required (enter 0 if none)")
    @PositiveOrZero(message = "Existing EMI cannot be negative")
    private Double existingEmi;
}

