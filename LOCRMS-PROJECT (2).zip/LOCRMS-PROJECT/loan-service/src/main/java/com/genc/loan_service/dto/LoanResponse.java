package com.genc.loan_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanResponse {
    private Long applicationId;
    private Long customerId;
    private String customerName;
    private String loanType;
    private Double requestedAmount;
    private Integer tenureMonths;
    private Double monthlyIncome;
    private Double existingEmi;
    private String applicationStatus;
    private String eligibilityRemarks;
    private Integer creditScore;
    private String riskGrade;
    private String creditRemarks;
    private String underwriterRemarks;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

