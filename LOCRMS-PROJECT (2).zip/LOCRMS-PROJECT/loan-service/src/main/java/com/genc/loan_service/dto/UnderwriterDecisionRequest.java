package com.genc.loan_service.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Underwriter approves or rejects the final application.
 */
@Data
public class UnderwriterDecisionRequest {

    @NotNull(message = "Approved flag is required")
    private Boolean approved;

    private String remarks;
}

