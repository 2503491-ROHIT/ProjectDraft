package com.genc.loan_service.entity;

import com.genc.loan_service.enums.LoanStatus;
import com.genc.loan_service.enums.LoanType;
import com.genc.loan_service.enums.RiskGrade;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "loan_applications")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    private Long customerId;
    private String customerName;

    @Enumerated(EnumType.STRING)
    private LoanType loanType;

    private Double requestedAmount;
    private Integer tenureMonths;
    private Double monthlyIncome;
    private Double existingEmi;

    @Enumerated(EnumType.STRING)
    private LoanStatus applicationStatus;

    private String eligibilityRemarks;

    // Filled in by the credit-service
    private Integer creditScore;

    @Enumerated(EnumType.STRING)
    private RiskGrade riskGrade;

    private String creditRemarks;

    // Filled in by the underwriter
    private String underwriterRemarks;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.applicationStatus == null) {
            this.applicationStatus = LoanStatus.SUBMITTED;
        }
    }

    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}

