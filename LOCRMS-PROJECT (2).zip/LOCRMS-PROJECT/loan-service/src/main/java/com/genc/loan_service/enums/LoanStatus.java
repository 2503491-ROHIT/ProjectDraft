package com.genc.loan_service.enums;

/**
 * The stages a loan application moves through in the workflow.
 */
public enum LoanStatus {
    SUBMITTED,
    ELIGIBILITY_APPROVED,
    ELIGIBILITY_REJECTED,
    FORWARDED_TO_CREDIT,
    FORWARDED_TO_UNDERWRITER,
    APPROVED,
    REJECTED,
    DISBURSED
}

