package com.genc.loan_service.enums;

public enum LoanType {
    PERSONAL,
    HOME,
    VEHICLE,
    EDUCATION,
    BUSINESS
}

