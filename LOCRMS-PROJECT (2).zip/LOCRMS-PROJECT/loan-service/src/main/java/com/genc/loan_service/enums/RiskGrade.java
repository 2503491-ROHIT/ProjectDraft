package com.genc.loan_service.enums;

public enum RiskGrade {
    LOW,
    MEDIUM,
    HIGH
}

