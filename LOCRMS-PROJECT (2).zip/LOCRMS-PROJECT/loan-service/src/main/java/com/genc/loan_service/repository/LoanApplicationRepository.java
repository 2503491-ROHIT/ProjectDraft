package com.genc.loan_service.repository;

import com.genc.loan_service.entity.LoanApplication;
import com.genc.loan_service.enums.LoanStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LoanApplicationRepository extends JpaRepository<LoanApplication, Long> {

    List<LoanApplication> findByCustomerId(Long customerId);

    List<LoanApplication> findByApplicationStatus(LoanStatus status);
}

