package com.genc.loan_service.service;

import com.genc.loan_service.dto.*;

import java.util.List;

public interface LoanService {

    LoanResponse submit(LoanApplicationRequest request);

    LoanResponse getById(Long applicationId);

    List<LoanResponse> getByCustomer(Long customerId);

    List<LoanResponse> getAll();

    List<LoanResponse> getByStatus(String status);

    LoanResponse checkEligibility(Long applicationId, EligibilityDecisionRequest request);

    LoanResponse forwardToCredit(Long applicationId);

    LoanResponse applyCreditEvaluation(Long applicationId, CreditUpdateRequest request);

    LoanResponse underwriterDecision(Long applicationId, UnderwriterDecisionRequest request);

    LoanResponse disburse(Long applicationId);
}

