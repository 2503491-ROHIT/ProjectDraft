package com.genc.loan_service.service.impl;

import com.genc.loan_service.client.CustomerClient;
import com.genc.loan_service.client.DisbursementClient;
import com.genc.loan_service.dto.*;
import com.genc.loan_service.entity.LoanApplication;
import com.genc.loan_service.enums.LoanStatus;
import com.genc.loan_service.exception.InvalidOperationException;
import com.genc.loan_service.exception.ResourceNotFoundException;
import com.genc.loan_service.repository.LoanApplicationRepository;
import com.genc.loan_service.service.LoanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanServiceImpl implements LoanService {

    private static final Logger log = LoggerFactory.getLogger(LoanServiceImpl.class);

    // A flat interest rate is used to keep the EMI maths simple
    private static final double INTEREST_RATE = 10.5;

    private final LoanApplicationRepository loanRepository;
    private final CustomerClient customerClient;
    private final DisbursementClient disbursementClient;

    public LoanServiceImpl(LoanApplicationRepository loanRepository,
                           CustomerClient customerClient,
                           DisbursementClient disbursementClient) {
        this.loanRepository = loanRepository;
        this.customerClient = customerClient;
        this.disbursementClient = disbursementClient;
    }

    @Override
    public LoanResponse submit(LoanApplicationRequest request) {
        // Customer must exist and KYC must be verified before applying
        CustomerDto customer = customerClient.getCustomer(request.getCustomerId()).getData();
        if (customer == null) {
            throw new ResourceNotFoundException("Customer not found");
        }
        if (!"VERIFIED".equalsIgnoreCase(customer.getKycStatus())) {
            throw new InvalidOperationException("KYC must be verified before applying for a loan");
        }

        LoanApplication loan = LoanApplication.builder()
                .customerId(request.getCustomerId())
                .customerName(customer.getFullName())
                .loanType(request.getLoanType())
                .requestedAmount(request.getRequestedAmount())
                .tenureMonths(request.getTenureMonths())
                .monthlyIncome(request.getMonthlyIncome())
                .existingEmi(request.getExistingEmi())
                .applicationStatus(LoanStatus.SUBMITTED)
                .build();

        LoanApplication saved = loanRepository.save(loan);
        log.info("Loan application submitted: id={} customer={}", saved.getApplicationId(), saved.getCustomerId());
        return toResponse(saved);
    }

    @Override
    public LoanResponse getById(Long applicationId) {
        return toResponse(findLoan(applicationId));
    }

    @Override
    public List<LoanResponse> getByCustomer(Long customerId) {
        return loanRepository.findByCustomerId(customerId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<LoanResponse> getAll() {
        return loanRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public List<LoanResponse> getByStatus(String status) {
        LoanStatus loanStatus = parseStatus(status);
        return loanRepository.findByApplicationStatus(loanStatus).stream().map(this::toResponse).toList();
    }

    @Override
    public LoanResponse checkEligibility(Long applicationId, EligibilityDecisionRequest request) {
        LoanApplication loan = findLoan(applicationId);
        if (loan.getApplicationStatus() != LoanStatus.SUBMITTED) {
            throw new InvalidOperationException("Eligibility can only be checked for submitted applications");
        }

        // Simple business rules for eligibility
        boolean rulesPassed = isEligibleByRules(loan);
        boolean approved = Boolean.TRUE.equals(request.getApproved()) && rulesPassed;

        if (approved) {
            loan.setApplicationStatus(LoanStatus.ELIGIBILITY_APPROVED);
            loan.setEligibilityRemarks(request.getRemarks() != null ? request.getRemarks() : "Eligibility approved");
            log.info("Loan {} passed eligibility check", applicationId);
        } else {
            loan.setApplicationStatus(LoanStatus.ELIGIBILITY_REJECTED);
            String reason = rulesPassed ? request.getRemarks() : "Does not meet income/EMI rules";
            loan.setEligibilityRemarks(reason);
            log.info("Loan {} rejected at eligibility check", applicationId);
        }
        return toResponse(loanRepository.save(loan));
    }

    @Override
    public LoanResponse forwardToCredit(Long applicationId) {
        LoanApplication loan = findLoan(applicationId);
        if (loan.getApplicationStatus() != LoanStatus.ELIGIBILITY_APPROVED) {
            throw new InvalidOperationException("Only eligible applications can be forwarded to credit");
        }
        loan.setApplicationStatus(LoanStatus.FORWARDED_TO_CREDIT);
        log.info("Loan {} forwarded to credit analyst", applicationId);
        return toResponse(loanRepository.save(loan));
    }

    @Override
    public LoanResponse applyCreditEvaluation(Long applicationId, CreditUpdateRequest request) {
        LoanApplication loan = findLoan(applicationId);
        loan.setCreditScore(request.getCreditScore());
        loan.setRiskGrade(request.getRiskGrade());
        loan.setCreditRemarks(request.getCreditRemarks());
        loan.setApplicationStatus(LoanStatus.FORWARDED_TO_UNDERWRITER);
        log.info("Credit evaluation applied to loan {} and forwarded to underwriter", applicationId);
        return toResponse(loanRepository.save(loan));
    }

    @Override
    public LoanResponse underwriterDecision(Long applicationId, UnderwriterDecisionRequest request) {
        LoanApplication loan = findLoan(applicationId);
        if (loan.getApplicationStatus() != LoanStatus.FORWARDED_TO_UNDERWRITER) {
            throw new InvalidOperationException("Application is not ready for underwriting");
        }
        if (Boolean.TRUE.equals(request.getApproved())) {
            loan.setApplicationStatus(LoanStatus.APPROVED);
            log.info("Loan {} approved by underwriter", applicationId);
        } else {
            loan.setApplicationStatus(LoanStatus.REJECTED);
            log.info("Loan {} rejected by underwriter", applicationId);
        }
        loan.setUnderwriterRemarks(request.getRemarks());
        return toResponse(loanRepository.save(loan));
    }

    @Override
    public LoanResponse disburse(Long applicationId) {
        LoanApplication loan = findLoan(applicationId);
        if (loan.getApplicationStatus() != LoanStatus.APPROVED) {
            throw new InvalidOperationException("Only approved loans can be disbursed");
        }

        DisburseRequest disburseRequest = new DisburseRequest(
                loan.getApplicationId(), loan.getCustomerId(),
                loan.getRequestedAmount(), loan.getTenureMonths(), INTEREST_RATE);
        disbursementClient.disburse(disburseRequest);

        loan.setApplicationStatus(LoanStatus.DISBURSED);
        log.info("Loan {} disbursed", applicationId);
        return toResponse(loanRepository.save(loan));
    }

    // ----- helpers -----

    private boolean isEligibleByRules(LoanApplication loan) {
        // Rule 1: income at least 15000
        if (loan.getMonthlyIncome() == null || loan.getMonthlyIncome() < 15000) {
            return false;
        }
        // Rule 2: proposed EMI + existing EMI should be under 50% of income
        double proposedEmi = loan.getRequestedAmount() / loan.getTenureMonths();
        double totalEmi = proposedEmi + (loan.getExistingEmi() == null ? 0 : loan.getExistingEmi());
        return totalEmi <= (loan.getMonthlyIncome() * 0.5);
    }

    private LoanApplication findLoan(Long applicationId) {
        return loanRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Loan application not found with id " + applicationId));
    }

    private LoanStatus parseStatus(String status) {
        try {
            return LoanStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new InvalidOperationException("Invalid loan status: " + status);
        }
    }

    private LoanResponse toResponse(LoanApplication l) {
        return new LoanResponse(l.getApplicationId(), l.getCustomerId(), l.getCustomerName(),
                l.getLoanType() != null ? l.getLoanType().name() : null,
                l.getRequestedAmount(), l.getTenureMonths(), l.getMonthlyIncome(), l.getExistingEmi(),
                l.getApplicationStatus().name(), l.getEligibilityRemarks(), l.getCreditScore(),
                l.getRiskGrade() != null ? l.getRiskGrade().name() : null,
                l.getCreditRemarks(), l.getUnderwriterRemarks(), l.getCreatedAt(), l.getUpdatedAt());
    }
}

